# Implementation note 01: token-level chat-shell extraction

Date: 2026-09-12 UTC  
Timing: before any Mistral canonical or noncanonical task score

The initial generic adapter rendered a chat template to text, split that text
around a unique user marker, and separately re-tokenized the prefix and suffix.
That reconstruction is valid for the original Qwen/Phi paths but failed for
Mistral because separately tokenizing rendered special-token text does not
necessarily reproduce the IDs emitted by `apply_chat_template`.

The corrected implementation obtains the official tokenized marker prompt,
locates the standalone marker-token sequence exactly once inside it, and takes
the surrounding IDs directly as the prefix and suffix. Every experimental
prompt is still checked against the official chat-template IDs before scoring.

This is an implementation correction to enforce the already intended
chat-shell identity invariant. It changes no task instance, causal estimand,
threshold, seed, sample size, or stopping rule. No Mistral task outcome was
accessed before the correction.

