#!/usr/bin/env python3
"""Build the two reviewed Colab notebooks from readable cell sources."""

from __future__ import annotations

import copy
from pathlib import Path
from textwrap import dedent

import nbformat as nbf

ROOT = Path(__file__).resolve().parents[1]


def md(text: str):
    return nbf.v4.new_markdown_cell(dedent(text).strip())


def code(text: str):
    return nbf.v4.new_code_cell(dedent(text).strip())


def notebook(cells):
    nb = nbf.v4.new_notebook(cells=cells)
    nb.metadata.update(
        {
            "colab": {"name": "TACL factorization", "provenance": []},
            "kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
            "language_info": {"name": "python"},
        }
    )
    return nb


COMMON_SETUP = r'''
from google.colab import drive, files
drive.mount('/content/drive')

from pathlib import Path
import json, shutil, subprocess, sys

PROJECT_DIR = Path('/content/drive/MyDrive/tacl_factorization')
PROJECT_DIR.mkdir(parents=True, exist_ok=True)
HARNESS_ZIP = PROJECT_DIR / 'TACL_Expansion_Harness_v4_5.zip'
REPO_DIR = Path('/content/causal_factorization')

if not HARNESS_ZIP.exists():
    print('Upload TACL_Expansion_Harness_v4_5.zip once; it will be retained in Drive.')
    uploaded = files.upload()
    names = [name for name in uploaded if name.endswith('.zip')]
    if not names:
        raise RuntimeError('No harness ZIP was uploaded.')
    shutil.copy2(names[0], HARNESS_ZIP)

if not REPO_DIR.exists():
    subprocess.check_call([
        'git', 'clone', '--depth', '1',
        'https://github.com/bilkentli88/causal_factorization', str(REPO_DIR)
    ])

subprocess.check_call([
    sys.executable, '-m', 'pip', 'install', '-q',
    str(HARNESS_ZIP), str(REPO_DIR / 'code/fragburden0.3.0.zip')
])
# A previous notebook may have imported an older harness in this same runtime.
# Evict only this package so subsequent imports use the just-installed version.
for module_name in list(sys.modules):
    if module_name == 'tacl_factorization' or module_name.startswith('tacl_factorization.'):
        del sys.modules[module_name]
import importlib
importlib.invalidate_caches()
print('Setup complete.')
'''


qwen_cells = [
    md('''
    # Qwen v061 reproduction gate

    This notebook has two deliberately separate stages:

    1. a CPU-only exact reconstruction of every reported Qwen v061 mean and
       95% trial-cluster bootstrap interval from the committed raw rows; and
    2. an **opt-in** GPU rerun under the frozen historical inference contract.

    The GPU stage defaults to off. A partial smoke run is not treated as a
    scientific replication. Re-running the notebook is safe because the JSONL
    ledger skips completed deterministic result IDs.
    '''),
    code(COMMON_SETUP),
    code(r'''
from tacl_factorization.config import assert_frozen, config_hash, load_config
from tacl_factorization.statistics import (
    canonical_metrics, compare_reported, load_jsonl, summarize_factorial
)

CONFIG_PATH = REPO_DIR.parent / 'qwen_v061_reproduction.json'
if not CONFIG_PATH.exists():
    # Extract the installed harness solely to expose its frozen JSON files.
    EXTRACTED = Path('/content/tacl_harness_files')
    if EXTRACTED.exists(): shutil.rmtree(EXTRACTED)
    shutil.unpack_archive(str(HARNESS_ZIP), str(EXTRACTED))
    candidates = list(EXTRACTED.rglob('qwen_v061_reproduction.json'))
    if len(candidates) != 1: raise RuntimeError('Could not locate frozen Qwen config.')
    CONFIG_PATH = candidates[0]

cfg = load_config(CONFIG_PATH)
assert_frozen(cfg)
print('Frozen config hash:', config_hash(cfg))
print(json.dumps(cfg, indent=2))
'''),
    code(r'''
RAW = REPO_DIR / 'data/qwen/v061_factorial_4k8k.jsonl'
EXPECTED = json.loads((REPO_DIR / 'config/reported_results.json').read_text())['qwen_v061']
frame = load_jsonl(RAW)
observed = summarize_factorial(frame, reps=cfg['bootstrap']['reps'])
mismatches = compare_reported(observed, EXPECTED)
metrics = canonical_metrics(frame)
assert metrics['canonical_accuracy'] == EXPECTED['canonical_accuracy']
assert metrics['canonical_max_pred_share'] == EXPECTED['canonical_max_pred_share']
assert not mismatches, '\n'.join(mismatches)
print(json.dumps({'metrics': metrics, 'effects': observed}, indent=2))
print('PASS: every v061 mean and confidence interval reproduces exactly.')
'''),
    md('''
    ## Optional GPU rerun

    Set `RUN_GPU_RERUN=True`. Leave `RUN_FULL_GRID=False` for a four-row
    engineering smoke test; set it to `True` only when you intend to rerun all
    512 historical rows. Results are written to Drive and resume automatically.
    A full rerun should use the same GPU class/environment recorded in the
    audit because low-bit kernels can vary across hardware/software versions.
    '''),
    code(r'''
RUN_GPU_RERUN = False
RUN_FULL_GRID = False

if not RUN_GPU_RERUN:
    print('GPU rerun skipped (default). CPU historical gate is complete.')
'''),
    code(r'''
if RUN_GPU_RERUN:
    subprocess.check_call([
        sys.executable, '-m', 'pip', 'install', '-q', '-U',
        'transformers==5.15.1', 'accelerate', 'bitsandbytes', 'tokenizers'
    ])

    import functools, inspect, torch, transformers
    from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
    from fragburden.dial import FragmentationDial, verify_monotone
    from fragburden.testing import sample_texts
    from tacl_factorization.adapters import HFChatAdapter
    from tacl_factorization.experiment import run_symbolic_factorial
    from tacl_factorization.scoring import score_qwen_chunked_v061

    assert transformers.__version__ == cfg['transformers_version']
    assert torch.cuda.is_available()
    tokenizer = AutoTokenizer.from_pretrained(cfg['model'], use_fast=True)
    bnb = BitsAndBytesConfig(
        load_in_4bit=True, bnb_4bit_quant_type='nf4',
        bnb_4bit_compute_dtype=torch.float16, bnb_4bit_use_double_quant=True
    )
    model = AutoModelForCausalLM.from_pretrained(
        cfg['model'], quantization_config=bnb, device_map='auto',
        attn_implementation='sdpa', dtype=torch.float16
    ).eval()
    if hasattr(model.config, 'use_cache'): model.config.use_cache = False
    assert 'position_ids' in inspect.signature(model.model.forward).parameters

    dial = FragmentationDial.from_transformers(tokenizer, name=cfg['model'])
    gate = verify_monotone(
        dial, sample_texts('en') + sample_texts('tr'), levels=(100, 50, 25, 10, 5, 2, 1)
    )
    assert gate['monotone_nondecreasing'] and gate['all_in_vocab']
    adapter = HFChatAdapter(
        tokenizer=tokenizer,
        base_dial=dial.at(100),
        fragmented_dials={
            language: dial.at(cfg['frag_keep_by_language'][language])
            for language in cfg['filler_languages']
        },
        chat_kwargs=cfg['chat_kwargs'],
    )
    scorer = functools.partial(score_qwen_chunked_v061, chunk_size=cfg['prefill_chunk'])
    output = PROJECT_DIR / 'qwen_v061_gpu_rerun.jsonl'
    new_rows = run_symbolic_factorial(
        cfg, adapter, model, output, scorer,
        limit_new_rows=None if RUN_FULL_GRID else 4,
    )
    print('New rows:', new_rows, 'Output:', output)
'''),
    code(r'''
if RUN_GPU_RERUN:
    rerun = load_jsonl(PROJECT_DIR / 'qwen_v061_gpu_rerun.jsonl')
    print('Rows present:', len(rerun), '/', cfg['expected_rows'])
    if len(rerun) == cfg['expected_rows']:
        rerun_summary = summarize_factorial(rerun, reps=cfg['bootstrap']['reps'])
        print(json.dumps(rerun_summary, indent=2))
        print('Full rerun complete. Compare effect signs and intervals; exact low-bit logits may be hardware-specific.')
    else:
        print('Engineering-only partial run: no scientific effect summary produced.')
'''),
]


phi_cells = [
    md('''
    # Phi-4-mini engineering qualification v1.1 — outcome-independent

    This notebook decides whether `microsoft/Phi-4-mini-instruct` is technically
    eligible for the pre-frozen TACL factorial. It uses tokenizer structure,
    token-count inflation, geometry invariants, deterministic repeat scoring,
    and **canonical-only** task accuracy. It never summarizes `CE`, `FC`, or
    `FE` outcomes.

    Version 1.1 records Protocol Amendment 01: the canonical threshold is
    anchored to the weakest canonical substrate already reported in the paper,
    rather than requiring an inconsistent 32/32. If a gate fails, retain the
    audit and stop. Do not tune on factorial results.
    '''),
    code(COMMON_SETUP),
    code(r'''
subprocess.check_call([
    sys.executable, '-m', 'pip', 'install', '-q', '-U',
    'transformers==5.15.1', 'accelerate', 'bitsandbytes', 'tokenizers'
])

from tacl_factorization.config import assert_frozen, config_hash, load_config

EXTRACTED = Path('/content/tacl_harness_files')
if EXTRACTED.exists(): shutil.rmtree(EXTRACTED)
shutil.unpack_archive(str(HARNESS_ZIP), str(EXTRACTED))
candidates = list(EXTRACTED.rglob('phi_engineering_v1_1.json'))
if len(candidates) != 1: raise RuntimeError('Could not locate frozen Phi config.')
cfg = load_config(candidates[0])
assert_frozen(cfg)
print('Frozen config hash:', config_hash(cfg))
print(json.dumps(cfg, indent=2))
'''),
    code(r'''
import hashlib, inspect, platform
import numpy as np
import pandas as pd
import torch, transformers
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
from fragburden.dial import FragmentationDial, verify_monotone
from fragburden.testing import sample_texts
from tacl_factorization.adapters import HFChatAdapter, build_user_encoding
from tacl_factorization.generator import build_instance
from tacl_factorization.geometry import assemble_factorial
from tacl_factorization.qualification import static_model_checks, select_fragmentation_keep
from tacl_factorization.results import JsonlLedger, read_jsonl
from tacl_factorization.scoring import flatten_score, score_one_shot

assert torch.cuda.is_available(), 'Select a GPU runtime.'
assert transformers.__version__ == cfg['transformers_version']
tokenizer = AutoTokenizer.from_pretrained(cfg['model'], use_fast=True)
bnb = BitsAndBytesConfig(
    load_in_4bit=True, bnb_4bit_quant_type='nf4',
    bnb_4bit_compute_dtype=torch.bfloat16, bnb_4bit_use_double_quant=True
)
model = AutoModelForCausalLM.from_pretrained(
    cfg['model'], quantization_config=bnb, device_map='auto',
    attn_implementation='sdpa', dtype=torch.bfloat16
).eval()
if hasattr(model.config, 'use_cache'): model.config.use_cache = False

static_gate = static_model_checks(model, tokenizer, cfg['required_context'])
print(json.dumps(static_gate, indent=2))
assert static_gate['passed'], 'STATIC MODEL GATE FAILED'
'''),
    code(r'''
dial = FragmentationDial.from_transformers(tokenizer, name=cfg['model'])
capability = dial.capability()
dial_gate = verify_monotone(
    dial, sample_texts('en') + sample_texts('tr'),
    levels=(100, *cfg['candidate_keep_pct'])
)
print(json.dumps({'capability': capability, 'dial_gate': dial_gate}, indent=2))
assert capability['usable_for_arm_a']
assert dial_gate['monotone_nondecreasing'] and dial_gate['all_in_vocab']

d100 = dial.at(100)
# Shell does not depend on the selected dial. Temporary identity dials are used here.
shell_adapter = HFChatAdapter(
    tokenizer, d100, {'en': d100, 'tr': d100}, cfg['chat_kwargs']
)
'''),
    code(r'''
scan_path = PROJECT_DIR / 'phi_engineering_fragmentation_scan.jsonl'
scan = JsonlLedger(scan_path)

for language in cfg['filler_languages']:
    for target_tokens in cfg['target_lengths']:
        for trial_index, semantic_seed in enumerate(cfg['calibration_seeds']):
            instance = build_instance(
                language, semantic_seed, trial_index, target_tokens,
                shell_adapter.count_chat_tokens, shell_adapter.verify_chat_shell,
                cfg['n_records'],
            )
            for keep in cfg['candidate_keep_pct']:
                rid = hashlib.sha256(
                    f"phi-calibration-v1|{language}|{target_tokens}|{semantic_seed}|{trial_index}|{keep}".encode()
                ).hexdigest()[:24]
                if rid in scan.ids: continue
                encoding = build_user_encoding(instance, tokenizer, d100, dial.at(keep))
                canonical_tokens = len(shell_adapter.prefix_ids) + len(encoding.canonical_ids) + len(shell_adapter.suffix_ids)
                fragmented_tokens = len(shell_adapter.prefix_ids) + len(encoding.fragmented_ids) + len(shell_adapter.suffix_ids)
                scan.append({
                    'result_id': rid, 'filler_language': language,
                    'target_chat_tokens': target_tokens, 'semantic_seed': semantic_seed,
                    'trial_index': trial_index, 'keep_pct': keep,
                    'canonical_tokens': canonical_tokens,
                    'fragmented_tokens': fragmented_tokens,
                    'inflation_ratio': fragmented_tokens / canonical_tokens,
                    'dial_fingerprint': dial.at(keep).fingerprint,
                })

scan_rows = read_jsonl(scan_path)
selections = {}
for language in cfg['filler_languages']:
    language_rows = [row for row in scan_rows if row['filler_language'] == language]
    selections[language] = select_fragmentation_keep(
        language_rows,
        target_ratio=cfg['target_fragmentation_ratio'],
        acceptable=tuple(cfg['acceptable_per_cell_ratio']),
    )
print(json.dumps(selections, indent=2))
assert all(item['passed'] for item in selections.values()), 'FRAGMENTATION CALIBRATION GATE FAILED'
selected_keep = {language: result['selected']['keep_pct'] for language, result in selections.items()}
'''),
    code(r'''
selected_adapter = HFChatAdapter(
    tokenizer, d100,
    {language: dial.at(selected_keep[language]) for language in cfg['filler_languages']},
    cfg['chat_kwargs'],
)

geometry_audit = []
canonical_conditions = []
for language in cfg['filler_languages']:
    for target_tokens in cfg['target_lengths']:
        instance = build_instance(
            language, cfg['calibration_seeds'][0], 0, target_tokens,
            selected_adapter.count_chat_tokens, selected_adapter.verify_chat_shell,
            cfg['n_records'],
        )
        encoding = selected_adapter.encode_instance(instance)
        factorial = assemble_factorial(
            selected_adapter.prefix_ids, selected_adapter.suffix_ids, encoding
        )
        geometry_audit.append({
            'language': language, 'target_tokens': target_tokens,
            'CC_FC_gap_difference': factorial['CC'].gaps['evidence_readout'] - factorial['FC'].gaps['evidence_readout'],
            'CE_FE_gap_difference': factorial['CE'].gaps['evidence_readout'] - factorial['FE'].gaps['evidence_readout'],
            'expanded_minus_source_gap': factorial['FE'].gaps['evidence_readout'] - factorial['FC'].gaps['evidence_readout'],
        })
print(pd.DataFrame(geometry_audit))
'''),
    md('''
    ## Canonical-only scoring gate

    This stage scores only `CC`. The first item is scored twice to check
    deterministic one-shot inference. No factorial contrast can be calculated
    from this file.
    '''),
    code(r'''
canonical_path = PROJECT_DIR / 'phi_engineering_canonical_gate.jsonl'
canonical_ledger = JsonlLedger(canonical_path)

for language in cfg['filler_languages']:
    for target_tokens in cfg['target_lengths']:
        for trial_index, semantic_seed in enumerate(cfg['calibration_seeds']):
            instance = build_instance(
                language, semantic_seed, trial_index, target_tokens,
                selected_adapter.count_chat_tokens, selected_adapter.verify_chat_shell,
                cfg['n_records'],
            )
            encoding = selected_adapter.encode_instance(instance)
            condition = assemble_factorial(
                selected_adapter.prefix_ids, selected_adapter.suffix_ids, encoding
            )['CC']
            rid = hashlib.sha256(
                f"phi-canonical-v1|{language}|{target_tokens}|{semantic_seed}|{trial_index}".encode()
            ).hexdigest()[:24]
            if rid in canonical_ledger.ids: continue
            score = score_one_shot(
                model, condition, instance.gold_digit, selected_adapter.digit_ids, tokenizer
            )
            canonical_ledger.append({
                'result_id': rid, 'filler_language': language,
                'target_chat_tokens': target_tokens, 'semantic_seed': semantic_seed,
                'trial_index': trial_index, 'gold_digit': instance.gold_digit,
                'ids_hash': condition.ids_hash, 'position_hash': condition.position_hash,
                **flatten_score(score),
            })

# Repeat one frozen audit item on every notebook execution, including resumed runs.
repeat_instance = build_instance(
    cfg['filler_languages'][0], cfg['calibration_seeds'][0], 0, cfg['target_lengths'][0],
    selected_adapter.count_chat_tokens, selected_adapter.verify_chat_shell, cfg['n_records'],
)
repeat_encoding = selected_adapter.encode_instance(repeat_instance)
repeat_condition = assemble_factorial(
    selected_adapter.prefix_ids, selected_adapter.suffix_ids, repeat_encoding
)['CC']
repeat_a = score_one_shot(
    model, repeat_condition, repeat_instance.gold_digit, selected_adapter.digit_ids, tokenizer
)
repeat_b = score_one_shot(
    model, repeat_condition, repeat_instance.gold_digit, selected_adapter.digit_ids, tokenizer
)
repeat_max_logit_diff = max(
    abs(repeat_a['candidate_logits'][d] - repeat_b['candidate_logits'][d]) for d in '1234'
)

canonical_rows = read_jsonl(canonical_path)
canonical_frame = pd.DataFrame(canonical_rows)
overall_correct = int(canonical_frame['correct'].sum())
canonical_accuracy = overall_correct / len(canonical_frame)
cell_table = canonical_frame.groupby(
    ['filler_language', 'target_chat_tokens'], as_index=False
).agg(correct=('correct', 'sum'), n=('correct', 'size'))
cell_table['accuracy'] = cell_table['correct'] / cell_table['n']
max_predicted_digit_share = float(
    canonical_frame['predicted_digit'].value_counts(normalize=True).max()
)
gate = cfg['canonical_gate']
canonical_gate_checks = {
    'row_count': len(canonical_rows) == gate['total_instances'],
    'overall_correct': overall_correct >= gate['minimum_overall_correct'],
    'per_cell_correct': bool(
        (cell_table['correct'] >= gate['minimum_per_language_length_cell_correct']).all()
    ),
    'response_balance': max_predicted_digit_share <= gate['maximum_predicted_digit_share'],
    'deterministic_repeat': (
        repeat_max_logit_diff <= gate['maximum_repeat_candidate_logit_difference']
    ),
}
canonical_gate_passed = all(canonical_gate_checks.values())

print('Canonical rows:', len(canonical_rows), 'correct:', overall_correct, 'accuracy:', canonical_accuracy)
display(cell_table)
print('Maximum predicted-digit share:', max_predicted_digit_share)
print('Repeat max candidate-logit difference:', repeat_max_logit_diff)
print('Gate checks:', json.dumps(canonical_gate_checks, indent=2))
print('Canonical gate passed:', canonical_gate_passed)
'''),
    code(r'''
audit = {
    'protocol_version': cfg['protocol_version'],
    'config_hash': config_hash(cfg),
    'model': cfg['model'],
    'transformers': transformers.__version__,
    'torch': torch.__version__,
    'gpu': torch.cuda.get_device_name(0),
    'static_gate': static_gate,
    'dial_capability': capability,
    'dial_gate': dial_gate,
    'fragmentation_selections': selections,
    'selected_keep_by_language': selected_keep,
    'geometry_audit': geometry_audit,
    'canonical_rows': len(canonical_rows),
    'canonical_correct': overall_correct,
    'canonical_accuracy': canonical_accuracy,
    'canonical_cell_table': cell_table.to_dict(orient='records'),
    'maximum_predicted_digit_share': max_predicted_digit_share,
    'repeat_max_candidate_logit_diff': repeat_max_logit_diff,
    'canonical_gate_checks': canonical_gate_checks,
    'passed': canonical_gate_passed,
    'factorial_outcomes_accessed': False,
}
audit_path = PROJECT_DIR / 'phi_engineering_audit.json'
audit_path.write_text(json.dumps(audit, indent=2, ensure_ascii=False))
print('Audit saved:', audit_path)
if not canonical_gate_passed:
    raise AssertionError('AMENDED CANONICAL TASK GATE FAILED; inspect the saved audit.')
print('QUALIFICATION PASSED. Selected keep values:', selected_keep)
print('The confirmatory factorial remains a separate future run; no such outcomes were accessed here.')
'''),
]


# Mistral uses the same qualification machinery, but every configuration and
# Drive output name is separate.  The scientific threshold is frozen before
# any Mistral outcome; unlike Phi v1.1, this is not a post-canonical amendment.
mistral_cells = copy.deepcopy(phi_cells)
mistral_cells[0].source = dedent('''
    # Mistral engineering qualification v1 — outcome-independent

    This notebook decides whether `mistralai/Mistral-7B-Instruct-v0.3` is
    technically eligible for the pre-frozen TACL factorial. It uses tokenizer
    structure, token-count inflation, geometry invariants, deterministic repeat
    scoring, and **canonical-only** task accuracy. It never summarizes `CE`,
    `FC`, or `FE` outcomes.

    The canonical thresholds were frozen before any Mistral outcome and use
    the same historical anchor applied across models. If a gate fails, retain
    the audit and stop; do not tune on factorial results.
''').strip()
_mistral_replacements = {
    "phi_engineering_v1_1.json": "mistral_engineering_v1_1.json",
    "frozen Phi config": "frozen Mistral config",
    "Frozen Phi config": "Frozen Mistral config",
    "phi_engineering_fragmentation_scan.jsonl": "mistral_engineering_fragmentation_scan_tokenwise_v1.jsonl",
    "phi-calibration-v1": "mistral-calibration-tokenwise-v1",
    "phi_engineering_canonical_gate.jsonl": "mistral_engineering_canonical_gate.jsonl",
    "phi-canonical-v1": "mistral-canonical-v1",
    "phi_engineering_audit.json": "mistral_engineering_audit.json",
}
for _cell in mistral_cells[1:]:
    for _old, _new in _mistral_replacements.items():
        _cell.source = _cell.source.replace(_old, _new)

mistral_cells[5].source = mistral_cells[5].source.replace(
    "scan = JsonlLedger(scan_path)",
    "scan = JsonlLedger(scan_path)\n\n"
    "scan_adapters = {\n"
    "    (language, keep): HFChatAdapter(\n"
    "        tokenizer=tokenizer, base_dial=d100,\n"
    "        fragmented_dials={language: dial.at(keep)},\n"
    "        chat_kwargs=cfg['chat_kwargs'],\n"
    "        answer_prefix_ids=cfg['answer_prefix_ids'],\n"
    "        candidate_token_ids=cfg['candidate_token_ids'],\n"
    "    )\n"
    "    for language in cfg['filler_languages']\n"
    "    for keep in cfg['candidate_keep_pct']\n"
    "}",
)
mistral_cells[5].source = mistral_cells[5].source.replace(
    "encoding = build_user_encoding(instance, tokenizer, d100, dial.at(keep))",
    "scan_adapter = scan_adapters[(language, keep)]\n"
    "                encoding = scan_adapter.encode_instance(instance)\n"
    "                assert scan_adapter.last_encoding_strategy == 'canonical_token_offsets_v1'",
)
mistral_cells[5].source = mistral_cells[5].source.replace(
    "'dial_fingerprint': dial.at(keep).fingerprint,",
    "'dial_fingerprint': dial.at(keep).fingerprint,\n"
    "                    'encoding_strategy': scan_adapter.last_encoding_strategy,",
)

_contextual_gate_code = r'''
def _normalise_probe_ids(value):
    if hasattr(value, 'keys') and 'input_ids' in value:
        value = value['input_ids']
    if hasattr(value, 'detach'):
        value = value.detach().cpu().tolist()
    if (
        isinstance(value, (list, tuple)) and len(value) == 1
        and isinstance(value[0], (list, tuple))
    ):
        value = value[0]
    return [int(item) for item in value]

probe_messages = [{
    'role': 'user',
    'content': (
        'K12345=1\nK23456=2\nK34567=3\nK45678=4\n'
        'QUERY KEY: K12345\nAnswer with one digit only:'
    ),
}]
probe_prompt = _normalise_probe_ids(tokenizer.apply_chat_template(
    probe_messages, tokenize=True, add_generation_prompt=True, return_dict=True
))
contextual_completions = {}
for digit in '1234':
    full = _normalise_probe_ids(tokenizer.apply_chat_template(
        probe_messages + [{'role': 'assistant', 'content': digit}],
        tokenize=True, add_generation_prompt=False, return_dict=True
    ))
    if full[:len(probe_prompt)] != probe_prompt:
        raise RuntimeError(f'{digit}: assistant completion does not extend generation prompt.')
    continuation = full[len(probe_prompt):]
    expected = (
        list(cfg['answer_prefix_ids'])
        + [cfg['candidate_token_ids'][digit]]
        + [cfg['assistant_eos_id']]
    )
    if continuation != expected:
        raise RuntimeError(f'{digit}: contextual completion {continuation} != frozen {expected}')
    contextual_completions[digit] = continuation

static_gate = static_model_checks(
    model, tokenizer, cfg['required_context'],
    candidate_token_ids=cfg['candidate_token_ids'],
)
static_gate['contextual_completions'] = contextual_completions
static_gate['contextual_completion_gate'] = True
static_gate['passed'] = static_gate['passed'] and static_gate['contextual_completion_gate']
'''.strip()
mistral_cells[3].source = mistral_cells[3].source.replace(
    "static_gate = static_model_checks(model, tokenizer, cfg['required_context'])",
    _contextual_gate_code,
)
mistral_cells[3].source = mistral_cells[3].source.replace(
    "tokenizer = AutoTokenizer.from_pretrained(cfg['model'], use_fast=True)",
    "import gc\n"
    "if 'model' in globals():\n"
    "    del model\n"
    "    gc.collect()\n"
    "    torch.cuda.empty_cache()\n"
    "tokenizer = AutoTokenizer.from_pretrained(cfg['model'], use_fast=True)",
)
mistral_cells[2].source += r'''

import tacl_factorization
assert tacl_factorization.__version__ == '0.4.5', (
    f"Stale harness loaded: {tacl_factorization.__version__}; expected 0.4.5"
)
assert cfg['protocol_version'] == 'tacl_mistral_qualification_v1_1'
assert cfg['candidate_token_ids'] == {'1': 29508, '2': 29518, '3': 29538, '4': 29549}
print('PASS: Mistral v1.1 notebook and harness identity verified before model loading.')
'''
mistral_cells[4].source = mistral_cells[4].source.replace(
    "tokenizer, d100, {'en': d100, 'tr': d100}, cfg['chat_kwargs']\n)",
    "tokenizer=tokenizer, base_dial=d100, fragmented_dials={'en': d100, 'tr': d100},\n"
    "    chat_kwargs=cfg['chat_kwargs'], answer_prefix_ids=cfg['answer_prefix_ids'],\n"
    "    candidate_token_ids=cfg['candidate_token_ids'],\n)",
)
mistral_cells[6].source = mistral_cells[6].source.replace(
    "    cfg['chat_kwargs'],\n)",
    "    chat_kwargs=cfg['chat_kwargs'],\n"
    "    answer_prefix_ids=cfg['answer_prefix_ids'],\n"
    "    candidate_token_ids=cfg['candidate_token_ids'],\n)",
)
mistral_cells[6].source += r'''

encoding_strategy = selected_adapter.last_encoding_strategy
assert encoding_strategy == 'canonical_token_offsets_v1'
print('PASS: region labels use the frozen token-offset fallback:', encoding_strategy)
'''
mistral_cells[9].source = mistral_cells[9].source.replace(
    "    'selected_keep_by_language': selected_keep,",
    "    'selected_keep_by_language': selected_keep,\n"
    "    'encoding_strategy': encoding_strategy,",
)


phi_factorial_cells = [
    md('''
    # Phi confirmatory factorial v1 — frozen 512-row run

    This notebook executes the confirmatory token identity × positional
    geometry experiment only after verifying the passed qualification audit.
    The frozen grid contains 32 new semantic seeds × 2 filler languages × 2
    target lengths × 4 conditions = 512 rows.

    Conditions are randomized within each semantic instance. Results are
    append-only and resume-safe. A result file may be resumed only under the
    identical runtime fingerprint. No effect estimate is computed until all
    512 rows and all pairing/geometry gates pass.
    '''),
    code(COMMON_SETUP),
    code(r'''
import hashlib
from tacl_factorization.config import assert_frozen, config_hash, load_config

EXTRACTED = Path('/content/tacl_harness_files')
if EXTRACTED.exists(): shutil.rmtree(EXTRACTED)
shutil.unpack_archive(str(HARNESS_ZIP), str(EXTRACTED))
config_candidates = list(EXTRACTED.rglob('phi_factorial_confirmatory_v1.json'))
if len(config_candidates) != 1: raise RuntimeError('Could not locate frozen Phi factorial config.')
cfg = load_config(config_candidates[0])
assert_frozen(cfg)
print('Frozen factorial config hash:', config_hash(cfg))
print(json.dumps(cfg, indent=2))

qualification_path = PROJECT_DIR / cfg['qualification']['audit_file']
if not qualification_path.exists():
    raise RuntimeError('Run the Phi engineering qualification notebook first.')
qualification_bytes = qualification_path.read_bytes()
qualification_sha = hashlib.sha256(qualification_bytes).hexdigest()
qualification = json.loads(qualification_bytes)
assert qualification_sha == cfg['qualification']['audit_sha256'], 'Qualification audit hash differs.'
assert qualification['config_hash'] == cfg['qualification']['qualification_config_hash']
assert qualification['passed'] is True
assert qualification['factorial_outcomes_accessed'] is False
assert qualification['selected_keep_by_language'] == cfg['frag_keep_by_language']
print('PASS: exact qualification audit verified.')
'''),
    code(r'''
subprocess.check_call([
    sys.executable, '-m', 'pip', 'install', '-q', '-U',
    'transformers==5.15.1', 'accelerate', 'bitsandbytes', 'tokenizers'
])

import torch, transformers
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
from fragburden.dial import FragmentationDial, verify_monotone
from fragburden.testing import sample_texts
from tacl_factorization.adapters import HFChatAdapter
from tacl_factorization.results import read_jsonl

assert torch.cuda.is_available(), 'Select a GPU runtime.'
assert torch.cuda.is_bf16_supported(), 'The frozen BF16 run requires a BF16-capable GPU.'
assert transformers.__version__ == cfg['transformers_version']
tokenizer = AutoTokenizer.from_pretrained(cfg['model'], use_fast=True)
bnb = BitsAndBytesConfig(
    load_in_4bit=True, bnb_4bit_quant_type='nf4',
    bnb_4bit_compute_dtype=torch.bfloat16, bnb_4bit_use_double_quant=True
)
load_kwargs = dict(
    quantization_config=bnb, device_map='auto', attn_implementation='sdpa'
)
try:
    model = AutoModelForCausalLM.from_pretrained(
        cfg['model'], dtype=torch.bfloat16, **load_kwargs
    ).eval()
except TypeError:
    model = AutoModelForCausalLM.from_pretrained(
        cfg['model'], torch_dtype=torch.bfloat16, **load_kwargs
    ).eval()
if hasattr(model.config, 'use_cache'): model.config.use_cache = False

runtime = {
    'model': cfg['model'], 'weights': cfg['weights'],
    'compute_dtype': cfg['compute_dtype'],
    'transformers': transformers.__version__, 'torch': torch.__version__,
    'gpu': torch.cuda.get_device_name(0),
}
runtime_fingerprint = hashlib.sha256(
    json.dumps(runtime, sort_keys=True, separators=(',', ':')).encode()
).hexdigest()[:24]
print(json.dumps(runtime, indent=2))
print('Runtime fingerprint:', runtime_fingerprint)
'''),
    code(r'''
dial = FragmentationDial.from_transformers(tokenizer, name=cfg['model'])
dial_gate = verify_monotone(
    dial, sample_texts('en') + sample_texts('tr'), levels=(100, 2)
)
assert dial_gate['monotone_nondecreasing'] and dial_gate['all_in_vocab']
adapter = HFChatAdapter(
    tokenizer=tokenizer,
    base_dial=dial.at(100),
    fragmented_dials={
        language: dial.at(cfg['frag_keep_by_language'][language])
        for language in cfg['filler_languages']
    },
    chat_kwargs=cfg['chat_kwargs'],
)
assert adapter.digit_ids == qualification['static_gate']['digit_ids']
print('Factorial adapter ready. keep_pct:', cfg['frag_keep_by_language'])
'''),
    code(r'''
RESULTS_PATH = PROJECT_DIR / 'phi_factorial_confirmatory_v1.jsonl'
existing_rows = read_jsonl(RESULTS_PATH)
if existing_rows:
    fingerprints = {row.get('runtime_fingerprint') for row in existing_rows}
    if fingerprints != {runtime_fingerprint}:
        raise RuntimeError(
            'Existing rows were produced under another runtime. Restore that runtime '
            'or start a separately named result file; never mix them.'
        )
print('Existing rows:', len(existing_rows), '/', cfg['expected_rows'])

RUN_CONFIRMATORY_FACTORIAL = False  # Read the frozen config above, then change only this to True.
if not RUN_CONFIRMATORY_FACTORIAL:
    print('Confirmatory run is armed but not started. Set RUN_CONFIRMATORY_FACTORIAL=True.')
'''),
    code(r'''
if RUN_CONFIRMATORY_FACTORIAL:
    from tacl_factorization.experiment import run_symbolic_factorial
    from tacl_factorization.scoring import score_one_shot

    provenance = {
        'factorial_config_hash': config_hash(cfg),
        'qualification_audit_sha256': qualification_sha,
        'runtime_fingerprint': runtime_fingerprint,
        'runtime': runtime,
    }
    new_rows = run_symbolic_factorial(
        config=cfg,
        adapter=adapter,
        model=model,
        output_path=RESULTS_PATH,
        scorer=score_one_shot,
        limit_new_rows=None,
        row_provenance=provenance,
    )
    print('New rows written:', new_rows)
    print('Result file:', RESULTS_PATH)
'''),
    md('''
    ## Locked analysis gate

    This cell refuses to calculate effects from a partial or structurally
    invalid run. Run it only after the execution cell finishes.
    '''),
    code(r'''
from tacl_factorization.statistics import (
    canonical_metrics, factorial_effects, load_jsonl, summarize_factorial,
    validate_factorial_rows,
)
import pandas as pd

rows = load_jsonl(RESULTS_PATH)
print('Rows present:', len(rows), '/', cfg['expected_rows'])
if len(rows) != cfg['expected_rows']:
    print('INCOMPLETE: effect analysis remains locked.')
else:
    validate_factorial_rows(rows)
    assert set(rows['runtime_fingerprint']) == {runtime_fingerprint}
    base = ['filler_language', 'target_chat_tokens', 'semantic_seed', 'trial_index']
    assert (rows.groupby(base)['prompt_sha256'].nunique() == 1).all()
    pair = rows.pivot_table(
        index=base, columns='factorial_code',
        values=['ids_hash', 'evidence_readout_position_gap'], aggfunc='first'
    )
    assert (pair['ids_hash']['CC'] == pair['ids_hash']['CE']).all()
    assert (pair['ids_hash']['FC'] == pair['ids_hash']['FE']).all()
    assert ((pair['evidence_readout_position_gap']['CC'] - pair['evidence_readout_position_gap']['FC']).abs() <= 1e-3).all()
    assert ((pair['evidence_readout_position_gap']['CE'] - pair['evidence_readout_position_gap']['FE']).abs() <= 1e-3).all()
    assert (pair['evidence_readout_position_gap']['FE'] > pair['evidence_readout_position_gap']['FC']).all()
    print('PASS: completeness, same-ID, matched-geometry, prompt, and runtime gates.')

    pooled = summarize_factorial(
        rows, bootstrap_seed=cfg['bootstrap']['seed'], reps=cfg['bootstrap']['reps']
    )
    cells = {}
    for (language, length), group in rows.groupby(['filler_language', 'target_chat_tokens']):
        cells[f'{language}_{int(length)}'] = summarize_factorial(
            group, bootstrap_seed=cfg['bootstrap']['seed'], reps=cfg['bootstrap']['reps']
        )
    summary = {
        'protocol_version': cfg['protocol_version'],
        'factorial_config_hash': config_hash(cfg),
        'qualification_audit_sha256': qualification_sha,
        'runtime_fingerprint': runtime_fingerprint,
        'rows': len(rows),
        'canonical_metrics': canonical_metrics(rows),
        'pooled_effects': pooled,
        'cell_effects': cells,
    }
    SUMMARY_PATH = PROJECT_DIR / 'phi_factorial_confirmatory_v1_summary.json'
    SUMMARY_PATH.write_text(json.dumps(summary, indent=2, ensure_ascii=False))
    display(pd.DataFrame(pooled).T)
    print('Frozen summary:', SUMMARY_PATH)
'''),
]


mistral_factorial_cells = copy.deepcopy(phi_factorial_cells)
mistral_factorial_cells[0].source = dedent('''
    # Mistral confirmatory factorial v1 — frozen 512-row run

    This notebook executes the confirmatory token identity × positional
    geometry experiment only after verifying the exact passed Mistral
    qualification audit. The frozen grid contains 32 fresh semantic seeds × 2
    filler languages × 2 target lengths × 4 conditions = 512 rows.

    Conditions are randomized within each semantic instance. Results are
    append-only and resume-safe. A result file may be resumed only under the
    identical runtime fingerprint. No effect estimate is computed until all
    512 rows and all pairing/geometry gates pass.

    The adapter retains Mistral byte-fallback tokens canonically and uses the
    token-offset evidence/filler/query labels frozen before task scoring.
''').strip()
_mistral_factorial_replacements = {
    "phi_factorial_confirmatory_v1.json": "mistral_factorial_confirmatory_v1.json",
    "phi_factorial_confirmatory_v1.jsonl": "mistral_factorial_confirmatory_v1.jsonl",
    "phi_factorial_confirmatory_v1_summary.json": "mistral_factorial_confirmatory_v1_summary.json",
    "Phi factorial": "Mistral factorial",
    "Phi engineering": "Mistral engineering",
    "Phi": "Mistral",
}
for _cell in mistral_factorial_cells[1:]:
    for _old, _new in _mistral_factorial_replacements.items():
        _cell.source = _cell.source.replace(_old, _new)

mistral_factorial_cells[2].source += r'''

import tacl_factorization
assert tacl_factorization.__version__ == '0.4.5'
assert qualification['static_gate']['region_labeling'] == cfg['region_labeling']
assert qualification['static_gate']['byte_fallback_policy'] == cfg['byte_fallback_policy']
assert qualification['static_gate']['shell_extraction'] == cfg['chat_shell_extraction']
assert qualification['static_gate']['digit_ids'] == cfg['candidate_token_ids']
print('PASS: Mistral tokenizer and readout corrections are audit-bound.')
'''
mistral_factorial_cells[4].source = mistral_factorial_cells[4].source.replace(
    "    chat_kwargs=cfg['chat_kwargs'],\n)",
    "    chat_kwargs=cfg['chat_kwargs'],\n"
    "    answer_prefix_ids=cfg['answer_prefix_ids'],\n"
    "    candidate_token_ids=cfg['candidate_token_ids'],\n)",
)
mistral_factorial_cells[4].source += r'''

from tacl_factorization.generator import build_instance
from tacl_factorization.geometry import assemble_factorial

probe_instance = build_instance(
    filler_language=cfg['filler_languages'][0],
    semantic_seed=cfg['semantic_seeds'][0],
    trial_index=0,
    target_chat_tokens=cfg['target_lengths'][0],
    count_chat_tokens=adapter.count_chat_tokens,
    verify_chat_shell=adapter.verify_chat_shell,
    n_records=cfg['n_records'],
)
probe_encoding = adapter.encode_instance(probe_instance)
assert adapter.last_encoding_strategy == cfg['region_labeling']
probe_factorial = assemble_factorial(
    adapter.prefix_ids, adapter.suffix_ids, probe_encoding
)
assert probe_factorial['CC'].ids_hash == probe_factorial['CE'].ids_hash
assert probe_factorial['FC'].ids_hash == probe_factorial['FE'].ids_hash
assert probe_factorial['CC'].gaps['evidence_readout'] == probe_factorial['FC'].gaps['evidence_readout']
assert probe_factorial['CE'].gaps['evidence_readout'] == probe_factorial['FE'].gaps['evidence_readout']
print('PASS: pre-outcome Mistral adapter and geometry probe.')
'''
mistral_factorial_cells[3].source = mistral_factorial_cells[3].source.replace(
    "    'model': cfg['model'], 'weights': cfg['weights'],",
    "    'model': cfg['model'], 'weights': cfg['weights'],\n"
    "    'harness_version': tacl_factorization.__version__,\n"
    "    'region_labeling': cfg['region_labeling'],\n"
    "    'byte_fallback_policy': cfg['byte_fallback_policy'],",
)
mistral_factorial_cells[4].source = mistral_factorial_cells[4].source.replace(
    "    dial, sample_texts('en') + sample_texts('tr'), levels=(100, 2)",
    "    dial, sample_texts('en') + sample_texts('tr'),\n"
    "    levels=(100, *sorted(set(cfg['frag_keep_by_language'].values()), reverse=True))",
)


outputs = {
    ROOT / "notebooks/01_qwen_v061_reproduction_gate.ipynb": notebook(qwen_cells),
    ROOT / "notebooks/02_phi_engineering_qualification.ipynb": notebook(phi_cells),
    ROOT / "notebooks/03_phi_confirmatory_factorial.ipynb": notebook(phi_factorial_cells),
    ROOT / "notebooks/04_mistral_engineering_qualification_v1_1_r4.ipynb": notebook(mistral_cells),
    ROOT / "notebooks/05_mistral_confirmatory_factorial.ipynb": notebook(mistral_factorial_cells),
}
for path, nb in outputs.items():
    path.parent.mkdir(parents=True, exist_ok=True)
    nbf.write(nb, path)
    print(path)
