# Implementation Note 02: token-offset region labeling

**Frozen:** 2026-09-13, before any Mistral canonical or factorial task score
was produced or inspected.

## Trigger

The Mistral engineering notebook passed its model, contextual-candidate,
fragmentation-dial, chat-shell, and inflation-calibration stages. Geometry
assembly then stopped before scoring because the tokenizer backend exposed the
whole user message as a single pre-tokenization chunk. A single chunk cannot
represent the required evidence, filler, and query labels.

## Correction

When pre-tokenization chunks do not cover all three semantic regions, the
adapter now uses the token-offset construction already used in the frozen Gemma
v071 experiment:

1. obtain canonical token IDs and official character offsets from the fast
   tokenizer;
2. label each canonical token by maximum overlap with the frozen semantic
   spans;
3. fragment only canonical tokens lying fully inside the filler span;
4. leave boundary, evidence, and query tokens canonical; and
5. assign fragments of canonical token `i` the positions
   `i + rank / number_of_fragments`.

Canonical and fragmented sequences must decode identically, every fragmented
piece must remain in the canonical vocabulary, source positions must be
strictly increasing, and all three semantic labels must be present.

## Scientific status

This is an implementation correction, not an outcome-driven protocol change.
It does not alter prompts, seeds, model weights, candidate answers,
fragmentation targets, qualification thresholds, or the factorial estimand.
No Mistral task score or factorial contrast had been accessed when it was made.
