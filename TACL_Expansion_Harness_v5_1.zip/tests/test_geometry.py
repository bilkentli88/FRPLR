import numpy as np
import pytest

from tacl_factorization.geometry import (
    UserEncoding,
    assemble_factorial,
    fractional_local_positions,
)


def test_fractional_local_positions_match_v061_definition():
    observed = fractional_local_positions(["ab", "cde"], ["a", "b", "c", "d", "e"])
    expected = np.asarray([0.0, 0.5, 1.0, 4 / 3, 5 / 3], dtype=np.float32)
    np.testing.assert_array_equal(observed, expected)


def test_crossing_a_canonical_boundary_is_rejected():
    with pytest.raises(ValueError, match="crossed"):
        fractional_local_positions(["ab", "cd"], ["abc", "d"])


def test_factorial_same_id_and_matched_geometry_invariants():
    encoding = UserEncoding(
        canonical_ids=(10, 11, 12, 13, 14, 15, 16, 17),
        fragmented_ids=(10, 11, 120, 121, 130, 140, 141, 15, 16, 17),
        canonical_labels=("evidence", "evidence", "filler", "filler", "filler", "query", "query", "query"),
        fragmented_labels=("evidence", "evidence", "filler", "filler", "filler", "filler", "filler", "query", "query", "query"),
        fragmented_source_positions=(0.0, 1.0, 2.0, 2.5, 3.0, 4.0, 4.5, 5.0, 6.0, 7.0),
    )
    factorial = assemble_factorial((1, 2), (3, 4), encoding)
    assert factorial["CC"].ids_hash == factorial["CE"].ids_hash
    assert factorial["FC"].ids_hash == factorial["FE"].ids_hash
    assert factorial["CC"].gaps["evidence_readout"] == factorial["FC"].gaps["evidence_readout"]
    assert factorial["CE"].gaps["evidence_readout"] == factorial["FE"].gaps["evidence_readout"]
    assert factorial["FE"].gaps["evidence_readout"] > factorial["FC"].gaps["evidence_readout"]

