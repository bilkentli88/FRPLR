from tacl_factorization.adapters import HFChatAdapter
from tacl_factorization.qualification import static_model_checks


class _Config:
    model_type = "mistral"
    max_position_embeddings = 32768


class _Backbone:
    def forward(self, input_ids=None, position_ids=None):
        return None


class _Model:
    config = _Config()
    model = _Backbone()


class _Tokenizer:
    def __call__(self, text, add_special_tokens=False):
        if text == "<p>":
            # Deliberately differs from the official chat-template prefix;
            # re-tokenizing rendered shell text would therefore be wrong.
            return {"input_ids": [777]}
        if text == "</p>":
            return {"input_ids": [11]}
        if text in "1234":
            return {"input_ids": [29473, 29500 + int(text)]}
        return {"input_ids": [99]}

    def apply_chat_template(self, messages, tokenize, add_generation_prompt, **kwargs):
        rendered = "<p>" + messages[0]["content"] + "</p>"
        if not tokenize:
            return rendered
        return {"input_ids": [10, 99, 11]}


def test_contextual_candidate_override_passes_static_gate():
    tokenizer = _Tokenizer()
    assert not static_model_checks(_Model(), tokenizer)["digit_gate"]
    candidates = {"1": 29508, "2": 29518, "3": 29538, "4": 29549}
    result = static_model_checks(_Model(), tokenizer, candidate_token_ids=candidates)
    assert result["passed"]
    assert result["digit_ids"] == candidates


def test_answer_prefix_becomes_common_readout_suffix():
    candidates = {"1": 29508, "2": 29518, "3": 29538, "4": 29549}
    adapter = HFChatAdapter(
        tokenizer=_Tokenizer(),
        base_dial=None,
        fragmented_dials={},
        chat_kwargs={},
        answer_prefix_ids=[29473],
        candidate_token_ids=candidates,
        marker="MARKER",
    )
    assert adapter.official_suffix_ids == (11,)
    assert adapter.prefix_ids == (10,)
    assert adapter.suffix_ids == (11, 29473)
    assert adapter.shell_extraction == "official_token_subsequence_v1"
    assert adapter.digit_ids == candidates


class _RenderedBoundaryTokenizer:
    def __call__(self, text, add_special_tokens=False):
        table = {"<p>": [10], "</p>": [11], "MARKER": [98], "1": [1], "2": [2], "3": [3], "4": [4]}
        return {"input_ids": table[text]}

    def apply_chat_template(self, messages, tokenize, add_generation_prompt, **kwargs):
        rendered = "<p>" + messages[0]["content"] + "</p>"
        if not tokenize:
            return rendered
        content = messages[0]["content"]
        return {"input_ids": [10, *self(content, add_special_tokens=False)["input_ids"], 11]}


def test_rendered_text_boundary_shell_matches_gemma_v071_contract():
    adapter = HFChatAdapter(
        tokenizer=_RenderedBoundaryTokenizer(),
        base_dial=None,
        fragmented_dials={},
        chat_kwargs={},
        shell_extraction="rendered_text_boundary_v071",
        marker="MARKER",
    )
    assert adapter.prefix_ids == (10,)
    assert adapter.official_suffix_ids == (11,)
    assert adapter.shell_extraction == "rendered_text_boundary_v071"
