import json

from tacl_factorization.results import JsonlLedger, read_jsonl, repair_torn_final_line


def test_resume_skips_duplicate_and_repairs_torn_line(tmp_path):
    path = tmp_path / "run.jsonl"
    ledger = JsonlLedger(path)
    assert ledger.append({"result_id": "a", "value": 1})
    assert not ledger.append({"result_id": "a", "value": 999})
    with path.open("ab") as handle:
        handle.write(b'{"result_id":"broken"')
    assert repair_torn_final_line(path)
    assert read_jsonl(path) == [{"result_id": "a", "value": 1}]
    resumed = JsonlLedger(path)
    assert resumed.append({"result_id": "b", "value": 2})
    assert [row["result_id"] for row in read_jsonl(path)] == ["a", "b"]


def test_valid_final_line_without_newline_is_preserved(tmp_path):
    path = tmp_path / "run.jsonl"
    path.write_text(json.dumps({"result_id": "a"}), encoding="utf-8")
    assert repair_torn_final_line(path)
    assert read_jsonl(path) == [{"result_id": "a"}]

