# Protocol amendment 01: canonical qualification threshold

Amendment date: 2026-09-12 UTC  
Applies to: Phi engineering qualification only  
Timing: after canonical-only qualification results, before any Phi `CE`, `FC`,
or `FE` outcome was generated or inspected

## What happened

The original engineering configuration required 32/32 forced-choice accuracy
in the canonical (`CC`) condition. Phi obtained 30/32 (0.9375), while repeated
inference produced exactly identical candidate logits.

## Why the original rule was defective

Perfect accuracy is not required to identify the paper's continuous primary
endpoint, the gold-versus-best-distractor logit margin. More importantly, the
32/32 rule was inconsistent with the evidential standard already used in the
submitted manuscript: Gemma's reported canonical substrates include 31/32
(0.96875) and 29/32 (0.90625). Rejecting a new model at 30/32 while retaining
the 29/32 Gemma experiment would apply unequal standards across models.

## Amended rule

Phi passes the canonical task gate only if all of the following hold:

1. overall forced-choice canonical accuracy is at least 29/32 (0.90625), the
   weakest canonical substrate already reported in the manuscript;
2. accuracy is at least 6/8 (0.75) in every language × target-length cell;
3. the largest predicted-digit share is at most 0.375, guarding against a
   collapsed response strategy; and
4. two repeated one-shot scores of the frozen audit item have a maximum
   candidate-logit difference of exactly zero.

All tokenizer, context, reconstruction, fragmentation, and geometry gates are
unchanged. No threshold may be altered again after any Phi noncanonical
factorial outcome is accessed. Both this amendment and the superseded v1
configuration must remain in the archive.

## Consequence for the observed canonical run

The observed 30/32 result clears the overall threshold. Final qualification
still depends on the per-cell, response-balance, and unchanged engineering
gates computed by the revised notebook.

