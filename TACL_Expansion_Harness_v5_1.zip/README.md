# TACL expansion harness

This directory is the clean-room expansion workspace for the TACL revision of
*When Tokenization Effects Cancel*. It leaves the published reproduction
repository unchanged and freezes all new decisions before outcome inspection.

The package has four jobs:

1. reproduce the reported v061 factorial estimates from committed JSONL rows;
2. construct and audit the four causal conditions (`CC`, `CE`, `FC`, `FE`);
3. qualify a new model without looking at factorial outcomes; and
4. write append-only, resume-safe result files for Colab runs; and
5. rerun Qwen and Gemma under a harmonized one-shot/no-cache BF16 path.

## Local CPU checks

```bash
python -m pip install -e '.[test,notebook]'
pytest
tacl-factorization reproduce \
  --repo-root ../causal_factorization_repo \
  --experiment qwen_v061
```

No GPU or model download is required for these checks.

## Colab notebooks

- `notebooks/01_qwen_v061_reproduction_gate.ipynb` checks the historical raw
  rows, verifies the frozen contract, and provides an opt-in full rerun path.
- `notebooks/02_phi_engineering_qualification.ipynb` runs only the
  outcome-independent qualification stage for Phi-4-mini-instruct.
- `notebooks/03_phi_confirmatory_factorial.ipynb` verifies the exact passed
  audit and runs the frozen 512-row Phi factorial under a single guarded
  runtime fingerprint.
- `notebooks/04_mistral_engineering_qualification_v1_1_r4.ipynb` applies the same
  outcome-independent qualification design to Mistral before either new
  model's factorial outcomes are opened.
- `notebooks/05_mistral_confirmatory_factorial.ipynb` verifies the exact passed
  Mistral audit and runs its frozen, resume-safe 512-row factorial.
- `notebooks/06_qwen_harmonized_robustness.ipynb` runs the excluded-seed
  engineering preflight and the frozen 256-row matched-path Qwen robustness grid.
- `notebooks/07_gemma_harmonized_robustness.ipynb` applies the corresponding
  architecture-aware preflight and 256-row matched-path Gemma grid.

The notebooks write to Google Drive, are append-only, and can be resumed.
They deliberately stop before any newly generated factorial outcome is
summarized unless the corresponding frozen gate passes.

The confirmatory notebook is intentionally armed with
`RUN_CONFIRMATORY_FACTORIAL=False`; beginning the frozen run requires changing
that single flag after reviewing the printed configuration.

## Frozen configurations

- `configs/qwen_v061_reproduction.json`: exact historical Qwen contract.
- `configs/phi_engineering_v1.json`: original, superseded 32/32 Phi gate,
  retained for audit history.
- `configs/phi_engineering_v1_1.json`: amended Phi gate anchored to the weakest
  canonical substrate already reported in the paper; see
  `PROTOCOL_AMENDMENT_01.md`.
- `configs/phi_factorial_confirmatory_v1.json`: Phi's qualified, audit-bound
  512-row confirmatory run (`en=2`, `tr=2`).
- `configs/mistral_engineering_v1.json`: superseded standalone-digit-token
  check, retained for audit history.
- `configs/mistral_engineering_v1_1.json`: contextual digit-prefix contract
  frozen after tokenizer inspection and before any Mistral task outcome; see
  `PROTOCOL_AMENDMENT_02.md`.
- `configs/mistral_factorial_confirmatory_v1.json`: Mistral's qualified,
  audit-bound 512-row confirmatory run (`en=5`, `tr=1`).
- `configs/added_model_factorial_frozen.json`: locked confirmatory design for
  Phi and Mistral after qualification.
- `configs/qwen_harmonized_robustness_v1.json` and
  `configs/gemma_harmonized_robustness_v1.json`: Stage-2 matched-path design,
  fresh seeds 9000--9015, engineering seed 8999, locked estimands, and
  report-regardless stopping/analysis rules.

The study-wide rationale and stopping rules remain in
`../TACL_Expansion_Protocol_v1.md`.

Mistral's tokenizer requires the token-offset region-labeling fallback recorded
in `IMPLEMENTATION_NOTE_02.md`. This is the same construction used by the
frozen Gemma v071 experiment and was added before any Mistral task score.
Mistral byte-fallback tokens are kept canonical and its token-inflation scan is
recomputed through that exact encoder, as recorded in `IMPLEMENTATION_NOTE_03.md`.

Stage 2 is frozen in `STAGE2_HARMONIZED_PROTOCOL.md`. Both notebooks resolve
the model repository revision before scoring, bind rows to the exact engineering
audit/config/runtime hashes, and refuse to calculate effects from fewer than
256 structurally complete rows.

Harness 0.5.1 explicitly forces each Stage-2 model's frozen encoding strategy.
This prevents Gemma from being routed through the non-compositional Qwen-style
chunk encoder; the pre-score correction is documented in
`IMPLEMENTATION_NOTE_04.md`.
