# fragburden

Experiment base for **"Fragmentation, Not Language: A Within-Model Causal Test
of Token Burden in Multilingual Long-Context Reasoning"** (proposal v0.3).

Sized for a **single free-tier Colab T4**. No training, no paid API, no
LLM-as-judge.

```bash
pip install -e .
python -m fragburden budget          # what the current grid costs
python -m fragburden selftest        # 96 tests, no GPU or network needed
```

---

## What this does

Manipulates **fragmentation** — how many tokens the same bytes occupy — as an
independent variable inside a frozen model, and measures what it costs at
length. Two routes to the same variable: synthetic re-segmentation of English,
and the natural fragmentation of Turkish.

The two hard parts, and where they live:

| Problem | Module |
|---|---|
| A monotone, in-vocabulary fragmentation dial | `dial.py` |
| Separating fragmentation from distribution shift | `naturalness.py` |
| Surviving Colab disconnects without losing or duplicating work | `runner.py` |

---

## Module map

```
fragburden/
  spec.py          ItemSpec + deterministic item IDs (resume is a set difference)
  dial.py          merge-rank truncation; vocab-restriction fallback
  naturalness.py   N0/N1/N2 matched-token-count re-segmentation
  ledger.py        proposition ledger, audit, diagnostic distractor typing
  lexicon.py       EN/TR/RU case tables and templates  [TR/RU NEED SIGN-OFF]
  generator.py     four task families, verbose/compact, length targeting
  burden.py        fertility, phi, R_Z, required spans, epsilon
  grid.py          the grid and its cost; single source of truth
  model.py         4-bit HF loading; scores from raw IDs, never from a string
  runner.py        resume-safe harness + nightly reconciliation
  analysis.py      primary model, naturalness gate, g(N), phase/deficit, Thm 4.3
  testing.py       offline BPE/Unigram fixtures so tests need no network
```

### The dial (`dial.py`)

Truncating a BPE merge table at rank *k* gives a fragmentation dial that is
**monotone** (fewer merges never yields fewer tokens) and **in-vocabulary**
(every produced token is an intermediate merge, so IDs stay valid and the
embedding matrix is untouched).

On the toy fixture:

```
keep 100%  phi 1.000    keep 50%  phi 2.014
keep  75%  phi 1.457    keep 25%  phi 2.786
```

`capability()` is the **Phase 1 gate**: it reports whether merge ranks are
recoverable. Gemma 3's SentencePiece vocabulary may not expose them, in which
case the dial falls back to length-thresholded vocabulary restriction — also
monotone, also in-vocabulary, but its phi levels do not align numerically with
the BPE dial, so `dial_type` is recorded on every result row.

```bash
python -m fragburden dial-check --tokenizer Qwen/Qwen3-4B
python -m fragburden dial-check --tokenizer google/gemma-3-4b-it   # run this first
```

### The naturalness control (`naturalness.py`)

v0.2 planned to estimate the off-distribution penalty and **subtract** it. That
assumes it is additive and constant in phi. It almost certainly is not: deeper
truncation produces text further from anything the model saw, so the penalty
grows in the same direction as the effect of interest.

This module holds the **token count fixed** at each dial setting and varies only
which valid segmentation is used:

- **N0** greedy segmentation under the truncated merge table (the dial itself)
- **N1** uniformly sampled alternative with the same token count
- **N2** same count, boundaries chosen to maximise deviation from N0

Same-count enumeration is a DP over a vocabulary trie, per pre-token chunk.
`perturbable_fraction` is logged per item: if the vocabulary has no slack, the
naturalness contrast is weak and that must be reported, not absorbed.

`analysis.naturalness_check()` implements the **pre-registered failure mode**:
if the naturalness penalty is comparable to or larger than the fragmentation
effect at every dial setting, it reports a non-identification rather than a
rescued estimate.

### The harness (`runner.py`)

Free Colab disconnects; the harness is built around that.

- deterministic item IDs — nothing depends on execution order
- append-only JSONL on Drive, fsynced every 25 items
- resume by set difference; re-running is always idempotent
- **torn final lines are terminated before appending** (a hard kill mid-write
  leaves a partial record; without this the next row is glued onto it and both
  are lost — this was a real bug, caught by `test_resume.py`)
- length-descending shards: long items run while the session is freshest
- tokenizer fingerprint per row; `require_fingerprint=` re-runs only affected items
- OOM backoff halves the batch instead of losing the session
- `reconcile()` for the nightly integrity check

`tests/test_resume.py` is the **Phase 2 gate**, automated: kill three times
mid-run, assert zero duplicates and zero gaps.

---

## Budget

`grid.py` is the single source of truth, so any design change prints its
compute cost immediately.

```
block                      items    gpu-h
-----------------------------------------
pilot                        960     0.91
arm_a_core                 5,760     5.44
arm_a_16k                    288     1.52
arm_a_replication          1,152     1.34
arm_b                      1,152     1.35
arm_b_replication            576     0.68
retrieval_control            240     0.43
sanity_full_precision        800     0.27
position_spotcheck           384     0.59
paraphrase_spotcheck         320     0.41
stretch_32k                   72     1.10
-----------------------------------------
total                     11,704    14.04

with 2x contingency : 28.1 gpu-hours
at 3 usable h/day   : 9.4 calendar days
```

This lands within ~7% of the proposal's §6.2 table (12,264 items / ~15 h). The
small differences are the pilot being smaller than estimated and the 1.7B
sanity model being cheaper than the 4B planning figure allowed; update §6.2 to
match the code, not the other way round.

After the pilot, replace the estimated throughput table with measured values:

```python
from fragburden.grid import calibrate_from_run
calibrate_from_run("runs/pilot.jsonl")   # -> paste into SECONDS_PER_ITEM
```

---

## Running

```bash
# smoke test with no GPU: the stub model exercises the whole pipeline
python -m fragburden run --block pilot --limit 60 --model stub --out runs/smoke.jsonl

# real pilot
python -m fragburden run --block pilot \
    --tokenizer Qwen/Qwen3-4B --model Qwen/Qwen3-4B \
    --out /content/drive/MyDrive/fragburden/runs/pilot.jsonl \
    --batch-size 4 --time-budget 10800

python -m fragburden reconcile --out runs/pilot.jsonl   # exit 2 if gaps
python -m fragburden analyze   --out runs/pilot.jsonl
```

`notebooks/pilot.ipynb` wraps this for Colab: mounts Drive, installs, checks the
dial, runs with a time budget, reconciles, and is safe to re-run after any
disconnect.

---

## Before you pre-register

Four things this repo deliberately does **not** pretend are done.

1. **The Turkish and Russian lexicons are starter tables.** `sign_off_status()`
   reports `tr: False, ru: False`, and a test enforces that it keeps saying so
   until a native pass happens. Writing these tables already surfaced one real
   case error — a `ödünç verdi` variant with the roles reversed, which inverts
   the proposition without changing a word. Back-translation would not have
   caught it. This is the Phase 4 gate and it is not optional.
2. **Run `dial-check` on Gemma 3 first.** If merge ranks are not recoverable and
   the fallback dial behaves differently, Arm A becomes single-model and the
   paper's generality claim changes. One hour of work, before anything else.
3. **Reconcile this generator with your validated `paired_generator.py`.** This
   one is fresh and follows the same contract (seed ID, ledger, four corners),
   but yours has 2,880 audited records behind it. Diff the lexicons and keep the
   better one.
4. **The stub model is not a result.** `analysis.provenance()` flags any run
   containing stub rows as non-substantive, and `analyze` prints a warning.

---

## Analysis

`analysis.py` follows §7 in reporting order:

| Function | Answers |
|---|---|
| `primary_model` | phi × naturalness × log(tokens), cluster-robust by instance |
| `naturalness_check` | the identification gate and its pre-registered failure mode |
| `exchange_rate` | g(N): TR at N tokens ≈ EN at g(N) tokens |
| `phase_deficit` | length-invariant vs length-growing shares of the penalty (RQ5) |
| `thm43_check` | the Theorem 4.3 bound from measured R_Z and epsilon |

On `thm43_check`: the theorem bounds excess **log-loss**, not accuracy. The code
tests the ordering prediction and reports the bound in bits alongside the
accuracy gain, rather than inventing a loss-to-accuracy conversion the theorem
does not license. `phase_deficit` carries a similar caveat in its output —
Theorem 3.1's terms are defined for optimal predictors on Markov sources, so
the mapping is an operationalization, not an identification.

`statsmodels` is optional; everything except `primary_model` runs without it.

---

## Tests

```
96 passed
```

No GPU, no network — `testing.py` trains a small byte-level BPE and a Unigram
tokenizer locally. The suite covers dial monotonicity and vocabulary safety,
token-count matching under perturbation, byte preservation, ledger audits in
all three languages, grid arithmetic against the proposal, and the kill/resume
gate.
