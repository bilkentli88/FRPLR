"""Offline fixtures.

The real experiment uses Qwen3 and Gemma 3 tokenizers.  Tests must run without
network access and without a GPU, so this module trains a small byte-level BPE
locally.  It is a fixture, never an experimental object: nothing here should
appear in a result row that is analysed substantively.
"""

from __future__ import annotations

import functools

from tokenizers import Tokenizer, decoders, models, pre_tokenizers, trainers

from .dial import FragmentationDial

_EN = [
    "The report was filed on a cold morning and nobody objected to its contents.",
    "Alice picked up the book and carried it through the office to the library.",
    "There is a direct connection running from Almera to Bruning every evening.",
    "Brian handed the key over to Clara before the meeting started in the lounge.",
    "The weather over Corvale stayed unremarkable for most of the afternoon.",
]

_TR = [
    "Rapor soğuk bir sabah dosyalandı ve içeriğine kimse itiraz etmedi.",
    "Ali kitabı eline aldı ve ofisten kütüphaneye kadar taşıdı.",
    "Almera ile Bruning arasında her akşam doğrudan bir bağlantı bulunmaktadır.",
    "Mehmet anahtarı toplantı başlamadan önce Zeynep'e teslim etti.",
    "Corvale üzerindeki hava öğleden sonranın büyük bölümünde sıradan kaldı.",
    "Gelemeyeceğimizi söylemiştik ama kitaplarımızdan bahsetmeyi unutmuşuz.",
]

_RU = [
    "Отчёт был подан холодным утром, и никто не возражал против его содержания.",
    "Иван взял книгу и отнёс её из офиса в библиотеку.",
    "Между Альмерой и Брунингом каждый вечер есть прямое сообщение.",
    "Пётр передал ключ Ольге до начала встречи в гостиной.",
    "Погода над Корвейлом большую часть дня оставалась обычной.",
]

_SAMPLES = {"en": _EN, "tr": _TR, "ru": _RU}


def sample_texts(language: str = "en", repeat: int = 1) -> list[str]:
    return list(_SAMPLES.get(language, _EN)) * repeat


def all_sample_texts(repeat: int = 1) -> list[str]:
    out: list[str] = []
    for lang in ("en", "tr", "ru"):
        out.extend(sample_texts(lang, repeat))
    return out


@functools.lru_cache(maxsize=4)
def toy_tokenizer(vocab_size: int = 2000) -> Tokenizer:
    tk = Tokenizer(models.BPE(unk_token=None))
    tk.pre_tokenizer = pre_tokenizers.ByteLevel(add_prefix_space=True)
    tk.decoder = decoders.ByteLevel()
    trainer = trainers.BpeTrainer(
        vocab_size=vocab_size,
        special_tokens=["<pad>"],
        initial_alphabet=pre_tokenizers.ByteLevel.alphabet(),
        show_progress=False,
        min_frequency=1,
    )
    corpus = all_sample_texts(repeat=40)
    # a little extra material so merges reach interesting ranks
    corpus += [
        "kitaplarımızdan bahsetmiştik ve gelemeyeceğimizi söylemiştik",
        "the quick brown fox jumps over the lazy dog near the river bank",
        "международная организация подготовила подробный доклад о результатах",
    ] * 40
    tk.train_from_iterator(corpus, trainer)
    return tk


def toy_dial(vocab_size: int = 2000) -> FragmentationDial:
    return FragmentationDial(toy_tokenizer(vocab_size), name=f"toy-bpe-{vocab_size}")


@functools.lru_cache(maxsize=2)
def toy_unigram_tokenizer(vocab_size: int = 1200) -> Tokenizer:
    """A Unigram tokenizer, to exercise the vocab-restriction fallback path
    that Gemma 3 may require."""
    tk = Tokenizer(models.Unigram())
    tk.pre_tokenizer = pre_tokenizers.Metaspace()
    trainer = trainers.UnigramTrainer(
        vocab_size=vocab_size,
        special_tokens=["<pad>"],
        unk_token="<unk>",
        show_progress=False,
    )
    tk.train_from_iterator(all_sample_texts(repeat=40), trainer)
    return tk


def toy_unigram_dial(vocab_size: int = 1200) -> FragmentationDial:
    return FragmentationDial(toy_unigram_tokenizer(vocab_size),
                             name=f"toy-unigram-{vocab_size}")
