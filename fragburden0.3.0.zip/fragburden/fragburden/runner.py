"""Resume-safe execution harness.

Free Colab disconnects.  The harness is built around that rather than against
it (proposal v0.3 sec. 6.3):

  * deterministic item IDs -- nothing depends on execution order
  * append-only JSONL on Drive, flushed and fsynced every N items
  * resume by set difference; re-running is always idempotent
  * length-descending shards, so long-context items run while the session is
    freshest and short items backfill
  * tokenizer fingerprint on every row, so a changed encoding path invalidates
    only the affected rows
  * nightly reconciliation against the planned grid

The Phase 2 gate is: kill and resume three times mid-run, zero duplicates and
zero gaps.  `tests/test_resume.py` is that gate, automated.
"""

from __future__ import annotations

import json
import os
import signal
import sys
import time
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Iterable, Sequence

from .burden import compression_rate, fragmentation_ratio, required_span_tokens
from .dial import FragmentationDial
from .generator import GenConfig, generate, pad_to_token_count, realize
from .grid import RunBlock, seconds_for
from .lexicon import INSTRUCTIONS, sign_off_status
from .naturalness import NaturalnessPerturber
from .spec import ItemResult, ItemSpec


# ---------------------------------------------------------------------------
# storage
# ---------------------------------------------------------------------------

class ResultStore:
    """Append-only JSONL with periodic fsync and set-difference resume."""

    def __init__(self, path: str | Path, flush_every: int = 25):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.flush_every = flush_every
        self._fh = None
        self._since_flush = 0
        self.n_written = 0

    # -- reading ----------------------------------------------------------
    def completed(self, require_fingerprint: str | None = None) -> set[str]:
        """IDs already done.

        If `require_fingerprint` is given, rows written under a different
        tokenizer fingerprint are treated as *not* done, so a changed encoding
        path re-runs exactly the affected items.
        """
        done: set[str] = set()
        if not self.path.exists():
            return done
        for row in self.iter_rows():
            if require_fingerprint and row.get("tokenizer_fingerprint") != require_fingerprint:
                continue
            iid = row.get("item_id")
            if iid:
                done.add(iid)
        return done

    def iter_rows(self) -> Iterable[dict]:
        if not self.path.exists():
            return
        with self.path.open("r", encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                try:
                    yield json.loads(line)
                except json.JSONDecodeError:
                    # A torn final line from a hard kill.  Skip it; the item is
                    # simply not marked done and will be re-run.
                    continue

    def load_frame(self):
        import pandas as pd

        return pd.DataFrame(list(self.iter_rows()))

    # -- writing ----------------------------------------------------------
    def open(self) -> None:
        if self._fh is not None:
            return
        # A hard kill can leave a partial JSON line with no trailing newline.
        # Terminate it before appending, or the next record is glued onto the
        # fragment and both are lost.
        self._terminate_torn_line()
        self._fh = self.path.open("a", encoding="utf-8")

    def _terminate_torn_line(self) -> None:
        if not self.path.exists() or self.path.stat().st_size == 0:
            return
        with self.path.open("rb") as fh:
            fh.seek(-1, os.SEEK_END)
            last = fh.read(1)
        if last not in (b"\n", b"\r"):
            with self.path.open("a", encoding="utf-8") as fh:
                fh.write("\n")

    def write(self, result: ItemResult) -> None:
        self.open()
        assert self._fh is not None
        self._fh.write(result.to_json() + "\n")
        self.n_written += 1
        self._since_flush += 1
        if self._since_flush >= self.flush_every:
            self.sync()

    def sync(self) -> None:
        if self._fh is not None:
            self._fh.flush()
            os.fsync(self._fh.fileno())
            self._since_flush = 0

    def close(self) -> None:
        self.sync()
        if self._fh is not None:
            self._fh.close()
            self._fh = None

    def __enter__(self) -> "ResultStore":
        self.open()
        return self

    def __exit__(self, *exc) -> None:
        self.close()

    # -- integrity --------------------------------------------------------
    def duplicates(self) -> dict[str, int]:
        counts: dict[str, int] = defaultdict(int)
        for row in self.iter_rows():
            counts[row["item_id"]] += 1
        return {k: v for k, v in counts.items() if v > 1}


# ---------------------------------------------------------------------------
# item construction
# ---------------------------------------------------------------------------

@dataclass
class BuiltItem:
    spec: ItemSpec
    input_ids: list[int]
    gold: str
    option_errors: dict[str, str]
    realized_tokens: int
    baseline_tokens: int
    compression_rate: float
    required_span_tokens: int
    perturbable_fraction: float
    fingerprint: str


class ItemBuilder:
    """Turns an ItemSpec into token IDs, applying the dial and perturbation."""

    def __init__(self, dial: FragmentationDial):
        self.dial = dial
        self._perturbers: dict[int, NaturalnessPerturber] = {}
        self._base_vocab = list(dial.base.get_vocab().keys())

    def _perturber(self, phi: int) -> NaturalnessPerturber:
        if phi not in self._perturbers:
            self._perturbers[phi] = NaturalnessPerturber(
                self.dial.at(phi), base_vocab=self._base_vocab
            )
        return self._perturbers[phi]

    def build(self, spec: ItemSpec) -> BuiltItem:
        dialed = self.dial.at(spec.phi_level)
        baseline = self.dial.at(100)
        instruction = INSTRUCTIONS[spec.language]

        cfg = GenConfig(
            family=spec.family,
            language=spec.language,
            complexity=spec.complexity,
            realization=spec.realization,
            seed=spec.seed,
            target_tokens=spec.target_tokens,
        )

        # Matching regime (proposal v0.3 sec. 7.2).
        #   content: length searched under the undialed tokenizer, so bytes are
        #            held fixed across phi and token count rises with phi.
        #   token:   length searched under the dialed tokenizer, so token count
        #            is held fixed and content shrinks as phi rises.
        counter_tok = baseline if spec.matching == "content" else dialed
        prompt, ledger, _n_filler = realize(cfg, lambda s: len(counter_tok.encode_pieces(s)))

        # Arm B's length-matched filler cell.
        if spec.realization == "compact_filler":
            verbose_cfg = GenConfig(**{**cfg.__dict__, "realization": "verbose"})
            v_prompt, _v_lg, _ = realize(
                verbose_cfg, lambda s: len(counter_tok.encode_pieces(s))
            )
            v_tokens = len(counter_tok.encode_pieces(v_prompt))
            prompt, ledger, _ = pad_to_token_count(
                cfg, generate(cfg), lambda s: len(counter_tok.encode_pieces(s)), v_tokens
            )

        failures = ledger.audit()
        if failures:
            raise ValueError(f"ledger audit failed for {spec.id}: {failures}")

        reseg = self._perturber(spec.phi_level).apply(
            prompt, spec.naturalness, seed=spec.seed
        )
        ids = dialed.pieces_to_ids(reseg.pieces)

        return BuiltItem(
            spec=spec,
            input_ids=ids,
            gold=ledger.answer_key,
            option_errors=dict(ledger.option_errors),
            realized_tokens=len(ids),
            baseline_tokens=len(baseline.encode_pieces(prompt)),
            compression_rate=compression_rate(prompt, len(ids)),
            required_span_tokens=required_span_tokens(ledger, dialed, instruction),
            perturbable_fraction=reseg.perturbable_fraction,
            fingerprint=dialed.fingerprint,
        )


# ---------------------------------------------------------------------------
# runner
# ---------------------------------------------------------------------------

class Runner:
    def __init__(self, dial: FragmentationDial, model, store: ResultStore,
                 batch_size: int = 4, max_batch_tokens: int = 32768,
                 verbose: bool = True, allow_unsigned_lexicons: bool = True):
        self.builder = ItemBuilder(dial)
        self.model = model
        self.store = store
        self.batch_size = batch_size
        self.max_batch_tokens = max_batch_tokens
        self.verbose = verbose
        self.allow_unsigned = allow_unsigned_lexicons
        self._stop = False
        self.n_done = 0
        self.n_failed = 0
        self._install_signals()

    def _install_signals(self) -> None:
        def handler(signum, _frame):
            self._stop = True
            self._log(f"\nsignal {signum} received; finishing current batch and syncing")
        for sig in (signal.SIGINT, signal.SIGTERM):
            try:
                signal.signal(sig, handler)
            except (ValueError, OSError):
                pass  # not on the main thread (e.g. inside a notebook cell)

    def _log(self, msg: str) -> None:
        if self.verbose:
            print(msg, file=sys.stderr, flush=True)

    # -- planning ---------------------------------------------------------
    @staticmethod
    def order(specs: Sequence[ItemSpec]) -> list[ItemSpec]:
        """Length-descending shards; stable within a shard by ID."""
        return sorted(specs, key=lambda s: (-s.target_tokens, s.model, s.id))

    def pending(self, specs: Sequence[ItemSpec],
                require_fingerprint: str | None = None) -> list[ItemSpec]:
        done = self.store.completed(require_fingerprint=require_fingerprint)
        return [s for s in self.order(specs) if s.id not in done]

    def _batches(self, specs: Sequence[ItemSpec]) -> Iterable[list[ItemSpec]]:
        batch: list[ItemSpec] = []
        for s in specs:
            cap = max(1, min(self.batch_size,
                             self.max_batch_tokens // max(1, s.target_tokens)))
            if batch and (len(batch) >= cap
                          or batch[0].target_tokens != s.target_tokens
                          or batch[0].model != s.model):
                yield batch
                batch = []
            batch.append(s)
        if batch:
            yield batch

    # -- execution --------------------------------------------------------
    def run(self, specs: Sequence[ItemSpec],
            require_fingerprint: str | None = None,
            time_budget_s: float | None = None) -> dict:
        unsigned = [k for k, v in sign_off_status().items() if not v]
        langs = {s.language for s in specs}
        if unsigned and langs & set(unsigned) and not self.allow_unsigned:
            raise RuntimeError(
                f"lexicons {sorted(langs & set(unsigned))} lack native sign-off "
                "(Phase 4 gate); pass allow_unsigned_lexicons=True to override"
            )

        todo = self.pending(specs, require_fingerprint=require_fingerprint)
        self._log(f"{len(todo):,} pending of {len(specs):,} planned")
        started = time.time()

        with self.store:
            for batch in self._batches(todo):
                if self._stop:
                    break
                if time_budget_s and (time.time() - started) > time_budget_s:
                    self._log("time budget reached; stopping cleanly")
                    break
                self._run_batch(batch)

        self.store.sync()
        return {
            "planned": len(specs),
            "pending_at_start": len(todo),
            "completed_this_session": self.n_done,
            "failed": self.n_failed,
            "elapsed_s": round(time.time() - started, 1),
            "stopped_early": self._stop,
        }

    def _run_batch(self, batch: list[ItemSpec]) -> None:
        built: list[BuiltItem] = []
        for spec in batch:
            try:
                built.append(self.builder.build(spec))
            except Exception as exc:  # noqa: BLE001 - one bad item must not kill a run
                self.n_failed += 1
                self._log(f"build failed {spec.id}: {type(exc).__name__}: {exc}")
        if not built:
            return

        t0 = time.time()
        preds = self._score_with_backoff([b.input_ids for b in built],
                                         [b.gold for b in built])
        if preds is None:
            return
        dt = (time.time() - t0) / len(built)

        for b, pred in zip(built, preds):
            letter = pred.letter or ""
            correct = letter == b.gold
            self.store.write(
                ItemResult(
                    item_id=b.spec.id,
                    spec=b.spec,
                    correct=correct,
                    predicted=letter,
                    gold=b.gold,
                    error_type=("correct" if correct
                                else b.option_errors.get(letter, "unparsed")),
                    realized_tokens=b.realized_tokens,
                    baseline_tokens=b.baseline_tokens,
                    fragmentation_ratio=fragmentation_ratio(
                        b.realized_tokens, b.baseline_tokens),
                    compression_rate=b.compression_rate,
                    required_span_tokens=b.required_span_tokens,
                    perturbable_fraction=b.perturbable_fraction,
                    tokenizer_fingerprint=b.fingerprint,
                    wall_seconds=dt,
                )
            )
            self.n_done += 1

    def _score_with_backoff(self, ids: list[list[int]], golds: list[str],
                            attempts: int = 4):
        """Halve the batch on OOM rather than losing the session."""
        chunks = [list(zip(ids, golds))]
        for attempt in range(attempts):
            out = []
            try:
                for chunk in chunks:
                    sub_ids = [i for i, _ in chunk]
                    sub_gold = [g for _, g in chunk]
                    if hasattr(self.model, "_gold"):
                        self.model._gold = sub_gold
                    out.extend(self.model.score(sub_ids))
                return out
            except Exception as exc:  # noqa: BLE001
                name = type(exc).__name__
                oom = "OutOfMemory" in name or "CUDA out of memory" in str(exc)
                if not oom or attempt == attempts - 1:
                    self.n_failed += len(ids)
                    self._log(f"scoring failed ({name}: {exc}); skipping batch")
                    return None
                self._free_cache()
                chunks = [c[i:i + max(1, len(c) // 2)]
                          for c in chunks for i in range(0, len(c), max(1, len(c) // 2))]
                self._log(f"OOM; retrying at batch size {max(len(c) for c in chunks)}")
        return None

    @staticmethod
    def _free_cache() -> None:
        try:
            import gc
            import torch

            gc.collect()
            torch.cuda.empty_cache()
        except Exception:  # noqa: BLE001
            pass


# ---------------------------------------------------------------------------
# reconciliation
# ---------------------------------------------------------------------------

def reconcile(blocks: Sequence[RunBlock], store: ResultStore) -> dict:
    """Nightly integrity check: which planned cells are missing or short."""
    done = store.completed()
    dupes = store.duplicates()
    per_block = []
    missing_total = 0
    for b in blocks:
        missing = [s for s in b.specs if s.id not in done]
        missing_total += len(missing)
        by_cell: dict[str, int] = defaultdict(int)
        for s in missing:
            by_cell[s.cell] += 1
        per_block.append({
            "block": b.name,
            "planned": b.n_items,
            "done": b.n_items - len(missing),
            "missing": len(missing),
            "cells_incomplete": len(by_cell),
            "remaining_gpu_hours": round(
                sum(seconds_for(s.target_tokens) for s in missing) / 3600.0, 2),
        })
    return {
        "blocks": per_block,
        "missing_total": missing_total,
        "duplicate_item_ids": len(dupes),
        "rows_on_disk": sum(1 for _ in store.iter_rows()),
        "clean": missing_total == 0 and not dupes,
    }
