"""Command line entry points.

    python -m fragburden budget
    python -m fragburden dial-check --tokenizer Qwen/Qwen3-4B
    python -m fragburden fertility --corpus-dir corpora/ --tokenizer Qwen/Qwen3-4B
    python -m fragburden preview --language tr --family negation
    python -m fragburden run --block pilot --out runs/pilot.jsonl
    python -m fragburden reconcile --out runs/pilot.jsonl
    python -m fragburden analyze --out runs/pilot.jsonl
    python -m fragburden selftest
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from . import grid
from .dial import FragmentationDial, verify_monotone


def _load_dial(name: str | None, vocab_size: int = 2000) -> FragmentationDial:
    if name:
        return FragmentationDial.from_pretrained(name)
    from .testing import toy_dial

    print("no --tokenizer given; using a locally trained toy BPE", file=sys.stderr)
    return toy_dial(vocab_size=vocab_size)


# ---------------------------------------------------------------------------

def cmd_budget(args) -> int:
    names = args.blocks or list(grid.MAIN_RUN)
    b = grid.budget(names, contingency=args.contingency)
    print(grid.format_budget(b))
    return 0


def cmd_dial_check(args) -> int:
    """Phase 1 gate: is a fragmentation dial available on this tokenizer?"""
    dial = _load_dial(args.tokenizer)
    cap = dial.capability()
    print(json.dumps(cap, indent=2, ensure_ascii=False))
    if not cap["usable_for_arm_a"]:
        print("\nFAIL: no dial available. Arm A cannot use this tokenizer.")
        return 1

    from .testing import sample_texts

    texts = sample_texts(args.language)
    report = verify_monotone(dial, texts)
    print("\nmonotonicity check on sample text:")
    for lvl in sorted(report["counts"], reverse=True):
        print(f"  keep {lvl:>3}%  tokens {report['counts'][lvl]:>7,}"
              f"  phi {report['phi'][lvl]:.3f}  oov {report['oov'][lvl]}")
    ok = report["monotone_nondecreasing"] and report["all_in_vocab"]
    print(f"\nmonotone non-decreasing : {report['monotone_nondecreasing']}")
    print(f"all pieces in vocabulary: {report['all_in_vocab']}")
    print("PASS" if ok else "FAIL")
    return 0 if ok else 1


def cmd_fertility(args) -> int:
    from .burden import fertility_table

    dial = _load_dial(args.tokenizer)
    corpora: dict[str, list[str]] = {}
    if args.corpus_dir:
        for p in sorted(Path(args.corpus_dir).glob("*.txt")):
            corpora[p.stem] = [
                line.strip() for line in p.read_text(encoding="utf-8").splitlines()
                if line.strip()
            ]
    else:
        from .testing import sample_texts

        corpora = {lang: sample_texts(lang) for lang in ("en", "tr", "ru")}
    rows = fertility_table(dial, corpora, tokenizer_name=args.tokenizer or "toy")
    hdr = f"{'lang':<6}{'tok/word':>10}{'chars/tok':>11}{'vs en':>8}"
    print(hdr)
    print("-" * len(hdr))
    for r in rows:
        print(f"{r['language']:<6}{r['tokens_per_word']:>10.3f}"
              f"{r['chars_per_token']:>11.3f}{r.get('fertility_vs_en', float('nan')):>8.3f}")
    return 0


def cmd_preview(args) -> int:
    """Print a generated instance.  Use this to eyeball TR/RU before sign-off."""
    from .generator import GenConfig, realize
    from .lexicon import INSTRUCTIONS

    dial = _load_dial(args.tokenizer)
    dialed = dial.at(args.phi)
    cfg = GenConfig(family=args.family, language=args.language,
                    complexity=args.complexity, realization=args.realization,
                    seed=args.seed, target_tokens=args.target_tokens)
    prompt, ledger, n_filler = realize(
        cfg, lambda s: len(dialed.encode_pieces(s))
    )
    print(prompt)
    print("\n" + "-" * 60)
    print(f"answer        : {ledger.answer_key} = {ledger.answer}")
    print(f"option errors : {ledger.option_errors}")
    print(f"filler        : {n_filler}")
    print(f"tokens        : {len(dialed.encode_pieces(prompt))}")
    print(f"audit         : {ledger.audit() or 'clean'}")
    return 0


def cmd_run(args) -> int:
    from .model import StubModel
    from .runner import ResultStore, Runner

    dial = _load_dial(args.tokenizer)
    blocks = grid.build([args.block])
    specs = [s for b in blocks for s in b.specs]
    if args.limit:
        specs = Runner.order(specs)[: args.limit]

    if args.model == "stub":
        model = StubModel(seed=args.seed)
    else:
        from .model import HFModel

        model = HFModel(args.model, quant=args.quant,
                        chat_template=args.chat_template)

    store = ResultStore(args.out)
    runner = Runner(dial, model, store, batch_size=args.batch_size,
                    allow_unsigned_lexicons=not args.require_signoff)
    summary = runner.run(specs, time_budget_s=args.time_budget)
    print(json.dumps(summary, indent=2))
    return 0


def cmd_reconcile(args) -> int:
    from .runner import ResultStore, reconcile

    blocks = grid.build(args.blocks or list(grid.MAIN_RUN))
    rep = reconcile(blocks, ResultStore(args.out))
    print(json.dumps(rep, indent=2))
    return 0 if rep["clean"] else 2


def cmd_analyze(args) -> int:
    from . import analysis

    df = analysis.load(args.out)
    if df.empty:
        print("no rows")
        return 1
    print(json.dumps(analysis.summarize(df), indent=2, default=str))
    prov = analysis.provenance(df)
    if not prov["substantive"]:
        print("\nNOTE: this run contains StubModel rows. Pipeline check only; "
              "no substantive conclusions may be drawn.")
    try:
        print("\n--- naturalness identification gate ---")
        print(analysis.naturalness_check(df))
    except Exception as exc:  # noqa: BLE001
        print(f"naturalness check unavailable: {exc}")
    try:
        er = analysis.exchange_rate(df)
        print("\n--- exchange rate g(N) ---")
        print(er.grid.to_string(index=False))
    except Exception as exc:  # noqa: BLE001
        print(f"exchange rate unavailable: {exc}")
    try:
        pdres = analysis.phase_deficit(df, n_boot=args.boot)
        print("\n--- phase / deficit ---")
        print(f"phase (phi at shortest length): {pdres.phase_share:+.4f}")
        print(f"deficit (phi x log tokens)    : {pdres.deficit_coefficient:+.4f}")
        print(f"deficit share                 : {pdres.ratio:.3f} ci={pdres.ci}")
        print(pdres.caveat)
    except Exception as exc:  # noqa: BLE001
        print(f"phase/deficit unavailable: {exc}")
    try:
        t = analysis.thm43_check(df)
        print("\n--- Theorem 4.3 bound ---")
        print(t.per_cell.to_string(index=False))
        print(f"effective window: {t.effective_window}")
        print(f"rank correlation: {t.rank_correlation}")
        print(t.note)
    except Exception as exc:  # noqa: BLE001
        print(f"thm 4.3 check unavailable: {exc}")
    return 0


def cmd_selftest(args) -> int:
    import subprocess

    root = Path(__file__).resolve().parent.parent
    return subprocess.call([sys.executable, "-m", "pytest", "-q", str(root / "tests")])


# ---------------------------------------------------------------------------

def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="fragburden")
    sub = p.add_subparsers(dest="cmd", required=True)

    b = sub.add_parser("budget", help="items and GPU-hours for the current grid")
    b.add_argument("--blocks", nargs="*")
    b.add_argument("--contingency", type=float, default=2.0)
    b.set_defaults(func=cmd_budget)

    d = sub.add_parser("dial-check", help="Phase 1 gate: dial availability")
    d.add_argument("--tokenizer")
    d.add_argument("--language", default="en")
    d.set_defaults(func=cmd_dial_check)

    f = sub.add_parser("fertility", help="Phase 1 language-selection table")
    f.add_argument("--tokenizer")
    f.add_argument("--corpus-dir")
    f.set_defaults(func=cmd_fertility)

    pv = sub.add_parser("preview", help="print one generated instance")
    pv.add_argument("--tokenizer")
    pv.add_argument("--language", default="en")
    pv.add_argument("--family", default="state_tracking")
    pv.add_argument("--complexity", type=int, default=2)
    pv.add_argument("--realization", default="na")
    pv.add_argument("--phi", type=int, default=100)
    pv.add_argument("--seed", type=int, default=0)
    pv.add_argument("--target-tokens", type=int, default=512)
    pv.set_defaults(func=cmd_preview)

    r = sub.add_parser("run", help="execute a block")
    r.add_argument("--block", default="pilot")
    r.add_argument("--out", default="runs/results.jsonl")
    r.add_argument("--tokenizer")
    r.add_argument("--model", default="stub")
    r.add_argument("--quant", default="4bit")
    r.add_argument("--batch-size", type=int, default=4)
    r.add_argument("--limit", type=int)
    r.add_argument("--seed", type=int, default=0)
    r.add_argument("--time-budget", type=float)
    r.add_argument("--chat-template", action="store_true")
    r.add_argument("--require-signoff", action="store_true")
    r.set_defaults(func=cmd_run)

    rc = sub.add_parser("reconcile", help="nightly integrity check")
    rc.add_argument("--out", default="runs/results.jsonl")
    rc.add_argument("--blocks", nargs="*")
    rc.set_defaults(func=cmd_reconcile)

    an = sub.add_parser("analyze", help="run the analysis plan")
    an.add_argument("--out", default="runs/results.jsonl")
    an.add_argument("--boot", type=int, default=200)
    an.set_defaults(func=cmd_analyze)

    st = sub.add_parser("selftest", help="run the test suite")
    st.set_defaults(func=cmd_selftest)

    args = p.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
