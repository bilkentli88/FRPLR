"""Matched-token-count naturalness perturbation (proposal v0.3 sec. 4.2).

The identification problem: merge-rank truncation changes token *count* and
distributional *naturalness* at the same time, and the naturalness penalty
plausibly grows with truncation depth.  Subtracting it as an additive main
effect -- what v0.2 planned -- would leave a biased estimate that still looks
like a clean fragmentation slope.

The fix implemented here: at each dial setting, hold the token count fixed and
vary only *which* valid segmentation is used.

  N0  the greedy segmentation under the truncated merge table (the dial itself)
  N1  a uniformly sampled alternative segmentation with the same token count
  N2  the same-count segmentation that maximises boundary deviation from N0

Because the count is matched within a dial setting, the N0 -> N1 -> N2 slope
estimates the local off-distribution penalty with fragmentation held fixed.
If that slope varies across dial settings we have the interaction, and the
fragmentation effect is reported at matched naturalness rather than as a
difference of main effects.

Everything operates in the tokenizer's internal alphabet (byte-level pieces,
leading-space markers) on one pre-token chunk at a time, so every emitted piece
is a real vocabulary entry.
"""

from __future__ import annotations

import random
from dataclasses import dataclass
from functools import lru_cache
from typing import Sequence

MAX_PIECE_LEN_CAP = 32


class _Trie:
    __slots__ = ("children", "terminal")

    def __init__(self) -> None:
        self.children: dict[str, "_Trie"] = {}
        self.terminal = False

    @classmethod
    def build(cls, vocab: Sequence[str], max_len: int = MAX_PIECE_LEN_CAP) -> "_Trie":
        root = cls()
        for piece in vocab:
            if not piece or len(piece) > max_len:
                continue
            node = root
            for ch in piece:
                nxt = node.children.get(ch)
                if nxt is None:
                    nxt = _Trie()
                    node.children[ch] = nxt
                node = nxt
            node.terminal = True
        return root

    def matches_from(self, s: str, i: int) -> list[int]:
        """End indices j such that s[i:j] is in the vocabulary."""
        out: list[int] = []
        node = self
        j = i
        n = len(s)
        while j < n:
            node = node.children.get(s[j])
            if node is None:
                break
            j += 1
            if node.terminal:
                out.append(j)
        return out


@dataclass
class Resegmentation:
    pieces: list[str]
    perturbed_chunks: int
    total_chunks: int

    @property
    def perturbable_fraction(self) -> float:
        return self.perturbed_chunks / self.total_chunks if self.total_chunks else 0.0


class ChunkResegmenter:
    """Enumerate same-count segmentations of a pre-token chunk."""

    def __init__(self, vocab: Sequence[str]):
        self.trie = _Trie.build(vocab)
        self._vocab = set(vocab)

    # -- dynamic programme -------------------------------------------------
    def _tables(self, s: str, target: int):
        """completions[i][m] = number of ways to segment s[i:] into m pieces."""
        n = len(s)
        # cap counts to keep the numbers small; we only need relative weights
        completions = [[0] * (target + 1) for _ in range(n + 1)]
        completions[n][0] = 1
        edges: list[list[int]] = [[] for _ in range(n + 1)]
        for i in range(n - 1, -1, -1):
            ends = self.trie.matches_from(s, i)
            edges[i] = ends
            row_i = completions[i]
            for j in ends:
                row_j = completions[j]
                for m in range(1, target + 1):
                    c = row_j[m - 1]
                    if c:
                        row_i[m] += c
        return completions, edges

    def alternatives_exist(self, s: str, target: int) -> bool:
        completions, _ = self._tables(s, target)
        return completions[0][target] > 1

    def sample_uniform(self, s: str, target: int, rng: random.Random,
                       exclude: list[str] | None = None) -> list[str] | None:
        """Uniformly sample a segmentation of s into exactly `target` pieces."""
        completions, edges = self._tables(s, target)
        total = completions[0][target]
        if total == 0:
            return None
        if total == 1 and exclude is not None:
            return None

        for _ in range(8):  # retry a few times if we land on the excluded path
            out: list[str] = []
            i, m = 0, target
            ok = True
            while m > 0:
                weights = []
                choices = []
                for j in edges[i]:
                    c = completions[j][m - 1]
                    if c:
                        choices.append(j)
                        weights.append(c)
                if not choices:
                    ok = False
                    break
                j = rng.choices(choices, weights=weights, k=1)[0]
                out.append(s[i:j])
                i, m = j, m - 1
            if ok and i == len(s):
                if exclude is None or out != exclude:
                    return out
        return None

    def maximise_deviation(self, s: str, target: int,
                           baseline: list[str]) -> list[str] | None:
        """Same-count segmentation maximising novel boundary positions."""
        n = len(s)
        base_cuts = set()
        pos = 0
        for p in baseline[:-1]:
            pos += len(p)
            base_cuts.add(pos)

        completions, edges = self._tables(s, target)
        if completions[0][target] == 0:
            return None

        NEG = float("-inf")
        best = [[NEG] * (target + 1) for _ in range(n + 1)]
        nxt: list[list[int]] = [[-1] * (target + 1) for _ in range(n + 1)]
        best[n][0] = 0.0
        for i in range(n - 1, -1, -1):
            for j in edges[i]:
                gain = 0.0 if (j == n or j in base_cuts) else 1.0
                for m in range(1, target + 1):
                    if best[j][m - 1] == NEG:
                        continue
                    val = best[j][m - 1] + gain
                    if val > best[i][m]:
                        best[i][m] = val
                        nxt[i][m] = j
        if best[0][target] == NEG:
            return None

        out: list[str] = []
        i, m = 0, target
        while m > 0:
            j = nxt[i][m]
            if j < 0:
                return None
            out.append(s[i:j])
            i, m = j, m - 1
        return out if i == n else None


class NaturalnessPerturber:
    """Apply N0/N1/N2 to a whole text under a given DialedTokenizer."""

    def __init__(self, dialed, base_vocab: Sequence[str] | None = None):
        self.dialed = dialed
        vocab = list(base_vocab if base_vocab is not None else dialed.vocab.keys())
        self.reseg = ChunkResegmenter(vocab)

    def apply(self, text: str, level: str, seed: int) -> Resegmentation:
        if level not in ("N0", "N1", "N2"):
            raise ValueError(f"unknown naturalness level {level!r}")

        rng = random.Random(seed)
        chunks = self.dialed.pre_tokenize(text)
        pieces: list[str] = []
        perturbed = 0

        for chunk, _offsets in chunks:
            baseline = self.dialed.encode_chunk_pieces(chunk)
            if level == "N0" or len(baseline) <= 1:
                pieces.extend(baseline)
                continue

            target = len(baseline)
            if level == "N1":
                alt = self.reseg.sample_uniform(chunk, target, rng, exclude=baseline)
            else:
                alt = self.reseg.maximise_deviation(chunk, target, baseline)
                if alt == baseline:
                    alt = None

            if alt is None:
                pieces.extend(baseline)
            else:
                pieces.extend(alt)
                perturbed += 1

        return Resegmentation(
            pieces=pieces,
            perturbed_chunks=perturbed,
            total_chunks=sum(1 for c, _ in chunks if len(self.dialed.encode_chunk_pieces(c)) > 1),
        )


def boundary_divergence(a: Sequence[str], b: Sequence[str]) -> float:
    """Fraction of a's internal boundaries that are absent from b.

    Used in tests to assert N2 deviates more than N1, and reported as a
    manipulation check in the paper.
    """
    def cuts(seq: Sequence[str]) -> set[int]:
        out, pos = set(), 0
        for p in list(seq)[:-1]:
            pos += len(p)
            out.add(pos)
        return out

    ca, cb = cuts(a), cuts(b)
    if not ca:
        return 0.0
    return len(ca - cb) / len(ca)
