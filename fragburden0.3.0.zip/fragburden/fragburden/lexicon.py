"""Surface lexicons for EN / TR / RU.

STATUS: the English table is complete.  The Turkish and Russian tables are
*starter* tables and are the subject of the Phase 4 gate in the work plan --
they require native-speaker sign-off before any main run, with particular
attention to dative/ablative edges, negation morphology, and evidential -mis.
Nothing downstream should be read as validated until that sign-off exists.

Design note: forms are stored explicitly rather than derived by procedural
suffixing.  Turkish consonant softening (kitap -> kitabi, gozluk -> gozlugu)
and Russian stem changes are exactly the places where a rule-based suffixer
silently produces a non-word, and a non-word changes the fragmentation profile
of the very token we are measuring.
"""

from __future__ import annotations

from dataclasses import dataclass, field

SIGNED_OFF = {"en": True, "tr": False, "ru": False}


@dataclass(frozen=True)
class Noun:
    """Case forms.  Keys are language-specific; see the tables below."""

    forms: dict[str, str]

    def __getitem__(self, case: str) -> str:
        try:
            return self.forms[case]
        except KeyError as exc:
            raise KeyError(
                f"missing case {case!r}; have {sorted(self.forms)}"
            ) from exc


def _n(**forms: str) -> Noun:
    return Noun(forms=dict(forms))


# ---------------------------------------------------------------------------
# English
# ---------------------------------------------------------------------------

EN = {
    "people": {
        "P1": _n(nom="Alice", dat="Alice", abl="Alice", gen="Alice's"),
        "P2": _n(nom="Brian", dat="Brian", abl="Brian", gen="Brian's"),
        "P3": _n(nom="Clara", dat="Clara", abl="Clara", gen="Clara's"),
        "P4": _n(nom="Dmitri", dat="Dmitri", abl="Dmitri", gen="Dmitri's"),
        "P5": _n(nom="Elena", dat="Elena", abl="Elena", gen="Elena's"),
        "P6": _n(nom="Farid", dat="Farid", abl="Farid", gen="Farid's"),
    },
    "objects": {
        "O1": _n(nom="the book", acc="the book", dat="the book", loc="the book"),
        "O2": _n(nom="the pen", acc="the pen", dat="the pen", loc="the pen"),
        "O3": _n(nom="the key", acc="the key", dat="the key", loc="the key"),
        "O4": _n(nom="the bag", acc="the bag", dat="the bag", loc="the bag"),
        "O5": _n(nom="the phone", acc="the phone", dat="the phone", loc="the phone"),
        "O6": _n(nom="the map", acc="the map", dat="the map", loc="the map"),
    },
    "places": {
        "L1": _n(nom="the kitchen", dat="to the kitchen", loc="in the kitchen",
                 abl="from the kitchen"),
        "L2": _n(nom="the garden", dat="to the garden", loc="in the garden",
                 abl="from the garden"),
        "L3": _n(nom="the office", dat="to the office", loc="in the office",
                 abl="from the office"),
        "L4": _n(nom="the library", dat="to the library", loc="in the library",
                 abl="from the library"),
        "L5": _n(nom="the garage", dat="to the garage", loc="in the garage",
                 abl="from the garage"),
        "L6": _n(nom="the lounge", dat="to the lounge", loc="in the lounge",
                 abl="from the lounge"),
    },
    "cities": ["Almera", "Bruning", "Corvale", "Dunmoor", "Eskrid", "Fallow",
               "Gethen", "Halvern"],
}

# ---------------------------------------------------------------------------
# Turkish  (STARTER -- requires native sign-off, Phase 4)
# ---------------------------------------------------------------------------

TR = {
    "people": {
        "P1": _n(nom="Ali", dat="Ali'ye", abl="Ali'den", gen="Ali'nin"),
        "P2": _n(nom="Ayşe", dat="Ayşe'ye", abl="Ayşe'den", gen="Ayşe'nin"),
        "P3": _n(nom="Mehmet", dat="Mehmet'e", abl="Mehmet'ten", gen="Mehmet'in"),
        "P4": _n(nom="Zeynep", dat="Zeynep'e", abl="Zeynep'ten", gen="Zeynep'in"),
        "P5": _n(nom="Can", dat="Can'a", abl="Can'dan", gen="Can'ın"),
        "P6": _n(nom="Elif", dat="Elif'e", abl="Elif'ten", gen="Elif'in"),
    },
    "objects": {
        # nom / acc / dat / abl / loc / gen
        "O1": _n(nom="kitap", acc="kitabı", dat="kitaba", abl="kitaptan",
                 loc="kitapta", gen="kitabın"),
        "O2": _n(nom="kalem", acc="kalemi", dat="kaleme", abl="kalemden",
                 loc="kalemde", gen="kalemin"),
        "O3": _n(nom="anahtar", acc="anahtarı", dat="anahtara", abl="anahtardan",
                 loc="anahtarda", gen="anahtarın"),
        "O4": _n(nom="çanta", acc="çantayı", dat="çantaya", abl="çantadan",
                 loc="çantada", gen="çantanın"),
        "O5": _n(nom="telefon", acc="telefonu", dat="telefona", abl="telefondan",
                 loc="telefonda", gen="telefonun"),
        "O6": _n(nom="harita", acc="haritayı", dat="haritaya", abl="haritadan",
                 loc="haritada", gen="haritanın"),
    },
    "places": {
        "L1": _n(nom="mutfak", dat="mutfağa", loc="mutfakta", abl="mutfaktan"),
        "L2": _n(nom="bahçe", dat="bahçeye", loc="bahçede", abl="bahçeden"),
        "L3": _n(nom="ofis", dat="ofise", loc="ofiste", abl="ofisten"),
        "L4": _n(nom="kütüphane", dat="kütüphaneye", loc="kütüphanede",
                 abl="kütüphaneden"),
        "L5": _n(nom="garaj", dat="garaja", loc="garajda", abl="garajdan"),
        "L6": _n(nom="salon", dat="salona", loc="salonda", abl="salondan"),
    },
    "cities": ["Almera", "Bruning", "Corvale", "Dunmoor", "Eskrid", "Fallow",
               "Gethen", "Halvern"],
}

# ---------------------------------------------------------------------------
# Russian  (STARTER -- requires native sign-off, Phase 4)
# ---------------------------------------------------------------------------

RU = {
    "people": {
        "P1": _n(nom="Иван", dat="Ивану", abl="Ивана", gen="Ивана"),
        "P2": _n(nom="Мария", dat="Марии", abl="Марии", gen="Марии"),
        "P3": _n(nom="Пётр", dat="Петру", abl="Петра", gen="Петра"),
        "P4": _n(nom="Ольга", dat="Ольге", abl="Ольги", gen="Ольги"),
        "P5": _n(nom="Сергей", dat="Сергею", abl="Сергея", gen="Сергея"),
        "P6": _n(nom="Анна", dat="Анне", abl="Анны", gen="Анны"),
    },
    "objects": {
        "O1": _n(nom="книга", acc="книгу", dat="книге", abl="книги",
                 loc="книге", gen="книги"),
        "O2": _n(nom="ручка", acc="ручку", dat="ручке", abl="ручки",
                 loc="ручке", gen="ручки"),
        "O3": _n(nom="ключ", acc="ключ", dat="ключу", abl="ключа",
                 loc="ключе", gen="ключа"),
        "O4": _n(nom="сумка", acc="сумку", dat="сумке", abl="сумки",
                 loc="сумке", gen="сумки"),
        "O5": _n(nom="телефон", acc="телефон", dat="телефону", abl="телефона",
                 loc="телефоне", gen="телефона"),
        "O6": _n(nom="карта", acc="карту", dat="карте", abl="карты",
                 loc="карте", gen="карты"),
    },
    "places": {
        "L1": _n(nom="кухня", dat="на кухню", loc="на кухне", abl="с кухни"),
        "L2": _n(nom="сад", dat="в сад", loc="в саду", abl="из сада"),
        "L3": _n(nom="офис", dat="в офис", loc="в офисе", abl="из офиса"),
        "L4": _n(nom="библиотека", dat="в библиотеку", loc="в библиотеке",
                 abl="из библиотеки"),
        "L5": _n(nom="гараж", dat="в гараж", loc="в гараже", abl="из гаража"),
        "L6": _n(nom="гостиная", dat="в гостиную", loc="в гостиной",
                 abl="из гостиной"),
    },
    "cities": ["Альмера", "Брунинг", "Корвейл", "Данмур", "Эскрид", "Фэллоу",
               "Гетен", "Хальверн"],
}

LEXICONS = {"en": EN, "tr": TR, "ru": RU}


# ---------------------------------------------------------------------------
# Templates.  Two verbosities per event kind per language.
# `verbose` carries connectives and redundant restatement; `compact` is
# telegraphic.  Both must realize exactly the same proposition -- that is what
# the ledger audit enforces.
#
# A template may be a string or a list of variants.  Variants matter for the
# negation family, where the same borrow/return event recurs several times in
# one instance: byte-identical repeated sentences are their own confound (a
# model can match on the repeat rather than track the state), and they also
# depress the fragmentation contrast by re-using an identical token sequence.
# `VARIANTS[kind]` rotates by event index.
# ---------------------------------------------------------------------------

# INVARIANT: within a kind, every variant must assign the SAME semantic role to
# the same placeholder.  For "borrow", {p_nom} is always the borrower (subject,
# nominative) and {q_abl} always the source (ablative / genitive-with-u).  A
# variant that flips the perspective -- "X lent it to Y" -- would need the
# opposite cases and silently inverts the proposition.  That is precisely the
# suffix-level equivalence failure sec. 7 flags for Turkish, and it is not
# catchable by back-translation.  Keep the roles fixed; vary only the wording.

TEMPLATE_VARIANTS: dict[str, dict[str, dict[str, list[str]]]] = {
    "en": {
        "borrow": {
            "verbose": [
                "At that point {p_nom} borrowed {o_acc} from {q_abl} for a while.",
                "Later on, {p_nom} asked {q_abl} for {o_acc} and took it away.",
                "Shortly after, {p_nom} obtained {o_acc} from {q_abl}.",
                "A while later, {p_nom} collected {o_acc} from {q_abl}.",
            ],
            "compact": [
                "{p_nom} borrowed {o_acc} from {q_abl}.",
                "{p_nom} took {o_acc} from {q_abl}.",
                "{p_nom} obtained {o_acc} from {q_abl}.",
                "{p_nom} collected {o_acc} from {q_abl}.",
            ],
        },
        "return": {
            "verbose": [
                "Not long afterwards, {p_nom} gave {o_acc} back to {q_dat}.",
                "Once finished, {p_nom} handed {o_acc} back to {q_dat}.",
                "Before leaving, {p_nom} returned {o_acc} to {q_dat}.",
                "The next day, {p_nom} passed {o_acc} back to {q_dat}.",
            ],
            "compact": [
                "{p_nom} returned {o_acc} to {q_dat}.",
                "{p_nom} gave {o_acc} back to {q_dat}.",
                "{p_nom} handed {o_acc} back to {q_dat}.",
                "{p_nom} passed {o_acc} back to {q_dat}.",
            ],
        },
    },
    "tr": {
        "borrow": {
            "verbose": [
                "O sırada {p_nom} {o_acc} {q_abl} bir süreliğine ödünç aldı.",
                "Daha sonra {p_nom} {q_abl} {o_acc} istedi ve yanına aldı.",
                "Kısa bir süre sonra {p_nom} {o_acc} {q_abl} teslim aldı.",
                "Bir süre sonra {p_nom} {o_acc} {q_abl} ödünç aldı ve götürdü.",
            ],
            "compact": [
                "{p_nom} {o_acc} {q_abl} ödünç aldı.",
                "{p_nom} {o_acc} {q_abl} aldı.",
                "{p_nom} {o_acc} {q_abl} teslim aldı.",
                "{p_nom}, {o_acc} {q_abl} ödünç aldı.",
            ],
        },
        "return": {
            "verbose": [
                "Çok geçmeden {p_nom} {o_acc} {q_dat} geri verdi.",
                "İşi bitince {p_nom} {o_acc} {q_dat} iade etti.",
                "Ayrılmadan önce {p_nom} {o_acc} {q_dat} teslim etti.",
                "Ertesi gün {p_nom} {o_acc} {q_dat} geri getirdi.",
            ],
            "compact": [
                "{p_nom} {o_acc} {q_dat} geri verdi.",
                "{p_nom} {o_acc} {q_dat} iade etti.",
                "{p_nom} {o_acc} {q_dat} teslim etti.",
                "{p_nom} {o_acc} {q_dat} geri getirdi.",
            ],
        },
    },
    "ru": {
        "borrow": {
            "verbose": [
                "В тот момент {p_nom} одолжил {o_acc} у {q_abl} на время.",
                "Позже {p_nom} попросил {o_acc} у {q_abl} и забрал с собой.",
                "Вскоре {p_nom} взял {o_acc} у {q_abl}.",
                "Через некоторое время {p_nom} получил {o_acc} от {q_abl}.",
            ],
            "compact": [
                "{p_nom} одолжил {o_acc} у {q_abl}.",
                "{p_nom} забрал {o_acc} у {q_abl}.",
                "{p_nom} взял {o_acc} у {q_abl}.",
                "{p_nom} получил {o_acc} от {q_abl}.",
            ],
        },
        "return": {
            "verbose": [
                "Вскоре после этого {p_nom} вернул {o_acc} {q_dat}.",
                "Закончив, {p_nom} отдал {o_acc} обратно {q_dat}.",
                "Перед уходом {p_nom} передал {o_acc} обратно {q_dat}.",
                "На следующий день {p_nom} принёс {o_acc} обратно {q_dat}.",
            ],
            "compact": [
                "{p_nom} вернул {o_acc} {q_dat}.",
                "{p_nom} отдал {o_acc} обратно {q_dat}.",
                "{p_nom} передал {o_acc} обратно {q_dat}.",
                "{p_nom} принёс {o_acc} обратно {q_dat}.",
            ],
        },
    },
}


def n_variants(language: str, kind: str, verbosity: str) -> int:
    v = TEMPLATE_VARIANTS.get(language, {}).get(kind, {}).get(verbosity)
    return len(v) if v else 1


def max_complexity(language: str, verbosity: str = "verbose") -> int:
    """Largest hop count the negation family can realize without repeating a
    sentence verbatim.  cycles + 1 borrow events must each get a distinct
    variant, so complexity <= 2 * (n_variants - 1)."""
    v = min(n_variants(language, "borrow", verbosity),
            n_variants(language, "return", verbosity))
    return max(2, 2 * (v - 1))

TEMPLATES: dict[str, dict[str, dict[str, str]]] = {
    "en": {
        "take":    {"verbose": "A little later, {p_nom} picked up {o_acc} and held on to it.",
                    "compact": "{p_nom} took {o_acc}."},
        "give":    {"verbose": "Some time after that, {p_nom} handed {o_acc} over to {q_dat}.",
                    "compact": "{p_nom} gave {o_acc} to {q_dat}."},
        "borrow":  {"verbose": "At that point {p_nom} borrowed {o_acc} from {q_abl} for a while.",
                    "compact": "{p_nom} borrowed {o_acc} from {q_abl}."},
        "return":  {"verbose": "Not long afterwards, {p_nom} gave {o_acc} back to {q_dat}.",
                    "compact": "{p_nom} returned {o_acc} to {q_dat}."},
        "place":   {"verbose": "Then {p_nom} carried {o_acc} and left it {l_loc}.",
                    "compact": "{p_nom} put {o_acc} {l_loc}."},
        "edge":    {"verbose": "There is a direct connection running from {a} to {b}.",
                    "compact": "{a} to {b}."},
        "fact":    {"verbose": "It is recorded that the code for {o_nom} is {v}.",
                    "compact": "{o_nom} code: {v}."},
        "filler":  {"verbose": "The weather over {city} stayed unremarkable for most of the day, and nothing of note was reported.",
                    "compact": "{city}: nothing reported."},
    },
    "tr": {
        "take":    {"verbose": "Biraz sonra {p_nom} {o_acc} eline aldı ve yanında tuttu.",
                    "compact": "{p_nom} {o_acc} aldı."},
        "give":    {"verbose": "Bir süre sonra {p_nom} {o_acc} {q_dat} teslim etti.",
                    "compact": "{p_nom} {o_acc} {q_dat} verdi."},
        "borrow":  {"verbose": "O sırada {p_nom} {o_acc} {q_abl} bir süreliğine ödünç aldı.",
                    "compact": "{p_nom} {o_acc} {q_abl} ödünç aldı."},
        "return":  {"verbose": "Çok geçmeden {p_nom} {o_acc} {q_dat} geri verdi.",
                    "compact": "{p_nom} {o_acc} {q_dat} geri verdi."},
        "place":   {"verbose": "Ardından {p_nom} {o_acc} taşıyıp {l_loc} bıraktı.",
                    "compact": "{p_nom} {o_acc} {l_loc} bıraktı."},
        "edge":    {"verbose": "{a} ile {b} arasında doğrudan bir bağlantı bulunmaktadır.",
                    "compact": "{a} - {b}."},
        "fact":    {"verbose": "Kayıtlara göre {o_nom} için kod {v} olarak geçmektedir.",
                    "compact": "{o_nom} kodu: {v}."},
        "filler":  {"verbose": "{city} üzerindeki hava günün büyük bölümünde sıradan kaldı ve kayda değer bir şey bildirilmedi.",
                    "compact": "{city}: bildirim yok."},
    },
    "ru": {
        "take":    {"verbose": "Немного позже {p_nom} взял {o_acc} и оставил у себя.",
                    "compact": "{p_nom} взял {o_acc}."},
        "give":    {"verbose": "Через некоторое время {p_nom} передал {o_acc} {q_dat}.",
                    "compact": "{p_nom} отдал {o_acc} {q_dat}."},
        "borrow":  {"verbose": "В тот момент {p_nom} одолжил {o_acc} у {q_abl} на время.",
                    "compact": "{p_nom} одолжил {o_acc} у {q_abl}."},
        "return":  {"verbose": "Вскоре после этого {p_nom} вернул {o_acc} {q_dat}.",
                    "compact": "{p_nom} вернул {o_acc} {q_dat}."},
        "place":   {"verbose": "Затем {p_nom} отнёс {o_acc} и оставил {l_loc}.",
                    "compact": "{p_nom} положил {o_acc} {l_loc}."},
        "edge":    {"verbose": "Между {a} и {b} есть прямое сообщение.",
                    "compact": "{a} - {b}."},
        "fact":    {"verbose": "В записях указано, что код для {o_nom} — {v}.",
                    "compact": "{o_nom}, код: {v}."},
        "filler":  {"verbose": "Погода над {city} большую часть дня оставалась обычной, ничего примечательного не отмечено.",
                    "compact": "{city}: без сообщений."},
    },
}

QUERIES = {
    "en": {
        "possession": "Question: who has {o_nom} at the end?",
        "location": "Question: where is {o_nom} at the end?",
        "reachability": "Question: can you travel from {a} to {b} using the connections above?",
        "retrieval": "Question: what is the code for {o_nom}?",
    },
    "tr": {
        "possession": "Soru: sonunda {o_nom} kimde?",
        "location": "Soru: sonunda {o_nom} nerede?",
        "reachability": "Soru: yukarıdaki bağlantıları kullanarak {a} şehrinden {b} şehrine gidilebilir mi?",
        "retrieval": "Soru: {o_nom} için kod nedir?",
    },
    "ru": {
        "possession": "Вопрос: у кого {o_nom} в конце?",
        "location": "Вопрос: где {o_nom} в конце?",
        "reachability": "Вопрос: можно ли добраться из {a} в {b} по указанным сообщениям?",
        "retrieval": "Вопрос: какой код у {o_nom}?",
    },
}

INSTRUCTIONS = {
    "en": "Read the report and answer with a single letter.",
    "tr": "Raporu oku ve tek bir harfle cevap ver.",
    "ru": "Прочитайте отчёт и ответьте одной буквой.",
}

YES_NO = {
    "en": {"yes": "Yes", "no": "No"},
    "tr": {"yes": "Evet", "no": "Hayır"},
    "ru": {"yes": "Да", "no": "Нет"},
}


def lexicon(language: str) -> dict:
    try:
        return LEXICONS[language]
    except KeyError as exc:
        raise KeyError(f"no lexicon for {language!r}") from exc


def sign_off_status() -> dict[str, bool]:
    """Phase 4 gate state.  The runner refuses main runs on unsigned lexicons
    unless explicitly overridden."""
    return dict(SIGNED_OFF)
