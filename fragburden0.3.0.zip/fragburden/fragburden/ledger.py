"""Proposition ledger: the spine shared by every realization.

Every problem instance is generated as a language-neutral object carrying an
explicit list of the atomic facts required for the answer.  Three things depend
on it:

  * Equivalence auditing.  A Turkish or Russian realization is valid only if
    every required proposition survives it.  Suffix-level edges (dative vs.
    ablative, negation morphology, evidential -mis) can alter a fact without
    changing a whole word, which back-translation will not catch, so the audit
    checks surface realizations against the ledger directly.
  * Diagnostic distractors.  Each incorrect option is generated from a specific
    ledger failure, so every item yields an error *type* rather than a single
    correctness bit, at no extra compute and with no judge model.
  * Epsilon, for the Theorem 4.3 bound check.  The span from the earliest
    required proposition to the query is measured in tokens per item.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal

ErrorType = Literal[
    "correct",
    "dropped_proposition",
    "misbound_entity",
    "missed_update",
    "pre_cancellation",
]


@dataclass(frozen=True)
class Proposition:
    """One atomic fact.  `key` must be stable across languages."""

    kind: str                     # e.g. "possession", "location", "edge"
    args: tuple[Any, ...]
    required: bool = True

    @property
    def key(self) -> str:
        return f"{self.kind}({','.join(map(str, self.args))})"


@dataclass
class Realization:
    """A proposition rendered in one language at one verbosity."""

    proposition_index: int | None   # None for filler
    text: str
    is_filler: bool = False


@dataclass
class Ledger:
    propositions: list[Proposition] = field(default_factory=list)
    answer: str = ""
    answer_key: str = ""
    query: str = ""
    options: dict[str, str] = field(default_factory=dict)      # letter -> text
    option_errors: dict[str, ErrorType] = field(default_factory=dict)
    realizations: list[Realization] = field(default_factory=list)
    meta: dict = field(default_factory=dict)

    # -- required set -----------------------------------------------------
    @property
    def required_indices(self) -> list[int]:
        return [i for i, p in enumerate(self.propositions) if p.required]

    # -- audit ------------------------------------------------------------
    def audit(self) -> list[str]:
        """Return a list of failures.  Empty list means the instance is valid.

        The Phase 3 gate is *zero* failures at scale.
        """
        failures: list[str] = []

        realized = {
            r.proposition_index
            for r in self.realizations
            if r.proposition_index is not None
        }
        for i in self.required_indices:
            if i not in realized:
                failures.append(
                    f"required proposition {i} ({self.propositions[i].key}) "
                    "has no realization"
                )

        if not self.answer:
            failures.append("empty answer")
        if self.answer_key not in self.options:
            failures.append(
                f"answer_key {self.answer_key!r} not among options "
                f"{sorted(self.options)}"
            )
        elif self.options[self.answer_key] != self.answer:
            failures.append(
                f"option {self.answer_key} is {self.options[self.answer_key]!r} "
                f"but answer is {self.answer!r}"
            )

        texts = list(self.options.values())
        if len(set(texts)) != len(texts):
            failures.append("duplicate option surface forms")

        for letter in self.options:
            if letter not in self.option_errors:
                failures.append(f"option {letter} has no error type")
        if self.option_errors.get(self.answer_key) != "correct":
            failures.append("answer option is not typed 'correct'")

        n_correct = sum(1 for e in self.option_errors.values() if e == "correct")
        if n_correct != 1:
            failures.append(f"{n_correct} options typed 'correct', expected 1")

        return failures

    def is_valid(self) -> bool:
        return not self.audit()

    # -- epsilon support --------------------------------------------------
    def required_span_chars(self) -> tuple[int, int]:
        """Char span from the first required realization to the end of the body."""
        pos = 0
        first = None
        for r in self.realizations:
            if r.proposition_index is not None and self.propositions[
                r.proposition_index
            ].required:
                if first is None:
                    first = pos
            pos += len(r.text) + 1
        return (first if first is not None else 0, pos)

    def body(self) -> str:
        return " ".join(r.text for r in self.realizations)

    def prompt(self, instruction: str) -> str:
        opts = "\n".join(f"{k}. {v}" for k, v in sorted(self.options.items()))
        return f"{instruction}\n\n{self.body()}\n\n{self.query}\n{opts}\nAnswer:"


def audit_batch(ledgers: list[Ledger]) -> dict:
    """Summary suitable for the Phase 3 gate."""
    failures = {}
    for i, lg in enumerate(ledgers):
        f = lg.audit()
        if f:
            failures[i] = f
    return {
        "n": len(ledgers),
        "n_failed": len(failures),
        "pass_rate": 1.0 - (len(failures) / len(ledgers) if ledgers else 0),
        "failures": failures,
    }
