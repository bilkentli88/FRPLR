"""The fragmentation dial.

Primary method (proposal v0.3 sec. 4.1): merge-rank truncation.  A BPE merge
table is an ordered list; truncating it at rank k yields a coarser-to-finer
segmentation dial with two properties we need:

  1. Monotone.  Fewer merges never produces fewer tokens.
  2. In-vocabulary.  Every token produced by a truncated merge table is itself
     an intermediate merge, hence already present in the original vocabulary,
     so token IDs stay valid and the embedding matrix is untouched.

Fallback method (proposal v0.3 sec. 5.3): vocabulary restriction, for
tokenizers whose merge ranks are not recoverable (Gemma 3's SentencePiece
Unigram vocabulary is the motivating case).  Pieces longer than a
length threshold are pushed to a very low log-probability so Viterbi decoding
avoids them.  Also monotone, also in-vocabulary, but the induced phi levels do
not align numerically with the BPE dial -- which is why the dial *type* is
recorded on every result row.

Neither method touches model weights.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from typing import Iterable, Sequence

from tokenizers import Tokenizer

_LOWEST_LOGPROB = -1e6


class DialError(RuntimeError):
    pass


# ---------------------------------------------------------------------------
# merge-table helpers -- the on-disk format changed across `tokenizers`
# releases (list of "a b" strings in older versions, list of [a, b] pairs in
# newer ones).  Normalise on read, restore on write.
# ---------------------------------------------------------------------------

def _merges_are_pairs(merges: Sequence) -> bool:
    return bool(merges) and isinstance(merges[0], (list, tuple))


def _merge_key(merge) -> str:
    if isinstance(merge, (list, tuple)):
        return " ".join(merge)
    return str(merge)


@dataclass(frozen=True)
class DialedTokenizer:
    """A tokenizer at one setting of the fragmentation dial."""

    tokenizer: Tokenizer
    keep_pct: int
    dial_type: str            # "merge_rank" | "vocab_restrict" | "identity"
    fingerprint: str
    n_merges_kept: int | None = None
    max_piece_len: int | None = None

    # -- encoding ---------------------------------------------------------
    def pre_tokenize(self, text: str) -> list[tuple[str, tuple[int, int]]]:
        """Split text into pre-token chunks with char offsets into `text`."""
        pt = self.tokenizer.pre_tokenizer
        if pt is None:
            return [(text, (0, len(text)))]
        return [(chunk, off) for chunk, off in pt.pre_tokenize_str(text)]

    def encode_pieces(self, text: str) -> list[str]:
        return self.tokenizer.encode(text, add_special_tokens=False).tokens

    def encode_chunk_pieces(self, chunk: str) -> list[str]:
        """Segment a single pre-token chunk, bypassing pre-tokenization.

        The chunk string is already in the tokenizer's internal alphabet (e.g.
        byte-level, with the leading-space marker), so pre-tokenizing it again
        would be wrong.  We therefore encode with the pre-tokenizer disabled.
        """
        return _encode_no_pretok(self.tokenizer, chunk)

    def pieces_to_ids(self, pieces: Iterable[str]) -> list[int]:
        vocab = self.vocab
        out = []
        for p in pieces:
            if p not in vocab:
                raise DialError(f"piece {p!r} is not in the vocabulary")
            out.append(vocab[p])
        return out

    @property
    def vocab(self) -> dict[str, int]:
        if not hasattr(self, "_vocab_cache"):
            object.__setattr__(self, "_vocab_cache", self.tokenizer.get_vocab())
        return self._vocab_cache  # type: ignore[attr-defined]

    def count(self, text: str) -> int:
        return len(self.encode_pieces(text))


_NO_PRETOK_CACHE: dict[int, Tokenizer] = {}


def _encode_no_pretok(tk: Tokenizer, chunk: str) -> list[str]:
    """Encode a pre-tokenized chunk without re-applying pre-tokenization."""
    key = id(tk)
    clone = _NO_PRETOK_CACHE.get(key)
    if clone is None:
        state = json.loads(tk.to_str())
        state["pre_tokenizer"] = None
        state["normalizer"] = None
        clone = Tokenizer.from_str(json.dumps(state))
        _NO_PRETOK_CACHE[key] = clone
    return clone.encode(chunk, add_special_tokens=False).tokens


# ---------------------------------------------------------------------------


class FragmentationDial:
    """Builds DialedTokenizers at requested settings from a base tokenizer."""

    def __init__(self, tokenizer: Tokenizer, name: str = "unnamed"):
        self.base = tokenizer
        self.name = name
        self._state = json.loads(tokenizer.to_str())
        self._model_type = self._state["model"]["type"]
        self._cache: dict[int, DialedTokenizer] = {}

    # -- construction -----------------------------------------------------
    @classmethod
    def from_pretrained(cls, name: str) -> "FragmentationDial":
        return cls(Tokenizer.from_pretrained(name), name=name)

    @classmethod
    def from_file(cls, path: str, name: str | None = None) -> "FragmentationDial":
        return cls(Tokenizer.from_file(path), name=name or path)

    @classmethod
    def from_transformers(cls, hf_tokenizer, name: str | None = None) -> "FragmentationDial":
        backend = getattr(hf_tokenizer, "backend_tokenizer", None)
        if backend is None:
            raise DialError(
                "need a fast (Rust-backed) tokenizer; got "
                f"{type(hf_tokenizer).__name__}. Load with use_fast=True."
            )
        return cls(backend, name=name or getattr(hf_tokenizer, "name_or_path", "hf"))

    # -- capability probe -------------------------------------------------
    def capability(self) -> dict:
        """What kind of dial is available for this tokenizer.

        Run this in Phase 1 before pre-registration.  It is the check that
        decides whether Gemma 3 can carry Arm A (proposal v0.3 sec. 5.3).
        """
        model = self._state["model"]
        mtype = model.get("type")
        merges = model.get("merges") or []
        info = {
            "tokenizer": self.name,
            "model_type": mtype,
            "vocab_size": len(model.get("vocab") or []),
            "n_merges": len(merges),
            "merge_rank_available": bool(mtype == "BPE" and merges),
            "vocab_restrict_available": mtype in ("Unigram", "BPE", "WordPiece"),
        }
        info["dial_type"] = (
            "merge_rank" if info["merge_rank_available"]
            else ("vocab_restrict" if info["vocab_restrict_available"] else "none")
        )
        info["usable_for_arm_a"] = info["dial_type"] != "none"
        return info

    # -- the dial ---------------------------------------------------------
    def at(self, keep_pct: int) -> DialedTokenizer:
        if not 1 <= keep_pct <= 100:
            raise ValueError("keep_pct must be in 1..100")
        if keep_pct in self._cache:
            return self._cache[keep_pct]

        cap = self.capability()
        if keep_pct == 100:
            dialed = DialedTokenizer(
                tokenizer=Tokenizer.from_str(json.dumps(self._state)),
                keep_pct=100,
                dial_type="identity",
                fingerprint=self._fingerprint(self._state),
            )
        elif cap["dial_type"] == "merge_rank":
            dialed = self._truncate_merges(keep_pct)
        elif cap["dial_type"] == "vocab_restrict":
            dialed = self._restrict_vocab(keep_pct)
        else:
            raise DialError(
                f"no fragmentation dial available for model type {cap['model_type']!r}"
            )
        self._cache[keep_pct] = dialed
        return dialed

    # -- implementations --------------------------------------------------
    def _truncate_merges(self, keep_pct: int) -> DialedTokenizer:
        state = json.loads(json.dumps(self._state))  # deep copy
        merges = state["model"]["merges"]
        keep = max(1, int(round(len(merges) * keep_pct / 100.0)))
        state["model"]["merges"] = merges[:keep]
        # Dropping merges can orphan `dropout`/cache assumptions; make the
        # segmentation deterministic.
        state["model"]["dropout"] = None
        tk = Tokenizer.from_str(json.dumps(state))
        return DialedTokenizer(
            tokenizer=tk,
            keep_pct=keep_pct,
            dial_type="merge_rank",
            fingerprint=self._fingerprint(state),
            n_merges_kept=keep,
        )

    def _restrict_vocab(self, keep_pct: int) -> DialedTokenizer:
        """Length-thresholded vocabulary restriction.

        The threshold is chosen as the keep_pct-th percentile of piece lengths,
        so the dial is monotone in keep_pct and comparable in spirit -- though
        not in numeric value -- to the merge-rank dial.
        """
        state = json.loads(json.dumps(self._state))
        model = state["model"]
        mtype = model["type"]

        if mtype == "Unigram":
            entries = model["vocab"]  # list of [piece, logprob]
            lengths = sorted(len(e[0]) for e in entries)
            idx = min(len(lengths) - 1, max(0, int(len(lengths) * keep_pct / 100.0)))
            max_len = max(1, lengths[idx])
            for e in entries:
                if len(e[0]) > max_len:
                    e[1] = _LOWEST_LOGPROB
        else:
            # BPE/WordPiece without usable merges: drop long pieces from the
            # vocab entirely.  IDs of surviving pieces are preserved.
            vocab = model["vocab"]
            lengths = sorted(len(p) for p in vocab)
            idx = min(len(lengths) - 1, max(0, int(len(lengths) * keep_pct / 100.0)))
            max_len = max(1, lengths[idx])
            model["vocab"] = {p: i for p, i in vocab.items() if len(p) <= max_len}
            if mtype == "BPE":
                model["merges"] = [
                    m for m in model.get("merges", [])
                    if len("".join(m) if isinstance(m, (list, tuple)) else m.replace(" ", ""))
                    <= max_len
                ]

        tk = Tokenizer.from_str(json.dumps(state))
        return DialedTokenizer(
            tokenizer=tk,
            keep_pct=keep_pct,
            dial_type="vocab_restrict",
            fingerprint=self._fingerprint(state),
            max_piece_len=max_len,
        )

    # -- provenance -------------------------------------------------------
    @staticmethod
    def _fingerprint(state: dict) -> str:
        """Hash of the model section only.

        Logged on every result row so that a changed encoding path invalidates
        exactly the affected rows.
        """
        model = state["model"]
        merges = model.get("merges") or []
        payload = {
            "type": model.get("type"),
            "n_vocab": len(model.get("vocab") or []),
            "n_merges": len(merges),
            "merges_head": [_merge_key(m) for m in merges[:64]],
            "merges_tail": [_merge_key(m) for m in merges[-64:]],
        }
        blob = json.dumps(payload, sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(blob.encode("utf-8")).hexdigest()[:16]


def verify_monotone(dial: FragmentationDial, texts: Sequence[str],
                    levels: Sequence[int] = (100, 75, 50, 25)) -> dict:
    """Check the dial is monotone and in-vocabulary on real text.

    This is a gate, not a nicety: a non-monotone dial makes the phi
    coefficient uninterpretable.
    """
    base_vocab = set(dial.base.get_vocab())
    counts: dict[int, int] = {}
    oov: dict[int, int] = {}
    for lvl in sorted(levels, reverse=True):
        d = dial.at(lvl)
        total, bad = 0, 0
        for t in texts:
            pieces = d.encode_pieces(t)
            total += len(pieces)
            bad += sum(1 for p in pieces if p not in base_vocab)
        counts[lvl] = total
        oov[lvl] = bad
    ordered = [counts[l] for l in sorted(levels, reverse=True)]
    monotone = all(a <= b for a, b in zip(ordered, ordered[1:]))
    return {
        "counts": counts,
        "oov": oov,
        "monotone_nondecreasing": monotone,
        "all_in_vocab": all(v == 0 for v in oov.values()),
        "phi": {l: counts[l] / counts[max(levels)] for l in counts},
    }
