"""Item specification and deterministic identity.

Every experimental item is fully described by an ItemSpec.  Its ID is a hash of
the canonical form of that spec, so:

  * nothing depends on execution order,
  * the same cell always produces the same IDs across sessions and machines,
  * resume is a set difference.

The tokenizer fingerprint is deliberately NOT part of the ID.  It is logged on
the result row instead, so a silent change in the encoding path invalidates the
affected rows without renaming every item in the grid (proposal v0.3 sec. 6.3).
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, asdict, field
from typing import Any

# Factor level vocabularies.  Kept here so that a typo becomes an error at
# construction time rather than a silently empty cell at analysis time.
ARMS = ("A", "B")
FAMILIES = ("state_tracking", "negation", "reachability", "retrieval")
LANGUAGES = ("en", "tr", "ru")
NATURALNESS = ("N0", "N1", "N2")
REALIZATIONS = ("na", "verbose", "compact", "compact_filler")
MATCHING = ("content", "token")
PHI_LEVELS = (100, 75, 50, 25)  # percent of the merge table retained


@dataclass(frozen=True, order=True)
class ItemSpec:
    """One forward pass worth of experimental condition."""

    arm: str
    family: str
    language: str
    model: str
    phi_level: int
    naturalness: str
    target_tokens: int
    complexity: int
    matching: str
    realization: str
    seed: int

    def __post_init__(self) -> None:
        def check(name: str, value: Any, allowed: tuple) -> None:
            if value not in allowed:
                raise ValueError(f"{name}={value!r} not in {allowed}")

        check("arm", self.arm, ARMS)
        check("family", self.family, FAMILIES)
        check("language", self.language, LANGUAGES)
        check("naturalness", self.naturalness, NATURALNESS)
        check("realization", self.realization, REALIZATIONS)
        check("matching", self.matching, MATCHING)
        check("phi_level", self.phi_level, PHI_LEVELS)
        if self.complexity < 1:
            raise ValueError("complexity must be >= 1")
        if self.target_tokens < 64:
            raise ValueError("target_tokens must be >= 64")

    # -- identity ---------------------------------------------------------
    def canonical(self) -> str:
        return json.dumps(asdict(self), sort_keys=True, separators=(",", ":"))

    @property
    def id(self) -> str:
        return hashlib.sha256(self.canonical().encode("utf-8")).hexdigest()[:24]

    # -- convenience ------------------------------------------------------
    @property
    def cell(self) -> str:
        """Cell key: the spec without the seed.  Used for reconciliation."""
        d = asdict(self)
        d.pop("seed")
        return json.dumps(d, sort_keys=True, separators=(",", ":"))

    def to_row(self) -> dict:
        d = asdict(self)
        d["item_id"] = self.id
        return d

    @classmethod
    def from_row(cls, row: dict) -> "ItemSpec":
        fields = {
            k: row[k]
            for k in (
                "arm", "family", "language", "model", "phi_level",
                "naturalness", "target_tokens", "complexity", "matching",
                "realization", "seed",
            )
        }
        return cls(**fields)


@dataclass
class ItemResult:
    """What the runner writes, one JSON line per completed item."""

    item_id: str
    spec: ItemSpec
    correct: bool
    predicted: str
    gold: str
    error_type: str | None            # diagnostic distractor classification
    realized_tokens: int              # tokens actually fed to the model
    baseline_tokens: int              # tokens under the undialed tokenizer
    fragmentation_ratio: float        # realized / baseline
    compression_rate: float           # source chars per token  (R_Z)
    required_span_tokens: int         # for epsilon estimation
    perturbable_fraction: float       # naturalness realisability diagnostic
    tokenizer_fingerprint: str
    wall_seconds: float
    schema_version: int = 1
    extra: dict = field(default_factory=dict)

    def to_json(self) -> str:
        d = self.spec.to_row()
        d.update(
            {
                "correct": bool(self.correct),
                "predicted": self.predicted,
                "gold": self.gold,
                "error_type": self.error_type,
                "realized_tokens": self.realized_tokens,
                "baseline_tokens": self.baseline_tokens,
                "fragmentation_ratio": round(self.fragmentation_ratio, 6),
                "compression_rate": round(self.compression_rate, 6),
                "required_span_tokens": self.required_span_tokens,
                "perturbable_fraction": round(self.perturbable_fraction, 6),
                "tokenizer_fingerprint": self.tokenizer_fingerprint,
                "wall_seconds": round(self.wall_seconds, 4),
                "schema_version": self.schema_version,
            }
        )
        d.update(self.extra)
        return json.dumps(d, sort_keys=True, separators=(",", ":"))
