"""Analysis (proposal v0.3 sec. 7).

Five things, in the order the paper reports them:

  1. primary_model        fragmentation x naturalness x log(tokens)
  2. naturalness_check    the identification gate -- does N0->N1->N2 scale with phi?
  3. exchange_rate        g(N) such that TR at N matches EN at g(N)
  4. phase_deficit        length-invariant vs length-growing shares of the penalty
  5. thm43_check          the Theorem 4.3 bound, in measured quantities

statsmodels is an optional dependency; the descriptive paths work without it.
"""

from __future__ import annotations

import math
import warnings
from dataclasses import dataclass, field
from typing import Sequence

import numpy as np
import pandas as pd

from .burden import epsilon, estimate_effective_window, theorem_43_bound

PHI_NOMINAL = {100: 1.0, 75: 0.75, 50: 0.50, 25: 0.25}


def load(path: str) -> pd.DataFrame:
    df = pd.read_json(path, lines=True)
    if df.empty:
        return df
    df["correct"] = df["correct"].astype(int)
    df["log_tokens"] = np.log(df["realized_tokens"].clip(lower=1))
    df["phi"] = df["fragmentation_ratio"]
    # instance identity for clustering: everything but the segmentation factors
    df["instance"] = (
        df["family"] + "|" + df["language"] + "|" + df["matching"] + "|"
        + df["realization"] + "|" + df["complexity"].astype(str) + "|"
        + df["target_tokens"].astype(str) + "|" + df["seed"].astype(str)
    )
    return df


def provenance(df: pd.DataFrame) -> dict:
    """Refuse to let stub runs be mistaken for results."""
    models = sorted(df["model"].unique()) if not df.empty else []
    fps = sorted(df["tokenizer_fingerprint"].unique()) if not df.empty else []
    return {
        "n_rows": len(df),
        "models": models,
        "contains_stub": any("stub" in m for m in models),
        "substantive": not any("stub" in m for m in models),
        "tokenizer_fingerprints": fps,
        "fingerprint_conflict": len(fps) > 1,
    }


# ---------------------------------------------------------------------------
# 1. primary model
# ---------------------------------------------------------------------------

def primary_model(df: pd.DataFrame, cluster: str = "instance"):
    """Logistic regression with cluster-robust SEs by paired instance.

    Note the change from v0.2: naturalness enters as an *interaction* with phi,
    not as an additive covariate.  Distractor load and evidence position do not
    appear, having been fixed by design.
    """
    try:
        import statsmodels.formula.api as smf
    except ImportError as exc:  # pragma: no cover
        raise ImportError("pip install statsmodels for the primary model") from exc

    d = df[df["arm"] == "A"].copy()
    if d.empty:
        raise ValueError("no Arm A rows")
    d["nat"] = pd.Categorical(d["naturalness"], categories=["N0", "N1", "N2"])
    formula = (
        "correct ~ phi * C(nat) * log_tokens + phi:complexity "
        "+ C(language) + C(model)"
    )
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        model = smf.logit(formula, data=d)
        return model.fit(
            disp=False, cov_type="cluster",
            cov_kwds={"groups": d[cluster]}, maxiter=200,
        )


# ---------------------------------------------------------------------------
# 2. naturalness identification gate
# ---------------------------------------------------------------------------

@dataclass
class NaturalnessCheck:
    per_phi: pd.DataFrame
    slope_varies_with_phi: bool
    identified: bool
    note: str

    def __str__(self) -> str:
        return (
            f"{self.per_phi.to_string(index=False)}\n"
            f"slope varies with phi : {self.slope_varies_with_phi}\n"
            f"fragmentation identified: {self.identified}\n{self.note}"
        )


def naturalness_check(df: pd.DataFrame, ratio_threshold: float = 1.0
                      ) -> NaturalnessCheck:
    """The pre-registered non-identification test (sec. 4.2, P2).

    At each dial setting the token count is matched, so the N0->N2 accuracy
    drop estimates the local off-distribution penalty with fragmentation held
    fixed.  If that penalty is comparable to or larger than the fragmentation
    slope at *every* setting, Arm A does not identify the effect and the paper
    reports a non-identification.
    """
    d = df[(df["arm"] == "A")]
    rows = []
    for phi_level, g in d.groupby("phi_level"):
        by_nat = g.groupby("naturalness")["correct"].agg(["mean", "count"])
        n0 = by_nat["mean"].get("N0", np.nan)
        n1 = by_nat["mean"].get("N1", np.nan)
        n2 = by_nat["mean"].get("N2", np.nan)
        far = n2 if not math.isnan(n2 if n2 is not None else float("nan")) else n1
        rows.append({
            "phi_level": phi_level,
            "acc_N0": n0, "acc_N1": n1, "acc_N2": n2,
            "naturalness_penalty": (n0 - far) if far == far else np.nan,
            "n": int(by_nat["count"].sum()),
        })
    per_phi = pd.DataFrame(rows).sort_values("phi_level", ascending=False)

    base = per_phi[per_phi["phi_level"] == 100]["acc_N0"]
    frag_slopes = []
    for _, r in per_phi.iterrows():
        if not base.empty and r["phi_level"] != 100:
            frag_slopes.append(float(base.iloc[0]) - float(r["acc_N0"]))
    frag_effect = max(frag_slopes) if frag_slopes else float("nan")

    pens = per_phi["naturalness_penalty"].dropna()
    varies = bool(len(pens) > 1 and (pens.max() - pens.min()) > 0.5 * abs(frag_effect or 1))
    identified = bool(
        len(pens) > 0 and frag_effect == frag_effect
        and (pens.max() < ratio_threshold * frag_effect)
    )
    note = (
        "Naturalness penalty is smaller than the fragmentation effect at the "
        "worst dial setting; report the interaction-adjusted contrast."
        if identified else
        "PRE-REGISTERED FAILURE MODE: the naturalness penalty is comparable to "
        "or larger than the fragmentation effect. Report a non-identification, "
        "not a rescued estimate."
    )
    return NaturalnessCheck(per_phi, varies, identified, note)


# ---------------------------------------------------------------------------
# 3. exchange rate
# ---------------------------------------------------------------------------

@dataclass
class ExchangeRate:
    per_language: dict[str, tuple[float, float]]
    grid: pd.DataFrame
    boot: pd.DataFrame | None = None

    def g(self, n_tokens: float, src: str = "tr", ref: str = "en") -> float:
        a_s, b_s = self.per_language[src]
        a_r, b_r = self.per_language[ref]
        if b_r == 0:
            return float("nan")
        return float(math.exp((a_s - a_r + b_s * math.log(n_tokens)) / b_r))


def _fit_logistic(x: np.ndarray, y: np.ndarray) -> tuple[float, float]:
    """Two-parameter logistic fit by Newton steps; no statsmodels needed."""
    X = np.column_stack([np.ones_like(x), x])
    beta = np.zeros(2)
    for _ in range(64):
        eta = X @ beta
        p = 1.0 / (1.0 + np.exp(-np.clip(eta, -30, 30)))
        W = np.clip(p * (1 - p), 1e-8, None)
        grad = X.T @ (y - p)
        H = X.T @ (X * W[:, None])
        try:
            step = np.linalg.solve(H + 1e-8 * np.eye(2), grad)
        except np.linalg.LinAlgError:
            break
        beta = beta + step
        if np.max(np.abs(step)) < 1e-9:
            break
    return float(beta[0]), float(beta[1])


def exchange_rate(df: pd.DataFrame, family: str | None = None,
                  n_boot: int = 0, seed: int = 0) -> ExchangeRate:
    """Fit accuracy vs log realized tokens per language, then invert.

    g(N) reports the English token count at which English accuracy equals
    Turkish accuracy at N tokens.  Reported with uncertainty across the
    measured range only -- never extrapolated past it.
    """
    d = df[(df["arm"] == "A") & (df["naturalness"] == "N0")]
    if family:
        d = d[d["family"] == family]
    if d.empty:
        raise ValueError("no rows for exchange-rate fit")

    per_lang: dict[str, tuple[float, float]] = {}
    for lang, g in d.groupby("language"):
        per_lang[str(lang)] = _fit_logistic(
            g["log_tokens"].to_numpy(float), g["correct"].to_numpy(float)
        )

    lo = float(d["realized_tokens"].quantile(0.05))
    hi = float(d["realized_tokens"].quantile(0.95))
    ns = np.unique(np.round(np.exp(np.linspace(math.log(lo), math.log(hi), 12))))
    er = ExchangeRate(per_language=per_lang, grid=pd.DataFrame())
    rows = []
    for n in ns:
        row = {"n_tokens": int(n)}
        for lang in per_lang:
            if lang == "en":
                continue
            try:
                row[f"g_{lang}"] = round(er.g(float(n), src=lang), 1)
            except Exception:  # noqa: BLE001
                row[f"g_{lang}"] = float("nan")
        rows.append(row)
    er.grid = pd.DataFrame(rows)

    if n_boot:
        rng = np.random.default_rng(seed)
        instances = d["instance"].unique()
        boots = []
        for _ in range(n_boot):
            pick = rng.choice(instances, size=len(instances), replace=True)
            sub = pd.concat([d[d["instance"] == i] for i in pick])
            try:
                sub_er = exchange_rate(sub, family=family, n_boot=0)
                boots.append({"g_tr_at_4096": sub_er.g(4096.0)})
            except Exception:  # noqa: BLE001
                continue
        er.boot = pd.DataFrame(boots)
    return er


# ---------------------------------------------------------------------------
# 4. phase / deficit split
# ---------------------------------------------------------------------------

@dataclass
class PhaseDeficit:
    phase_share: float
    deficit_coefficient: float
    ratio: float
    ci: tuple[float, float] | None = None
    caveat: str = (
        "Operationalization, not identification: Theorem 3.1's terms are "
        "defined for optimal predictors on Markov sources. Reported as such."
    )


def phase_deficit(df: pd.DataFrame, n_boot: int = 200, seed: int = 0
                  ) -> PhaseDeficit:
    """Split the fragmentation penalty into length-invariant and length-growing
    components (RQ5).

    phase   : the phi effect at the shortest realized length
    deficit : the phi x log(tokens) coefficient
    """
    d = df[(df["arm"] == "A") & (df["naturalness"] == "N0")].copy()
    if d.empty:
        raise ValueError("no rows")

    def fit(frame: pd.DataFrame) -> tuple[float, float]:
        x_phi = frame["phi"].to_numpy(float)
        x_len = frame["log_tokens"].to_numpy(float)
        x_len = x_len - x_len.min()
        X = np.column_stack([np.ones_like(x_phi), x_phi, x_len, x_phi * x_len])
        y = frame["correct"].to_numpy(float)
        beta = np.zeros(4)
        for _ in range(64):
            p = 1.0 / (1.0 + np.exp(-np.clip(X @ beta, -30, 30)))
            W = np.clip(p * (1 - p), 1e-8, None)
            try:
                step = np.linalg.solve(
                    X.T @ (X * W[:, None]) + 1e-8 * np.eye(4), X.T @ (y - p)
                )
            except np.linalg.LinAlgError:
                break
            beta += step
            if np.max(np.abs(step)) < 1e-9:
                break
        return float(beta[1]), float(beta[3])

    phase, deficit = fit(d)
    ratio = abs(deficit) / (abs(phase) + abs(deficit)) if (phase or deficit) else float("nan")

    ci = None
    if n_boot:
        rng = np.random.default_rng(seed)
        insts = d["instance"].unique()
        vals = []
        for _ in range(n_boot):
            pick = rng.choice(insts, size=len(insts), replace=True)
            sub = d[d["instance"].isin(set(pick))]
            if sub.empty:
                continue
            p_, d_ = fit(sub)
            denom = abs(p_) + abs(d_)
            if denom > 0:
                vals.append(abs(d_) / denom)
        if vals:
            ci = (float(np.percentile(vals, 2.5)), float(np.percentile(vals, 97.5)))

    return PhaseDeficit(phase_share=phase, deficit_coefficient=deficit,
                        ratio=ratio, ci=ci)


# ---------------------------------------------------------------------------
# 5. Theorem 4.3 bound check
# ---------------------------------------------------------------------------

@dataclass
class Thm43Result:
    per_cell: pd.DataFrame
    effective_window: float
    rank_correlation: float
    violations: int
    note: str = field(default=(
        "The theorem bounds excess *log-loss*, not accuracy. We therefore test "
        "the ordering prediction (cells with a larger predicted bound show a "
        "larger observed compaction gain) and report the bound in bits "
        "alongside the accuracy gain, rather than inventing a loss-to-accuracy "
        "conversion the theorem does not license."
    ))


def thm43_check(df: pd.DataFrame, source_alphabet_size: int = 96,
                effective_window: float | None = None) -> Thm43Result:
    """Compute the Theorem 4.3 bound per Arm B cell and compare to observed gain.

    R_Z and epsilon are both measured on our own materials:
      R_Z  chars per token, straight off the tokenizer
      eps  fraction of items whose required span exceeds the effective window,
           where the window is estimated from the single-fact retrieval control
    """
    if effective_window is None:
        ctrl = df[df["family"] == "retrieval"]
        effective_window = estimate_effective_window(ctrl.to_dict("records")) \
            if not ctrl.empty else float("inf")

    b = df[df["arm"] == "B"]
    if b.empty:
        raise ValueError("no Arm B rows")

    rows = []
    for (lang, length, cplx), g in b.groupby(
        ["language", "target_tokens", "complexity"]
    ):
        verbose = g[g["realization"] == "verbose"]
        compact = g[g["realization"] == "compact"]
        filler = g[g["realization"] == "compact_filler"]
        if verbose.empty or compact.empty:
            continue
        eps = epsilon(verbose["required_span_tokens"], effective_window)
        R_Z = float(compact["compression_rate"].mean())
        bound_bits = theorem_43_bound(R_Z, eps, source_alphabet_size)
        obs_gain = float(compact["correct"].mean() - verbose["correct"].mean())
        filler_gain = (float(filler["correct"].mean() - verbose["correct"].mean())
                       if not filler.empty else float("nan"))
        rows.append({
            "language": lang, "target_tokens": length, "complexity": cplx,
            "epsilon": round(eps, 4), "R_Z": round(R_Z, 4),
            "bound_bits_per_token": round(bound_bits, 5),
            "observed_gain": round(obs_gain, 4),
            "filler_gain": round(filler_gain, 4) if filler_gain == filler_gain else np.nan,
            # gain attributable to burden relief rather than redundancy removal
            "burden_component": round(obs_gain - filler_gain, 4)
            if filler_gain == filler_gain else np.nan,
            "n_verbose": len(verbose), "n_compact": len(compact),
        })

    per_cell = pd.DataFrame(rows)
    rho = float("nan")
    if len(per_cell) > 2:
        a = per_cell["bound_bits_per_token"].rank()
        c = per_cell["observed_gain"].rank()
        if a.std() > 0 and c.std() > 0:
            rho = float(np.corrcoef(a, c)[0, 1])
    violations = int((per_cell["observed_gain"] < 0).sum())
    return Thm43Result(per_cell=per_cell, effective_window=float(effective_window),
                       rank_correlation=rho, violations=violations)


# ---------------------------------------------------------------------------
# summary
# ---------------------------------------------------------------------------

def summarize(df: pd.DataFrame) -> dict:
    out: dict = {"provenance": provenance(df)}
    if df.empty:
        return out
    a = df[df["arm"] == "A"]
    if not a.empty:
        out["accuracy_by_phi"] = (
            a.groupby(["language", "phi_level"])["correct"].mean().round(4).to_dict()
        )
        out["accuracy_by_length"] = (
            a.groupby(["language", "target_tokens"])["correct"].mean().round(4).to_dict()
        )
        out["mean_fragmentation_ratio"] = (
            a.groupby(["language", "phi_level"])["fragmentation_ratio"]
            .mean().round(4).to_dict()
        )
        out["perturbable_fraction"] = (
            a.groupby("naturalness")["perturbable_fraction"].mean().round(4).to_dict()
        )
    if "error_type" in df:
        out["error_types"] = df["error_type"].value_counts().to_dict()
    return out
