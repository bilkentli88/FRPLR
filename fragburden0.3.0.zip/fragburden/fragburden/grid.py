"""The grid, and its cost.

This module is the single source of truth for what gets run.  `budget()`
prints items and GPU-hours for the current definition, so any change to the
design shows its compute cost immediately rather than at week three of a run.

The default grid reproduces the table in proposal v0.3 sec. 6.2.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterator, Sequence

from .spec import ItemSpec

# Planning figures from proposal v0.3 sec. 6.2: seconds per item on a free-tier
# T4 with a 4-bit 4B model, including a 1.5x safety factor over the FLOP
# estimate and assuming modest batching.  Replace with measured values after
# the pilot -- `cli.py budget --measured runs.jsonl` does that.
SECONDS_PER_ITEM = {
    1024: 0.9,
    2048: 1.7,
    4096: 3.5,
    8192: 7.5,
    16384: 19.0,
    32768: 55.0,
}

PRIMARY_MODEL = "qwen3-4b-4bit"
REPLICATION_MODEL = "gemma3-4b-4bit"
SANITY_MODEL = "qwen3-1.7b-fp16"

# Relative cost against the 4-bit 4B reference.  The 1.7B sanity model is
# smaller but runs in fp16 without dequantization overhead, which partly
# offsets the parameter saving on a Turing card.
MODEL_SPEED = {
    PRIMARY_MODEL: 1.0,
    REPLICATION_MODEL: 1.0,
    SANITY_MODEL: 0.55,
    "stub": 0.0,
}

CORE_LENGTHS = (1024, 2048, 4096, 8192)


def seconds_for(target_tokens: int, model: str = PRIMARY_MODEL) -> float:
    keys = sorted(SECONDS_PER_ITEM)
    if target_tokens in SECONDS_PER_ITEM:
        base = SECONDS_PER_ITEM[target_tokens]
    else:
        lo = max([k for k in keys if k <= target_tokens], default=keys[0])
        hi = min([k for k in keys if k >= target_tokens], default=keys[-1])
        if lo == hi:
            base = SECONDS_PER_ITEM[lo]
        else:
            frac = (target_tokens - lo) / (hi - lo)
            base = SECONDS_PER_ITEM[lo] + frac * (
                SECONDS_PER_ITEM[hi] - SECONDS_PER_ITEM[lo]
            )
    return base * MODEL_SPEED.get(model, 1.0)


def calibrate_from_run(path: str) -> dict[int, float]:
    """Replace the estimated throughput table with measured wall times.

    The pilot's job (Phase 5 gate) is to make the planning figures real.  Feed
    the pilot's JSONL here and put the result in SECONDS_PER_ITEM.
    """
    import json
    from collections import defaultdict

    buckets: dict[int, list[float]] = defaultdict(list)
    with open(path, "r", encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            try:
                row = json.loads(line)
            except json.JSONDecodeError:
                continue
            speed = MODEL_SPEED.get(row.get("model", ""), 1.0)
            if speed <= 0:
                continue  # stub rows carry no timing information
            buckets[int(row["target_tokens"])].append(
                float(row["wall_seconds"]) / speed
            )
    return {
        k: round(sum(v) / len(v), 3)
        for k, v in sorted(buckets.items()) if v
    }


# ---------------------------------------------------------------------------
# segmentation conditions: the nested naturalness design (sec. 4.2)
# ---------------------------------------------------------------------------

def segmentation_conditions() -> list[tuple[int, str]]:
    """N0 and N1 at every phi; N2 only at the endpoints.  Ten conditions."""
    out: list[tuple[int, str]] = []
    for phi in (100, 75, 50, 25):
        out.append((phi, "N0"))
        out.append((phi, "N1"))
    out.append((100, "N2"))
    out.append((25, "N2"))
    return out


# ---------------------------------------------------------------------------
# run blocks
# ---------------------------------------------------------------------------

@dataclass
class RunBlock:
    name: str
    specs: list[ItemSpec] = field(default_factory=list)

    @property
    def n_items(self) -> int:
        return len(self.specs)

    @property
    def gpu_hours(self) -> float:
        return sum(seconds_for(s.target_tokens, s.model) for s in self.specs) / 3600.0


def _block(name: str, specs: Iterator[ItemSpec]) -> RunBlock:
    return RunBlock(name=name, specs=list(specs))


def arm_a_core(items_per_cell: int = 24,
               languages: Sequence[str] = ("en", "tr", "ru"),
               lengths: Sequence[int] = CORE_LENGTHS,
               complexities: Sequence[int] = (2, 4),
               model: str = PRIMARY_MODEL,
               family: str = "state_tracking",
               matching: str = "content") -> RunBlock:
    def gen():
        for phi, nat in segmentation_conditions():
            for lang in languages:
                for length in lengths:
                    for cplx in complexities:
                        for seed in range(items_per_cell):
                            yield ItemSpec(
                                arm="A", family=family, language=lang,
                                model=model, phi_level=phi, naturalness=nat,
                                target_tokens=length, complexity=cplx,
                                matching=matching, realization="na", seed=seed,
                            )
    return _block("arm_a_core", gen())


def arm_a_16k(items_per_cell: int = 24,
              languages: Sequence[str] = ("en", "tr", "ru"),
              model: str = PRIMARY_MODEL) -> RunBlock:
    def gen():
        for phi in (100, 75, 50, 25):
            for lang in languages:
                for seed in range(items_per_cell):
                    yield ItemSpec(
                        arm="A", family="state_tracking", language=lang,
                        model=model, phi_level=phi, naturalness="N0",
                        target_tokens=16384, complexity=4, matching="content",
                        realization="na", seed=seed,
                    )
    return _block("arm_a_16k", gen())


def arm_a_replication(items_per_cell: int = 24,
                      languages: Sequence[str] = ("en", "tr", "ru"),
                      model: str = REPLICATION_MODEL) -> RunBlock:
    def gen():
        for phi in (100, 75, 50, 25):
            for lang in languages:
                for length in (1024, 8192):
                    for cplx in (2, 4):
                        for seed in range(items_per_cell):
                            yield ItemSpec(
                                arm="A", family="state_tracking", language=lang,
                                model=model, phi_level=phi, naturalness="N0",
                                target_tokens=length, complexity=cplx,
                                matching="content", realization="na", seed=seed,
                            )
    return _block("arm_a_replication", gen())


def arm_b(items_per_cell: int = 32,
          languages: Sequence[str] = ("en", "tr"),
          lengths: Sequence[int] = (2048, 4096, 8192),
          model: str = PRIMARY_MODEL) -> RunBlock:
    def gen():
        for realization in ("verbose", "compact", "compact_filler"):
            for lang in languages:
                for length in lengths:
                    for cplx in (2, 4):
                        for seed in range(items_per_cell):
                            yield ItemSpec(
                                arm="B", family="negation", language=lang,
                                model=model, phi_level=100, naturalness="N0",
                                target_tokens=length, complexity=cplx,
                                matching="content", realization=realization,
                                seed=seed,
                            )
    return _block("arm_b", gen())


def arm_b_replication(items_per_cell: int = 16) -> RunBlock:
    b = arm_b(items_per_cell=items_per_cell, model=REPLICATION_MODEL)
    b.name = "arm_b_replication"
    return b


def pilot(items_per_cell: int = 10) -> RunBlock:
    """Reduced sub-grid.  Calibrates length and hop ranges, estimates variance,
    and replaces the estimated throughput table with a measured one."""
    def gen():
        for phi in (100, 25):
            for nat in ("N0", "N1"):
                for lang in ("en", "tr", "ru"):
                    for length in CORE_LENGTHS:
                        for cplx in (2, 4):
                            for seed in range(items_per_cell):
                                yield ItemSpec(
                                    arm="A", family="state_tracking",
                                    language=lang, model=PRIMARY_MODEL,
                                    phi_level=phi, naturalness=nat,
                                    target_tokens=length, complexity=cplx,
                                    matching="content", realization="na",
                                    seed=1000 + seed,
                                )
    return _block("pilot", gen())


def retrieval_control(items_per_cell: int = 16) -> RunBlock:
    """The single-fact control.  Supplies the effective-window estimate that
    epsilon is computed against, so it is not optional."""
    def gen():
        for lang in ("en", "tr", "ru"):
            for length in CORE_LENGTHS + (16384,):
                for seed in range(items_per_cell):
                    yield ItemSpec(
                        arm="A", family="retrieval", language=lang,
                        model=PRIMARY_MODEL, phi_level=100, naturalness="N0",
                        target_tokens=length, complexity=1, matching="content",
                        realization="na", seed=2000 + seed,
                    )
    return _block("retrieval_control", gen())


def sanity_full_precision(items_per_cell: int = 50) -> RunBlock:
    def gen():
        for phi in (100, 25):
            for lang in ("en", "tr"):
                for length in (1024, 4096):
                    for cplx in (2, 4):
                        for seed in range(items_per_cell):
                            yield ItemSpec(
                                arm="A", family="state_tracking", language=lang,
                                model=SANITY_MODEL, phi_level=phi,
                                naturalness="N0", target_tokens=length,
                                complexity=cplx, matching="content",
                                realization="na", seed=3000 + seed,
                            )
    return _block("sanity_full_precision", gen())


def position_spotcheck(items_per_cell: int = 48) -> RunBlock:
    """Guards the decision to fix evidence position rather than cross it."""
    def gen():
        for phi in (100, 25):
            for lang in ("en", "tr"):
                for length in (4096, 8192):
                    for seed in range(items_per_cell):
                        yield ItemSpec(
                            arm="A", family="state_tracking", language=lang,
                            model=PRIMARY_MODEL, phi_level=phi,
                            naturalness="N0", target_tokens=length,
                            complexity=4, matching="content",
                            realization="na", seed=4000 + seed,
                        )
    return _block("position_spotcheck", gen())


def paraphrase_spotcheck(items_per_cell: int = 40) -> RunBlock:
    """Sec. 4.5: guards against option-phrasing artifacts masquerading as the
    Arm B wording surplus.  Same instances, paraphrased option sets."""
    def gen():
        for realization in ("verbose", "compact"):
            for lang in ("en", "tr"):
                for length in (2048, 8192):
                    for seed in range(items_per_cell):
                        yield ItemSpec(
                            arm="B", family="negation", language=lang,
                            model=PRIMARY_MODEL, phi_level=100,
                            naturalness="N0", target_tokens=length,
                            complexity=4, matching="content",
                            realization=realization, seed=7000 + seed,
                        )
    return _block("paraphrase_spotcheck", gen())


def token_matched_slice(items_per_cell: int = 16) -> RunBlock:
    """The second matching regime required by sec. 7.2.

    Not in the v0.3 budget table; costs ~1.1 GPU-hours at the default size.
    Run it -- without overlapping token-count distributions the collinearity
    between language and log(tokens) is not breakable.
    """
    def gen():
        for phi in (100, 50, 25):
            for lang in ("en", "tr", "ru"):
                for length in (2048, 8192):
                    for seed in range(items_per_cell):
                        yield ItemSpec(
                            arm="A", family="state_tracking", language=lang,
                            model=PRIMARY_MODEL, phi_level=phi,
                            naturalness="N0", target_tokens=length,
                            complexity=4, matching="token",
                            realization="na", seed=5000 + seed,
                        )
    return _block("token_matched_slice", gen())


def stretch_32k(items_per_cell: int = 24) -> RunBlock:
    def gen():
        for lang in ("en", "tr", "ru"):
            for seed in range(items_per_cell):
                yield ItemSpec(
                    arm="A", family="state_tracking", language=lang,
                    model=PRIMARY_MODEL, phi_level=100, naturalness="N0",
                    target_tokens=32768, complexity=4, matching="content",
                    realization="na", seed=6000 + seed,
                )
    return _block("stretch_32k", gen())


BLOCKS = {
    "pilot": pilot,
    "arm_a_core": arm_a_core,
    "arm_a_16k": arm_a_16k,
    "arm_a_replication": arm_a_replication,
    "arm_b": arm_b,
    "arm_b_replication": arm_b_replication,
    "retrieval_control": retrieval_control,
    "sanity_full_precision": sanity_full_precision,
    "position_spotcheck": position_spotcheck,
    "paraphrase_spotcheck": paraphrase_spotcheck,
    "token_matched_slice": token_matched_slice,
    "stretch_32k": stretch_32k,
}

# Everything the paper needs.  `pilot` runs first and is excluded here because
# its results calibrate this grid rather than feeding the analysis.
MAIN_RUN = (
    "arm_a_core", "arm_a_16k", "arm_a_replication",
    "arm_b", "arm_b_replication", "retrieval_control",
    "sanity_full_precision", "position_spotcheck", "paraphrase_spotcheck",
)

FULL_PROGRAMME = ("pilot",) + MAIN_RUN + ("stretch_32k",)


def build(names: Sequence[str]) -> list[RunBlock]:
    out = []
    for n in names:
        if n not in BLOCKS:
            raise KeyError(f"unknown block {n!r}; have {sorted(BLOCKS)}")
        out.append(BLOCKS[n]())
    return out


def budget(names: Sequence[str] = MAIN_RUN,
           contingency: float = 2.0) -> dict:
    blocks = build(names)
    rows = [
        {"block": b.name, "items": b.n_items, "gpu_hours": round(b.gpu_hours, 2)}
        for b in blocks
    ]
    total_items = sum(r["items"] for r in rows)
    total_hours = sum(r["gpu_hours"] for r in rows)
    seen: dict[str, str] = {}
    dupes = 0
    for b in blocks:
        for s in b.specs:
            if s.id in seen:
                dupes += 1
            seen[s.id] = b.name
    return {
        "rows": rows,
        "total_items": total_items,
        "unique_items": len(seen),
        "duplicate_specs": dupes,
        "total_gpu_hours": round(total_hours, 2),
        "with_contingency": round(total_hours * contingency, 2),
        "calendar_days_at_3h": round(total_hours * contingency / 3.0, 1),
    }


def format_budget(b: dict) -> str:
    w = max(len(r["block"]) for r in b["rows"]) + 2
    lines = [f"{'block':<{w}}{'items':>9}{'gpu-h':>9}", "-" * (w + 18)]
    for r in b["rows"]:
        lines.append(f"{r['block']:<{w}}{r['items']:>9,}{r['gpu_hours']:>9.2f}")
    lines.append("-" * (w + 18))
    lines.append(f"{'total':<{w}}{b['total_items']:>9,}{b['total_gpu_hours']:>9.2f}")
    lines.append("")
    lines.append(f"unique item ids     : {b['unique_items']:,}")
    lines.append(f"duplicate specs     : {b['duplicate_specs']:,}")
    lines.append(f"with 2x contingency : {b['with_contingency']:.1f} gpu-hours")
    lines.append(f"at 3 usable h/day   : {b['calendar_days_at_3h']:.1f} calendar days")
    return "\n".join(lines)
