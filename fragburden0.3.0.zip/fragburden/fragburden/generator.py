"""Instance generation: language-neutral problem objects, realized per language.

Four families:

  state_tracking   objects moving between people; query final possessor
  negation         borrow -> return -> borrow; query final possessor.  The
                   adversarial family: it is where compaction is most likely to
                   silently drop a proposition, and where Turkish equivalence is
                   thinnest.
  reachability     directed edges between cities; query connectivity
  retrieval        one fact stated once; the single-fact control that also
                   supplies the effective-window estimate used for epsilon

Length control.  `realize` pads with ledger-irrelevant filler until the prompt
hits a target token count under a supplied counter.  Two matching regimes
(proposal v0.3 sec. 7.2):

  content  filler is searched once under the *undialed* tokenizer, so byte
           content is held fixed across dial settings and token count rises
           with phi.  This is the direct reading of Theorem 3.1.
  token    filler is searched separately at each dial setting, so token count
           is held fixed and content shrinks as phi rises.  Any residual
           difference here is purely representational.
"""

from __future__ import annotations

import random
from dataclasses import dataclass
from typing import Callable, Sequence

from .ledger import ErrorType, Ledger, Proposition, Realization
from .lexicon import (
    INSTRUCTIONS,
    QUERIES,
    TEMPLATE_VARIANTS,
    TEMPLATES,
    max_complexity,
    YES_NO,
    lexicon,
)

OPTION_LETTERS = ("A", "B", "C", "D")

TokenCounter = Callable[[str], int]


@dataclass
class GenConfig:
    family: str
    language: str
    complexity: int          # hops / events on the tracked object
    realization: str         # "verbose" | "compact" | "compact_filler" | "na"
    seed: int
    target_tokens: int = 1024
    filler_tolerance: float = 0.04


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

def _render(language: str, kind: str, verbosity: str, variant: int = 0, **kw) -> str:
    """Render one event.

    `variant` rotates through TEMPLATE_VARIANTS where they exist, so a repeated
    borrow/return cycle does not emit byte-identical sentences.  Identical
    repeats would let a model match on the repetition instead of tracking
    state, and would flatten the fragmentation contrast by re-using the same
    token sequence.
    """
    variants = TEMPLATE_VARIANTS.get(language, {}).get(kind, {}).get(verbosity)
    template = variants[variant % len(variants)] if variants \
        else TEMPLATES[language][kind][verbosity]
    return template.format(**kw)


def _verbosity(realization: str) -> str:
    return "verbose" if realization in ("na", "verbose") else "compact"


# ---------------------------------------------------------------------------
# families
# ---------------------------------------------------------------------------

def _gen_state_tracking(cfg: GenConfig, rng: random.Random) -> Ledger:
    lex = lexicon(cfg.language)
    verb = _verbosity(cfg.realization)
    people = list(lex["people"])
    objects = list(lex["objects"])
    rng.shuffle(people)
    rng.shuffle(objects)

    obj = objects[0]
    chain = people[: cfg.complexity + 1]
    lg = Ledger()

    holder = chain[0]
    lg.propositions.append(Proposition("possession", (obj, holder)))
    lg.realizations.append(
        Realization(
            0,
            _render(cfg.language, "take", verb,
                    p_nom=lex["people"][holder]["nom"],
                    o_acc=lex["objects"][obj]["acc"]),
        )
    )

    prior = holder
    for nxt in chain[1:]:
        idx = len(lg.propositions)
        lg.propositions.append(Proposition("possession", (obj, nxt)))
        lg.realizations.append(
            Realization(
                idx,
                _render(cfg.language, "give", verb,
                        p_nom=lex["people"][prior]["nom"],
                        o_acc=lex["objects"][obj]["acc"],
                        q_dat=lex["people"][nxt]["dat"]),
            )
        )
        prior, holder = nxt, nxt

    penultimate = chain[-2] if len(chain) > 1 else chain[0]
    decoys = [p for p in people if p not in (holder, penultimate)]

    lg.query = QUERIES[cfg.language]["possession"].format(
        o_nom=lex["objects"][obj]["nom"]
    )
    lg.answer_key, lg.answer = "A", lex["people"][holder]["nom"]
    _assign_options(
        lg, rng,
        correct=lex["people"][holder]["nom"],
        distractors=[
            (lex["people"][penultimate]["nom"], "missed_update"),
            (lex["people"][decoys[0]]["nom"], "misbound_entity"),
            (lex["people"][chain[0]]["nom"], "dropped_proposition"),
        ],
    )
    lg.meta = {"object": obj, "chain": chain, "family": "state_tracking"}
    return lg


def _gen_negation(cfg: GenConfig, rng: random.Random) -> Ledger:
    """borrow -> return -> borrow.  The state-cancellation stress case."""
    lex = lexicon(cfg.language)
    verb = _verbosity(cfg.realization)
    people = list(lex["people"])
    objects = list(lex["objects"])
    rng.shuffle(people)
    rng.shuffle(objects)

    obj = objects[0]
    owner, borrower = people[0], people[1]

    cap = max_complexity(cfg.language, verb)
    if cfg.complexity > cap:
        raise ValueError(
            f"negation family at complexity={cfg.complexity} would repeat a "
            f"sentence verbatim in {cfg.language}/{verb} (max {cap}). Add "
            f"template variants in lexicon.TEMPLATE_VARIANTS before raising "
            f"the hop count."
        )

    lg = Ledger()

    def add(kind: str, holder: str, variant: int = 0, **kw) -> None:
        idx = len(lg.propositions)
        lg.propositions.append(Proposition("possession", (obj, holder)))
        lg.realizations.append(
            Realization(idx, _render(cfg.language, kind, verb, variant=variant, **kw))
        )

    add("take", owner,
        p_nom=lex["people"][owner]["nom"], o_acc=lex["objects"][obj]["acc"])

    cycles = max(1, cfg.complexity // 2)
    holder = owner
    for c in range(cycles):
        add("borrow", borrower, variant=c,
            p_nom=lex["people"][borrower]["nom"],
            o_acc=lex["objects"][obj]["acc"],
            q_abl=lex["people"][owner]["abl"])
        holder = borrower
        add("return", owner, variant=c,
            p_nom=lex["people"][borrower]["nom"],
            o_acc=lex["objects"][obj]["acc"],
            q_dat=lex["people"][owner]["dat"])
        holder = owner

    # final uncancelled borrow -- the fact a dropped proposition would miss
    add("borrow", borrower, variant=cycles,
        p_nom=lex["people"][borrower]["nom"],
        o_acc=lex["objects"][obj]["acc"],
        q_abl=lex["people"][owner]["abl"])
    holder = borrower

    decoys = [p for p in people if p not in (owner, borrower)]
    lg.query = QUERIES[cfg.language]["possession"].format(
        o_nom=lex["objects"][obj]["nom"]
    )
    lg.answer = lex["people"][holder]["nom"]
    _assign_options(
        lg, rng,
        correct=lg.answer,
        distractors=[
            (lex["people"][owner]["nom"], "pre_cancellation"),
            (lex["people"][decoys[0]]["nom"], "misbound_entity"),
            (lex["people"][decoys[1]]["nom"], "dropped_proposition"),
        ],
    )
    lg.meta = {"object": obj, "owner": owner, "borrower": borrower,
               "cycles": cycles, "family": "negation"}
    return lg


def _gen_reachability(cfg: GenConfig, rng: random.Random) -> Ledger:
    lex = lexicon(cfg.language)
    verb = _verbosity(cfg.realization)
    cities = list(lex["cities"])
    rng.shuffle(cities)
    path = cities[: cfg.complexity + 1]
    lg = Ledger()

    for a, b in zip(path, path[1:]):
        idx = len(lg.propositions)
        lg.propositions.append(Proposition("edge", (a, b)))
        lg.realizations.append(
            Realization(idx, _render(cfg.language, "edge", verb, a=a, b=b))
        )

    # decoy edges that do not complete the path
    spare = cities[cfg.complexity + 1:]
    for a, b in zip(spare, spare[1:]):
        idx = len(lg.propositions)
        lg.propositions.append(Proposition("edge", (a, b), required=False))
        lg.realizations.append(
            Realization(idx, _render(cfg.language, "edge", verb, a=a, b=b))
        )

    yes, no = YES_NO[cfg.language]["yes"], YES_NO[cfg.language]["no"]
    lg.query = QUERIES[cfg.language]["reachability"].format(a=path[0], b=path[-1])
    lg.answer = yes
    lg.options = {"A": yes, "B": no}
    lg.option_errors = {"A": "correct", "B": "dropped_proposition"}
    lg.answer_key = "A"
    _shuffle_options(lg, rng)
    lg.meta = {"path": path, "family": "reachability"}
    return lg


def _gen_retrieval(cfg: GenConfig, rng: random.Random) -> Ledger:
    lex = lexicon(cfg.language)
    verb = _verbosity(cfg.realization)
    objects = list(lex["objects"])
    rng.shuffle(objects)
    obj = objects[0]
    code = f"{rng.randint(100, 999)}"
    lg = Ledger()
    lg.propositions.append(Proposition("fact", (obj, code)))
    lg.realizations.append(
        Realization(0, _render(cfg.language, "fact", verb,
                               o_nom=lex["objects"][obj]["nom"], v=code))
    )
    lg.query = QUERIES[cfg.language]["retrieval"].format(
        o_nom=lex["objects"][obj]["nom"]
    )
    lg.answer = code
    others = []
    while len(others) < 3:
        c = str(rng.randint(100, 999))
        if c != code and c not in others:
            others.append(c)
    _assign_options(
        lg, rng, correct=code,
        distractors=[(others[0], "misbound_entity"),
                     (others[1], "dropped_proposition"),
                     (others[2], "missed_update")],
    )
    lg.meta = {"object": obj, "code": code, "family": "retrieval"}
    return lg


FAMILIES: dict[str, Callable[[GenConfig, random.Random], Ledger]] = {
    "state_tracking": _gen_state_tracking,
    "negation": _gen_negation,
    "reachability": _gen_reachability,
    "retrieval": _gen_retrieval,
}


# ---------------------------------------------------------------------------
# options
# ---------------------------------------------------------------------------

def _assign_options(lg: Ledger, rng: random.Random, correct: str,
                    distractors: Sequence[tuple[str, ErrorType]]) -> None:
    """Attach four options, deduplicated, each typed by its ledger failure."""
    seen = {correct}
    pool: list[tuple[str, ErrorType]] = []
    for text, etype in distractors:
        if text in seen:
            continue
        seen.add(text)
        pool.append((text, etype))
    pool = pool[:3]

    entries = [(correct, "correct")] + pool
    lg.options = {}
    lg.option_errors = {}
    for letter, (text, etype) in zip(OPTION_LETTERS, entries):
        lg.options[letter] = text
        lg.option_errors[letter] = etype  # type: ignore[assignment]
        if etype == "correct":
            lg.answer_key = letter
            lg.answer = text
    _shuffle_options(lg, rng)


def _shuffle_options(lg: Ledger, rng: random.Random) -> None:
    """Shuffle option order deterministically.

    NOTE (proposal v0.3 sec. 4.5): option *strings* are held fixed across the
    verbose/compact contrast within a language.  Because the shuffle is seeded
    from the instance seed and not from the realization, the same instance
    presents identical option text and identical ordering in both Arm B cells.
    """
    items = [(lg.options[k], lg.option_errors[k]) for k in sorted(lg.options)]
    rng.shuffle(items)
    letters = OPTION_LETTERS[: len(items)]
    lg.options = {}
    lg.option_errors = {}
    for letter, (text, etype) in zip(letters, items):
        lg.options[letter] = text
        lg.option_errors[letter] = etype
        if etype == "correct":
            lg.answer_key = letter
            lg.answer = text


# ---------------------------------------------------------------------------
# filler and length control
# ---------------------------------------------------------------------------

def _filler_text(language: str, verbosity: str, i: int, lex: dict) -> str:
    cities = lex["cities"]
    return _render(language, "filler", verbosity, city=cities[i % len(cities)])


def _interleave_filler(lg: Ledger, language: str, verbosity: str,
                       n_filler: int, rng: random.Random) -> Ledger:
    """Insert n_filler ledger-irrelevant sentences between required events."""
    lex = lexicon(language)
    core = list(lg.realizations)
    fillers = [
        Realization(None, _filler_text(language, verbosity, i, lex), is_filler=True)
        for i in range(n_filler)
    ]
    if not core:
        merged = fillers
    else:
        # distribute filler into the gaps, keeping the first required fact early
        slots = len(core) + 1
        buckets: list[list[Realization]] = [[] for _ in range(slots)]
        for k, f in enumerate(fillers):
            buckets[1 + (k % max(1, slots - 1))].append(f)
        merged = []
        for k, c in enumerate(core):
            merged.extend(buckets[k])
            merged.append(c)
        merged.extend(buckets[-1])
    out = Ledger(
        propositions=lg.propositions,
        answer=lg.answer,
        answer_key=lg.answer_key,
        query=lg.query,
        options=dict(lg.options),
        option_errors=dict(lg.option_errors),
        realizations=merged,
        meta=dict(lg.meta),
    )
    out.meta["n_filler"] = n_filler
    return out


def generate(cfg: GenConfig) -> Ledger:
    """Generate the unpadded instance."""
    if cfg.family not in FAMILIES:
        raise KeyError(f"unknown family {cfg.family!r}")
    rng = random.Random((cfg.seed, cfg.family, cfg.language, cfg.complexity).__hash__())
    return FAMILIES[cfg.family](cfg, rng)


def realize(cfg: GenConfig, counter: TokenCounter,
            max_iter: int = 24) -> tuple[str, Ledger, int]:
    """Generate and pad to `cfg.target_tokens` under `counter`.

    Returns (prompt, padded_ledger, n_filler).  The search is a doubling phase
    followed by a bisection, which converges in ~20 counter calls; the counter
    is pure CPU so this is negligible next to a forward pass.
    """
    base = generate(cfg)
    verbosity = _verbosity(cfg.realization)
    rng = random.Random(cfg.seed ^ 0x5EED)
    instruction = INSTRUCTIONS[cfg.language]
    target = cfg.target_tokens
    tol = max(8, int(target * cfg.filler_tolerance))

    def build(n: int) -> tuple[str, Ledger]:
        lg = _interleave_filler(base, cfg.language, verbosity, n, rng)
        return lg.prompt(instruction), lg

    prompt, lg = build(0)
    if counter(prompt) >= target - tol:
        return prompt, lg, 0

    lo, hi = 0, 8
    while True:
        prompt, lg = build(hi)
        if counter(prompt) >= target or hi > 1 << 16:
            break
        lo, hi = hi, hi * 2

    for _ in range(max_iter):
        if hi - lo <= 1:
            break
        mid = (lo + hi) // 2
        prompt, lg = build(mid)
        n = counter(prompt)
        if n < target - tol:
            lo = mid
        elif n > target + tol:
            hi = mid
        else:
            return prompt, lg, mid
    prompt, lg = build(hi)
    return prompt, lg, hi


def pad_to_token_count(cfg: GenConfig, lg: Ledger, counter: TokenCounter,
                       target: int) -> tuple[str, Ledger, int]:
    """Arm B's length-matched filler cell.

    Takes an already-compact ledger and pads it with neutral filler back to the
    verbose realization's token count, separating 'fewer total tokens' from
    'propositions per token'.
    """
    rng = random.Random(cfg.seed ^ 0xF111)
    instruction = INSTRUCTIONS[cfg.language]
    lo, hi = 0, 8
    while True:
        cand = _interleave_filler(lg, cfg.language, "compact", hi, rng)
        if counter(cand.prompt(instruction)) >= target or hi > 1 << 16:
            break
        lo, hi = hi, hi * 2
    best, best_lg = hi, None
    while hi - lo > 1:
        mid = (lo + hi) // 2
        cand = _interleave_filler(lg, cfg.language, "compact", mid, rng)
        if counter(cand.prompt(instruction)) < target:
            lo = mid
        else:
            hi, best, best_lg = mid, mid, cand
    if best_lg is None:
        best_lg = _interleave_filler(lg, cfg.language, "compact", best, rng)
    return best_lg.prompt(instruction), best_lg, best
