"""fragburden: within-model causal test of token burden in multilingual
long-context reasoning.

Companion code for proposal v0.3, "Fragmentation, Not Language".
"""

__version__ = "0.3.0"

from . import analysis, burden, dial, generator, grid, ledger, naturalness, runner, spec  # noqa: F401

__all__ = [
    "analysis", "burden", "dial", "generator", "grid", "ledger",
    "naturalness", "runner", "spec",
]
