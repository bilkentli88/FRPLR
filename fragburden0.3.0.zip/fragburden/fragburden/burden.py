"""Token burden measurement.

The token variable does not exist until real tokenizers are wired in: word and
character counts systematically understate Turkish, because fertility is hidden
by agglutination.  Everything downstream is expressed in fragmentation ratio,
not language identity.

Also implements the two measured quantities the Theorem 4.3 bound needs:

  R_Z  compression rate, source symbols per token
  eps  probability that the effective window fails to span the required source
       history, estimated across items from per-item required spans
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass
from typing import Iterable, Sequence

from .ledger import Ledger

_WORD_RE = re.compile(r"\w+", re.UNICODE)


def n_words(text: str) -> int:
    return len(_WORD_RE.findall(text))


# ---------------------------------------------------------------------------
# fertility
# ---------------------------------------------------------------------------

@dataclass
class FertilityRow:
    language: str
    tokenizer: str
    n_texts: int
    n_words: int
    n_tokens: int
    n_chars: int

    @property
    def tokens_per_word(self) -> float:
        return self.n_tokens / self.n_words if self.n_words else float("nan")

    @property
    def chars_per_token(self) -> float:
        return self.n_chars / self.n_tokens if self.n_tokens else float("nan")

    def to_row(self) -> dict:
        return {
            "language": self.language,
            "tokenizer": self.tokenizer,
            "n_texts": self.n_texts,
            "n_words": self.n_words,
            "n_tokens": self.n_tokens,
            "n_chars": self.n_chars,
            "tokens_per_word": round(self.tokens_per_word, 5),
            "chars_per_token": round(self.chars_per_token, 5),
        }


def measure_fertility(dialed, texts: Sequence[str], language: str,
                      tokenizer_name: str = "") -> FertilityRow:
    tok = words = chars = 0
    for t in texts:
        tok += len(dialed.encode_pieces(t))
        words += n_words(t)
        chars += len(t)
    return FertilityRow(
        language=language,
        tokenizer=tokenizer_name or getattr(dialed, "dial_type", "?"),
        n_texts=len(texts),
        n_words=words,
        n_tokens=tok,
        n_chars=chars,
    )


def fertility_table(dial, corpora: dict[str, Sequence[str]],
                    tokenizer_name: str = "") -> list[dict]:
    """Phase 1 language-selection figure.

    Run over 8-10 candidate languages on a fixed parallel corpus, under the
    actual model tokenizers.  The second language is selected from this table,
    not from typological reputation.
    """
    base = dial.at(100)
    rows = [
        measure_fertility(base, texts, lang, tokenizer_name).to_row()
        for lang, texts in sorted(corpora.items())
    ]
    if rows:
        anchor = next((r for r in rows if r["language"] == "en"), rows[0])
        for r in rows:
            r["fertility_vs_en"] = round(
                r["tokens_per_word"] / anchor["tokens_per_word"], 5
            )
    return rows


# ---------------------------------------------------------------------------
# fragmentation ratio
# ---------------------------------------------------------------------------

def fragmentation_ratio(realized_tokens: int, baseline_tokens: int) -> float:
    """phi, the independent variable.  Measured per item, never assumed."""
    if baseline_tokens <= 0:
        return float("nan")
    return realized_tokens / baseline_tokens


def compression_rate(text: str, n_tokens: int, unit: str = "chars") -> float:
    """R_Z in Theorem 4.3: source symbols per token.

    `unit` selects the source alphabet.  We report chars/token as the primary
    (it is alphabet-neutral across our three languages) and words/token as a
    secondary; the choice is stated in the paper rather than left implicit.
    """
    if n_tokens <= 0:
        return float("nan")
    src = len(text) if unit == "chars" else n_words(text)
    return src / n_tokens


# ---------------------------------------------------------------------------
# epsilon: span failure
# ---------------------------------------------------------------------------

def required_span_tokens(ledger: Ledger, dialed, instruction: str) -> int:
    """Tokens from the earliest required proposition to the end of the prompt.

    Measured at pre-token-chunk granularity, which is exact to within one
    chunk and costs one pass over the text.
    """
    body_prefix_chars, _ = ledger.required_span_chars()
    prompt = ledger.prompt(instruction)
    head = prompt.index(ledger.body()) if ledger.body() in prompt else 0
    cut = head + body_prefix_chars

    n_before = 0
    for chunk, (start, _end) in dialed.pre_tokenize(prompt):
        if start >= cut:
            break
        n_before += len(dialed.encode_chunk_pieces(chunk))
    total = len(dialed.encode_pieces(prompt))
    return max(0, total - n_before)


def epsilon(required_spans: Iterable[int], effective_window: int) -> float:
    """Fraction of items whose required history exceeds the effective window.

    `effective_window` is *not* the nominal context length.  It is estimated
    from the single-fact retrieval control -- the realized length at which
    retrieval accuracy crosses a criterion -- because multilingual long-context
    work reports models effectively using under 30% of claimed context.
    """
    spans = list(required_spans)
    if not spans:
        return float("nan")
    return sum(1 for s in spans if s > effective_window) / len(spans)


def estimate_effective_window(retrieval_rows: Sequence[dict],
                              criterion: float = 0.5) -> float:
    """Fit retrieval accuracy against log realized length; invert at criterion.

    Returns the token count at which the single-fact control falls to
    `criterion`.  Returns +inf if the control never falls that far, which is a
    legitimate outcome and must not be silently coerced.
    """
    pts: dict[int, list[float]] = {}
    for r in retrieval_rows:
        pts.setdefault(int(r["realized_tokens"]), []).append(float(r["correct"]))
    if len(pts) < 2:
        return float("inf")
    xs = sorted(pts)
    acc = [sum(pts[x]) / len(pts[x]) for x in xs]
    if all(a > criterion for a in acc):
        return float("inf")
    for (x0, a0), (x1, a1) in zip(zip(xs, acc), zip(xs[1:], acc[1:])):
        if (a0 - criterion) * (a1 - criterion) <= 0 and a0 != a1:
            t = (a0 - criterion) / (a0 - a1)
            return math.exp(math.log(x0) + t * (math.log(x1) - math.log(x0)))
    return float(xs[-1])


def theorem_43_bound(R_Z: float, eps: float, source_alphabet_size: int) -> float:
    """The excess-loss term of Theorem 4.3: eps * R_Z * log2|Y|.

    Returned in bits per token.  Converting a loss bound into an accuracy bound
    requires the link function fitted in analysis.thm43_bound_check; this
    function deliberately returns the loss-side quantity only.
    """
    if source_alphabet_size < 2:
        raise ValueError("source alphabet must have at least 2 symbols")
    return eps * R_Z * math.log2(source_alphabet_size)
