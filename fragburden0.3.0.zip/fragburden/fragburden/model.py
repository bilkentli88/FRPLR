"""Model loading and scoring.

The critical property: we feed **token IDs we constructed ourselves**, never a
string.  Handing the prompt to the tokenizer would discard the fragmentation
dial and the naturalness perturbation, which are the entire experiment.

Chat templates are handled by encoding the template's fixed pre/post segments
once and concatenating IDs around our body, so the body's segmentation is
never re-derived.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Protocol, Sequence

_LETTER_RE = re.compile(r"\b([A-D])\b")


@dataclass
class Prediction:
    text: str
    letter: str | None


class ScoringModel(Protocol):
    name: str
    max_context: int

    def score(self, batch_ids: Sequence[Sequence[int]]) -> list[Prediction]:
        ...


def parse_letter(text: str) -> str | None:
    m = _LETTER_RE.search(text.upper())
    if m:
        return m.group(1)
    stripped = text.strip().upper()
    return stripped[0] if stripped[:1] in ("A", "B", "C", "D") else None


# ---------------------------------------------------------------------------
# real model
# ---------------------------------------------------------------------------

class HFModel:
    """4-bit (or fp16) HuggingFace causal LM scored greedily from raw IDs."""

    def __init__(self, hf_name: str, quant: str = "4bit",
                 device: str = "cuda", max_new_tokens: int = 4,
                 max_context: int = 32768, chat_template: bool = False,
                 dtype: str = "float16"):
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer

        self.name = hf_name
        self.max_context = max_context
        self.max_new_tokens = max_new_tokens
        self._torch = torch

        self.tokenizer = AutoTokenizer.from_pretrained(hf_name, use_fast=True)
        if self.tokenizer.pad_token_id is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token
        self.tokenizer.padding_side = "left"

        kwargs: dict = {"device_map": device, "dtype": getattr(torch, dtype)}
        if quant == "4bit":
            from transformers import BitsAndBytesConfig

            kwargs["quantization_config"] = BitsAndBytesConfig(
                load_in_4bit=True,
                bnb_4bit_quant_type="nf4",
                bnb_4bit_compute_dtype=torch.float16,
                bnb_4bit_use_double_quant=True,
            )
        self.model = AutoModelForCausalLM.from_pretrained(hf_name, **kwargs)
        self.model.eval()

        self.prefix_ids: list[int] = []
        self.suffix_ids: list[int] = []
        if chat_template and getattr(self.tokenizer, "chat_template", None):
            self._build_template_ids()

    def _build_template_ids(self) -> None:
        """Split the chat template into ID prefix/suffix around a sentinel."""
        sentinel = "BODY"
        rendered = self.tokenizer.apply_chat_template(
            [{"role": "user", "content": sentinel}],
            tokenize=False, add_generation_prompt=True,
        )
        head, _, tail = rendered.partition(sentinel)
        self.prefix_ids = self.tokenizer(head, add_special_tokens=False)["input_ids"]
        self.suffix_ids = self.tokenizer(tail, add_special_tokens=False)["input_ids"]

    def wrap(self, body_ids: Sequence[int]) -> list[int]:
        return [*self.prefix_ids, *body_ids, *self.suffix_ids]

    def score(self, batch_ids: Sequence[Sequence[int]]) -> list[Prediction]:
        torch = self._torch
        wrapped = [self.wrap(ids) for ids in batch_ids]
        maxlen = max(len(x) for x in wrapped)
        pad = self.tokenizer.pad_token_id

        input_ids = torch.full((len(wrapped), maxlen), pad, dtype=torch.long)
        attn = torch.zeros((len(wrapped), maxlen), dtype=torch.long)
        for i, ids in enumerate(wrapped):
            input_ids[i, maxlen - len(ids):] = torch.tensor(ids, dtype=torch.long)
            attn[i, maxlen - len(ids):] = 1

        input_ids = input_ids.to(self.model.device)
        attn = attn.to(self.model.device)

        with torch.no_grad():
            out = self.model.generate(
                input_ids=input_ids,
                attention_mask=attn,
                max_new_tokens=self.max_new_tokens,
                do_sample=False,
                num_beams=1,
                pad_token_id=pad,
            )
        gen = out[:, maxlen:]
        texts = self.tokenizer.batch_decode(gen, skip_special_tokens=True)
        return [Prediction(text=t, letter=parse_letter(t)) for t in texts]


# ---------------------------------------------------------------------------
# offline stand-in, for harness tests and dry runs
# ---------------------------------------------------------------------------

class StubModel:
    """Deterministic fake scorer.

    Emulates a plausible degradation surface so the harness, the resume logic
    and the analysis can be exercised end to end with no GPU: accuracy falls
    with token count and with fragmentation, which is the shape the real
    experiment is testing for.  It proves the pipeline runs; it proves nothing
    about the hypothesis, and `analysis` marks any run containing StubModel
    rows as non-substantive.
    """

    name = "stub"
    max_context = 1 << 20

    def __init__(self, seed: int = 0, gold_letters: Sequence[str] | None = None):
        self.seed = seed
        self._gold = list(gold_letters) if gold_letters else None

    def score(self, batch_ids: Sequence[Sequence[int]]) -> list[Prediction]:
        import hashlib

        out = []
        for k, ids in enumerate(batch_ids):
            h = hashlib.sha256(
                (str(self.seed) + ",".join(map(str, ids[:32]))).encode()
            ).digest()
            p_correct = max(0.05, 0.95 - 0.06 * (len(ids) / 1024.0))
            draw = h[0] / 255.0
            gold = self._gold[k] if self._gold and k < len(self._gold) else "A"
            letter = gold if draw < p_correct else "ABCD"[h[1] % 4]
            out.append(Prediction(text=f" {letter}", letter=letter))
        return out
