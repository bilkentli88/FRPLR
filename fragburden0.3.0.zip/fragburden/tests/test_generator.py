"""Generator and ledger audit.  The Phase 3 gate is zero audit failures."""

from __future__ import annotations

import pytest

from fragburden.generator import GenConfig, generate, realize
from fragburden.ledger import Ledger, Proposition, Realization, audit_batch
from fragburden.lexicon import (
    LEXICONS,
    TEMPLATES,
    max_complexity,
    sign_off_status,
)
from fragburden.testing import toy_dial

LANGS = ("en", "tr", "ru")
FAMILIES = ("state_tracking", "negation", "reachability", "retrieval")


@pytest.fixture(scope="module")
def counter():
    d = toy_dial().at(100)
    return lambda s: len(d.encode_pieces(s))


@pytest.mark.parametrize("language", LANGS)
@pytest.mark.parametrize("family", FAMILIES)
def test_generated_ledgers_audit_clean(language, family):
    ledgers = []
    for seed in range(40):
        cfg = GenConfig(family=family, language=language, complexity=2,
                        realization="verbose", seed=seed)
        ledgers.append(generate(cfg))
    rep = audit_batch(ledgers)
    assert rep["n_failed"] == 0, rep["failures"]


@pytest.mark.parametrize("language", LANGS)
def test_option_strings_fixed_across_verbosity(language):
    """Sec. 4.5: option strings and ordering are held fixed across the
    verbose/compact contrast, so phrasing artifacts cannot masquerade as the
    Arm B wording surplus."""
    for seed in range(20):
        a = generate(GenConfig("negation", language, 2, "verbose", seed))
        b = generate(GenConfig("negation", language, 2, "compact", seed))
        assert a.options == b.options
        assert a.answer_key == b.answer_key
        assert a.option_errors == b.option_errors


@pytest.mark.parametrize("language", LANGS)
def test_verbose_is_longer_than_compact(language, counter):
    for seed in range(10):
        a = generate(GenConfig("state_tracking", language, 3, "verbose", seed))
        b = generate(GenConfig("state_tracking", language, 3, "compact", seed))
        assert counter(a.body()) > counter(b.body())


@pytest.mark.parametrize("language", LANGS)
@pytest.mark.parametrize("target", [256, 512, 1024])
def test_length_targeting_converges(language, counter, target):
    cfg = GenConfig("state_tracking", language, 2, "verbose", seed=1,
                    target_tokens=target)
    prompt, ledger, _n = realize(cfg, counter)
    got = counter(prompt)
    tol = max(8, int(target * 0.04))
    assert abs(got - target) <= tol * 3, f"target {target}, got {got}"
    assert not ledger.audit()


def test_exactly_one_correct_option():
    for language in LANGS:
        for family in FAMILIES:
            lg = generate(GenConfig(family, language, 2, "verbose", 0))
            n = sum(1 for v in lg.option_errors.values() if v == "correct")
            assert n == 1, (language, family, lg.option_errors)


def test_distractors_are_typed():
    lg = generate(GenConfig("negation", "en", 4, "verbose", 0))
    types = set(lg.option_errors.values())
    assert "correct" in types
    assert "pre_cancellation" in types, (
        "the negation family must expose a pre-cancellation distractor; it is "
        "what makes the family interpretable"
    )


def test_audit_catches_a_missing_realization():
    lg = Ledger(
        propositions=[Proposition("possession", ("O1", "P1"))],
        answer="x", answer_key="A", query="q",
        options={"A": "x", "B": "y"},
        option_errors={"A": "correct", "B": "missed_update"},
        realizations=[],
    )
    failures = lg.audit()
    assert any("no realization" in f for f in failures), failures


def test_audit_catches_duplicate_options():
    lg = Ledger(
        propositions=[], answer="x", answer_key="A", query="q",
        options={"A": "x", "B": "x"},
        option_errors={"A": "correct", "B": "missed_update"},
        realizations=[],
    )
    assert any("duplicate" in f for f in lg.audit())


def test_lexicon_completeness():
    """Every template placeholder must resolve for every language."""
    for lang, lex in LEXICONS.items():
        for kind in ("take", "give", "borrow", "return", "place"):
            assert kind in TEMPLATES[lang], (lang, kind)
        for key, noun in lex["objects"].items():
            for case in ("nom", "acc"):
                assert case in noun.forms, (lang, key, case)
        for key, person in lex["people"].items():
            for case in ("nom", "dat", "abl"):
                assert case in person.forms, (lang, key, case)


def test_signoff_status_is_honest():
    """TR and RU must not claim validation they do not have (Phase 4 gate)."""
    status = sign_off_status()
    assert status["en"] is True
    assert status["tr"] is False, "do not mark Turkish signed off without a native pass"
    assert status["ru"] is False


@pytest.mark.parametrize("language", LANGS)
@pytest.mark.parametrize("verbosity", ["verbose", "compact"])
def test_negation_avoids_byte_identical_repeats(language, verbosity):
    """Repeated identical sentences let a model match on the repeat instead of
    tracking state, and flatten the fragmentation contrast."""
    cap = max_complexity(language, verbosity)
    for complexity in range(2, cap + 1, 2):
        lg = generate(GenConfig("negation", language, complexity, verbosity, seed=0))
        texts = [r.text for r in lg.realizations]
        assert len(set(texts)) == len(texts), (complexity, texts)


@pytest.mark.parametrize("language", LANGS)
def test_negation_refuses_to_repeat_silently(language):
    """Past the variant budget the generator must fail loudly, not emit
    duplicate sentences."""
    cap = max_complexity(language, "verbose")
    with pytest.raises(ValueError, match="verbatim"):
        generate(GenConfig("negation", language, cap + 2, "verbose", seed=0))


def test_grid_complexities_are_within_variant_budget():
    from fragburden import grid
    for name, fn in grid.BLOCKS.items():
        for spec in fn().specs:
            if spec.family != "negation":
                continue
            verb = "verbose" if spec.realization in ("na", "verbose") else "compact"
            assert spec.complexity <= max_complexity(spec.language, verb), (
                f"{name}: complexity {spec.complexity} exceeds variant budget"
            )
