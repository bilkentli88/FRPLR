"""The dial has to be monotone and in-vocabulary or phi is uninterpretable."""

from __future__ import annotations

import pytest

from fragburden.dial import FragmentationDial, verify_monotone
from fragburden.testing import (
    all_sample_texts,
    sample_texts,
    toy_dial,
    toy_unigram_dial,
)

LEVELS = (100, 75, 50, 25)


@pytest.fixture(scope="module")
def dial() -> FragmentationDial:
    return toy_dial()


def test_capability_reports_merge_rank(dial):
    cap = dial.capability()
    assert cap["model_type"] == "BPE"
    assert cap["merge_rank_available"] is True
    assert cap["dial_type"] == "merge_rank"
    assert cap["usable_for_arm_a"] is True


def test_monotone_and_in_vocabulary(dial):
    report = verify_monotone(dial, all_sample_texts(), LEVELS)
    assert report["monotone_nondecreasing"], report["counts"]
    assert report["all_in_vocab"], report["oov"]


def test_fragmentation_actually_increases(dial):
    texts = all_sample_texts()
    n_full = sum(len(dial.at(100).encode_pieces(t)) for t in texts)
    n_quarter = sum(len(dial.at(25).encode_pieces(t)) for t in texts)
    assert n_quarter > n_full, "the dial must produce measurable fragmentation"


def test_phi_increases_as_merges_are_removed(dial):
    texts = all_sample_texts()
    base = sum(len(dial.at(100).encode_pieces(t)) for t in texts)
    phis = [sum(len(dial.at(l).encode_pieces(t)) for t in texts) / base
            for l in LEVELS]
    assert phis == sorted(phis), phis
    assert phis[0] == pytest.approx(1.0)


def test_ids_round_trip_through_vocab(dial):
    d = dial.at(50)
    for text in all_sample_texts():
        pieces = d.encode_pieces(text)
        ids = d.pieces_to_ids(pieces)
        assert len(ids) == len(pieces)
        base_vocab = dial.base.get_vocab()
        for p in pieces:
            assert p in base_vocab, f"{p!r} escaped the base vocabulary"


def test_fingerprint_changes_with_setting(dial):
    fps = {l: dial.at(l).fingerprint for l in LEVELS}
    assert len(set(fps.values())) == len(LEVELS), fps


def test_fingerprint_is_stable_across_instances():
    a = toy_dial().at(50).fingerprint
    b = FragmentationDial(toy_dial().base).at(50).fingerprint
    assert a == b


def test_chunk_encoding_matches_full_encoding(dial):
    """encode_chunk_pieces must agree with the full encoder, or the naturalness
    perturbation is operating on a different segmentation than the dial."""
    d = dial.at(75)
    for text in sample_texts("tr"):
        whole = d.encode_pieces(text)
        by_chunk = []
        for chunk, _ in d.pre_tokenize(text):
            by_chunk.extend(d.encode_chunk_pieces(chunk))
        assert by_chunk == whole


def test_unigram_fallback_dial():
    """Gemma 3's SentencePiece vocabulary may not expose merge ranks."""
    ud = toy_unigram_dial()
    cap = ud.capability()
    assert cap["model_type"] == "Unigram"
    assert cap["merge_rank_available"] is False
    assert cap["dial_type"] == "vocab_restrict"
    assert cap["usable_for_arm_a"] is True

    report = verify_monotone(ud, all_sample_texts(), LEVELS)
    assert report["monotone_nondecreasing"], report["counts"]
    assert report["all_in_vocab"], report["oov"]
