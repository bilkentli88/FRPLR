"""The naturalness perturbation is the identification device (sec. 4.2).

If it does not hold token count fixed, it is not a naturalness manipulation --
it is a second fragmentation dial, and the design collapses.
"""

from __future__ import annotations

import pytest

from fragburden.naturalness import (
    ChunkResegmenter,
    NaturalnessPerturber,
    boundary_divergence,
)
from fragburden.testing import all_sample_texts, toy_dial

LEVELS = (100, 75, 50, 25)


@pytest.fixture(scope="module")
def dial():
    return toy_dial()


@pytest.fixture(scope="module")
def vocab(dial):
    return list(dial.base.get_vocab().keys())


@pytest.mark.parametrize("phi", LEVELS)
@pytest.mark.parametrize("level", ["N0", "N1", "N2"])
def test_token_count_is_matched_within_phi(dial, vocab, phi, level):
    """The whole design rests on this."""
    d = dial.at(phi)
    p = NaturalnessPerturber(d, base_vocab=vocab)
    for text in all_sample_texts():
        baseline = d.encode_pieces(text)
        out = p.apply(text, level, seed=7)
        assert len(out.pieces) == len(baseline), (
            f"phi={phi} level={level}: {len(out.pieces)} != {len(baseline)}"
        )


@pytest.mark.parametrize("level", ["N0", "N1", "N2"])
def test_pieces_stay_in_vocabulary(dial, vocab, level):
    d = dial.at(50)
    p = NaturalnessPerturber(d, base_vocab=vocab)
    base_vocab = dial.base.get_vocab()
    for text in all_sample_texts():
        for piece in p.apply(text, level, seed=3).pieces:
            assert piece in base_vocab


def test_bytes_are_preserved(dial, vocab):
    """A perturbation that changes the underlying bytes is not a
    re-segmentation, it is a different stimulus."""
    d = dial.at(50)
    p = NaturalnessPerturber(d, base_vocab=vocab)
    for text in all_sample_texts():
        base = "".join(d.encode_pieces(text))
        for level in ("N1", "N2"):
            assert "".join(p.apply(text, level, seed=11).pieces) == base


def test_n0_is_the_identity(dial, vocab):
    d = dial.at(75)
    p = NaturalnessPerturber(d, base_vocab=vocab)
    for text in all_sample_texts():
        assert p.apply(text, "N0", seed=1).pieces == d.encode_pieces(text)


def test_n2_deviates_at_least_as_much_as_n1(dial, vocab):
    d = dial.at(50)
    p = NaturalnessPerturber(d, base_vocab=vocab)
    text = " ".join(all_sample_texts())
    base = d.encode_pieces(text)
    dev1 = boundary_divergence(p.apply(text, "N1", seed=5).pieces, base)
    dev2 = boundary_divergence(p.apply(text, "N2", seed=5).pieces, base)
    assert dev2 >= dev1, (dev1, dev2)
    assert dev2 > 0, "N2 produced no deviation at all; the dial has no slack"


def test_perturbation_is_deterministic(dial, vocab):
    d = dial.at(50)
    p = NaturalnessPerturber(d, base_vocab=vocab)
    text = " ".join(all_sample_texts())
    assert p.apply(text, "N1", seed=42).pieces == p.apply(text, "N1", seed=42).pieces


def test_perturbable_fraction_is_reported(dial, vocab):
    """A low perturbable fraction means the naturalness contrast is weak and
    must be reported, not silently absorbed."""
    d = dial.at(25)
    p = NaturalnessPerturber(d, base_vocab=vocab)
    out = p.apply(" ".join(all_sample_texts()), "N2", seed=2)
    assert 0.0 <= out.perturbable_fraction <= 1.0
    assert out.total_chunks > 0


def test_resegmenter_enumerates_alternatives():
    r = ChunkResegmenter(["a", "b", "c", "ab", "bc", "abc"])
    assert r.alternatives_exist("abc", 2) is True     # a|bc and ab|c
    assert r.alternatives_exist("abc", 3) is False    # only a|b|c
    assert r.alternatives_exist("abc", 1) is False    # only abc


def test_maximise_deviation_avoids_baseline_cuts():
    r = ChunkResegmenter(["a", "b", "c", "ab", "bc"])
    out = r.maximise_deviation("abc", 2, baseline=["ab", "c"])
    assert out == ["a", "bc"]
