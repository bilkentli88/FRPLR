"""The Phase 2 gate, automated.

'Kill and resume tested three times mid-run with zero duplicates and zero gaps.'
Free Colab will do this to the run whether or not we test it.
"""

from __future__ import annotations

import json

import pytest

from fragburden import grid
from fragburden.model import StubModel
from fragburden.runner import ResultStore, Runner, reconcile
from fragburden.spec import ItemSpec
from fragburden.testing import toy_dial


def small_specs(n: int = 24) -> list[ItemSpec]:
    out = []
    for i, (phi, nat) in enumerate(
        [(100, "N0"), (25, "N0"), (100, "N1"), (25, "N1")]
    ):
        for lang in ("en", "tr"):
            for seed in range(n // 8):
                out.append(ItemSpec(
                    arm="A", family="state_tracking", language=lang,
                    model="stub", phi_level=phi, naturalness=nat,
                    target_tokens=256, complexity=2, matching="content",
                    realization="na", seed=seed + 100 * i,
                ))
    return out


@pytest.fixture(scope="module")
def dial():
    return toy_dial()


def _runner(dial, path, batch_size=4):
    return Runner(dial, StubModel(seed=0), ResultStore(path, flush_every=1),
                  batch_size=batch_size, verbose=False)


def test_ids_are_unique_and_stable():
    specs = small_specs()
    ids = [s.id for s in specs]
    assert len(set(ids)) == len(ids)
    again = [s.id for s in small_specs()]
    assert ids == again


def test_id_is_independent_of_field_order():
    a = ItemSpec("A", "negation", "tr", "m", 50, "N1", 1024, 2, "content", "na", 3)
    b = ItemSpec(seed=3, realization="na", matching="content", complexity=2,
                 target_tokens=1024, naturalness="N1", phi_level=50,
                 model="m", language="tr", family="negation", arm="A")
    assert a.id == b.id


def test_run_completes_and_is_idempotent(tmp_path, dial):
    path = tmp_path / "r.jsonl"
    specs = small_specs()

    first = _runner(dial, path).run(specs)
    assert first["completed_this_session"] == len(specs)

    second = _runner(dial, path).run(specs)
    assert second["pending_at_start"] == 0
    assert second["completed_this_session"] == 0

    store = ResultStore(path)
    assert store.duplicates() == {}
    assert len(store.completed()) == len(specs)


def test_three_kills_leave_no_gaps_and_no_duplicates(tmp_path, dial):
    """The gate itself."""
    path = tmp_path / "r.jsonl"
    specs = small_specs(48)

    for kill in range(3):
        runner = _runner(dial, path, batch_size=2)
        pending = runner.pending(specs)
        if not pending:
            break
        # interrupt after roughly a third of what remains
        budget = max(1, len(pending) // 3)
        seen = 0
        original = runner._run_batch

        def limited(batch, _seen=[0]):
            original(batch)
            _seen[0] += len(batch)
            if _seen[0] >= budget:
                runner._stop = True

        runner._run_batch = limited  # type: ignore[assignment]
        runner.run(specs)

    _runner(dial, path).run(specs)

    store = ResultStore(path)
    assert store.duplicates() == {}, "resume wrote an item twice"
    done = store.completed()
    missing = [s.id for s in specs if s.id not in done]
    assert not missing, f"{len(missing)} items lost across kills"


def test_torn_final_line_is_survivable(tmp_path, dial):
    """A hard kill can leave a partial JSON line; it must not poison resume."""
    path = tmp_path / "r.jsonl"
    specs = small_specs(16)
    _runner(dial, path).run(specs[:8])

    with path.open("a", encoding="utf-8") as fh:
        fh.write('{"item_id": "truncated", "corr')

    store = ResultStore(path)
    done = store.completed()
    assert len(done) == 8

    _runner(dial, path).run(specs)
    assert not [s.id for s in specs if s.id not in ResultStore(path).completed()]


def test_fingerprint_mismatch_forces_rerun(tmp_path, dial):
    path = tmp_path / "r.jsonl"
    specs = small_specs(8)
    _runner(dial, path).run(specs)

    store = ResultStore(path)
    assert len(store.completed()) == 8
    assert store.completed(require_fingerprint="deadbeef") == set()


def test_length_descending_order():
    specs = [
        ItemSpec("A", "state_tracking", "en", "m", 100, "N0", t, 2,
                 "content", "na", 0)
        for t in (1024, 8192, 2048)
    ]
    ordered = Runner.order(specs)
    assert [s.target_tokens for s in ordered] == [8192, 2048, 1024]


def test_reconcile_reports_gaps(tmp_path, dial):
    path = tmp_path / "r.jsonl"
    specs = small_specs(16)
    _runner(dial, path).run(specs[:8])

    block = grid.RunBlock(name="test", specs=specs)
    rep = reconcile([block], ResultStore(path))
    assert rep["clean"] is False
    assert rep["blocks"][0]["missing"] == 8

    _runner(dial, path).run(specs)
    rep2 = reconcile([block], ResultStore(path))
    assert rep2["clean"] is True


def test_results_are_well_formed_json(tmp_path, dial):
    path = tmp_path / "r.jsonl"
    _runner(dial, path).run(small_specs(8))
    for line in path.read_text(encoding="utf-8").splitlines():
        row = json.loads(line)
        for key in ("item_id", "correct", "realized_tokens", "baseline_tokens",
                    "fragmentation_ratio", "compression_rate",
                    "required_span_tokens", "tokenizer_fingerprint"):
            assert key in row, key
        assert row["realized_tokens"] > 0
        assert row["fragmentation_ratio"] > 0
