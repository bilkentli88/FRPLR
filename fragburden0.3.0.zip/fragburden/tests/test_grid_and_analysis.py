"""Grid arithmetic must match the proposal, and analysis must refuse stub runs."""

from __future__ import annotations

import pytest

from fragburden import analysis, grid
from fragburden.burden import (
    compression_rate,
    epsilon,
    estimate_effective_window,
    fragmentation_ratio,
    theorem_43_bound,
)


def test_segmentation_conditions_are_ten():
    conds = grid.segmentation_conditions()
    assert len(conds) == 10
    assert conds.count((100, "N2")) == 1
    assert conds.count((25, "N2")) == 1
    assert sum(1 for _, n in conds if n == "N0") == 4


def test_arm_a_core_matches_proposal_table():
    b = grid.arm_a_core()
    assert b.n_items == 10 * 3 * 4 * 2 * 24 == 5760
    assert b.gpu_hours == pytest.approx(5.44, abs=0.05)


def test_arm_b_matches_proposal_table():
    b = grid.arm_b()
    assert b.n_items == 3 * 2 * 3 * 2 * 32 == 1152
    assert b.gpu_hours == pytest.approx(1.35, abs=0.05)


def test_main_run_budget_is_within_plan():
    b = grid.budget()
    assert b["duplicate_specs"] == 0, "the grid enumerates an item twice"
    assert b["unique_items"] == b["total_items"]
    # proposal v0.3 sec 6.2 plans ~15 GPU-hours before contingency
    assert 10.0 < b["total_gpu_hours"] < 20.0, b["total_gpu_hours"]


def test_every_block_builds():
    for name in grid.BLOCKS:
        block = grid.BLOCKS[name]()
        assert block.n_items > 0
        assert len({s.id for s in block.specs}) == block.n_items


def test_seconds_interpolates():
    assert grid.seconds_for(1024) == 0.9
    assert 1.7 < grid.seconds_for(3000) < 3.5


# ---------------------------------------------------------------------------


def test_fragmentation_ratio():
    assert fragmentation_ratio(200, 100) == 2.0


def test_compression_rate():
    assert compression_rate("abcdef", 3) == 2.0
    assert compression_rate("a b c", 5, unit="words") == pytest.approx(0.6)


def test_epsilon_counts_span_failures():
    assert epsilon([10, 20, 30, 40], 25) == 0.5
    assert epsilon([1, 2], 100) == 0.0


def test_effective_window_returns_inf_when_never_falls():
    rows = [{"realized_tokens": n, "correct": 1} for n in (1024, 4096, 8192)]
    assert estimate_effective_window(rows) == float("inf")


def test_effective_window_interpolates():
    rows = (
        [{"realized_tokens": 1024, "correct": 1}] * 10
        + [{"realized_tokens": 8192, "correct": 0}] * 10
    )
    w = estimate_effective_window(rows, criterion=0.5)
    assert 1024 < w < 8192


def test_theorem_43_bound_is_monotone_in_epsilon():
    a = theorem_43_bound(R_Z=3.0, eps=0.1, source_alphabet_size=96)
    b = theorem_43_bound(R_Z=3.0, eps=0.2, source_alphabet_size=96)
    assert b > a > 0


def test_provenance_flags_stub_runs(tmp_path):
    import json

    path = tmp_path / "r.jsonl"
    rows = [{
        "item_id": f"x{i}", "arm": "A", "family": "state_tracking",
        "language": "en", "model": "stub", "phi_level": 100,
        "naturalness": "N0", "target_tokens": 1024, "complexity": 2,
        "matching": "content", "realization": "na", "seed": i,
        "correct": i % 2, "realized_tokens": 1024, "baseline_tokens": 1024,
        "fragmentation_ratio": 1.0, "compression_rate": 3.0,
        "required_span_tokens": 500, "perturbable_fraction": 0.5,
        "tokenizer_fingerprint": "abc", "predicted": "A", "gold": "A",
        "error_type": "correct", "wall_seconds": 0.1,
    } for i in range(8)]
    path.write_text("\n".join(json.dumps(r) for r in rows), encoding="utf-8")

    df = analysis.load(str(path))
    prov = analysis.provenance(df)
    assert prov["contains_stub"] is True
    assert prov["substantive"] is False
